# Tiny Style — Sentence-Level Diffs

*Every meaningful sentence change in the NC article (Apr 12 session). Source: actual diff between ORIGINAL and Final-v1.*

---

## Opening

**ORIGINAL:**
> An employee spent 8 months developing and building sales funnels and marketing material for a small business. The business

**TINY:** Added comma after "materials" (grammar), kept story structure. Story IS the argument.

**ORIGINAL:**
> The belief that a non-compete clause protects a small business from this exact scenario is widespread, intuitive, and, for most business owners, catastrophically wrong.

**TINY REPLACEMENT:**
> The story above captures a fear that lives in every founder who has ever hired offshore and handed a contractor the keys to their marketing infrastructure.

**What changed:** "belief that is wrong" → "a fear that lives in". Generic → specific ("hired offshore"). Stated principle → felt experience.

---

## H2: The Promises and the Gaps

**ORIGINAL H2:** "What a Non-Compete Actually Does"
**TINY:** "Independent Contractor Non-Competes: The Promises and the Gaps"

**Move:** Added "Promises AND the Gaps" — the "and gaps" signals this isn't just explanation.

---

## H3: What the Clause Actually Restricts

**ORIGINAL CALLOUT:**
> "A non-compete controls where a contractor works next. It says nothing about what they know, what they build, or who they take with them."

**TINY CALLOUT:**
> "The non-compete protects a geographic territory that no longer exists in the knowledge economy. Your customer list is in their head, not on a map."

**What changed:** Description → revelation. Telling what it does → showing what the reader didn't realize (territory is obsolete, asset is in their head).

---

## H3: The State-by-State Problem

**ORIGINAL H2:** "What Courts and States Have Decided"
**TINY H2:** "The Non-Compete Contradiction: Misclassification Risk"

**The insight:** Courts examining the non-compete = court examining whether they're an employee. The non-compete IS the misclassification evidence.

**TINY BODY ADDITION:**
> "Consequently, when you send a cease-and-desist or file an injunction over a contractor violation, you are demonstrating to the court that you treated the contractor as an employee."

**The causal chain:** Action → unintended consequence → the consequence is the opposite of the goal.

**TINY ESCALATION ADDITION:**
> "Worse, this gap is not visible until it is too late. The moment of discovery comes when the contractor leaves, takes th"

**TINY CALLOUT:**
> "Enforcing a non-compete does not prove the contractor was yours. It proves you treated them like an employee. That is the exact opposite of what you were trying to establish."

**The contradiction:** The protective action IS the misclassification evidence.

---

## H2: Effective Tools That Protect Your Business

**ORIGINAL H2:** "The Control Contradiction"
**TINY H2:** "Effective Tools That Protect Your Business"

**Move:** "Control Contradiction" (process) → "Effective Tools" (outcome). Reader cares about protection, not about the legal mechanism.

---

## H3: IP Assignment

**ORIGINAL (not in original article body):**
> "An intellectual property assignment clause transfers ownership of the work product to your business upon creation."

**TINY'S CONTRAST ADDITION:**
> "A provider who builds the agreement with these three protections correctly structured from the start handles the hard part. They do not offer it as an add-on — they make it the baseline. The IP assignment is non-negotiable. The trade secret provisions are standard. That is the structure AbroadWorks builds into every independent contractor agreement."

**The brand reveal pattern:** Zero brand mentions through body. Single reveal at the end. The reader has to follow the argument to get there.

---

## H2: When Non-Compete Agreements Are Worth the Effort

**ORIGINAL H2:** "When a Non-Compete Might Actually Apply"
**TINY H2:** "When Non-Compete Agreements Are Worth the Effort"

**Move:** "might actually apply" → "worth the effort". Cost-benefit framing. The question isn't whether it's legal — it's whether it's worth doing.

**TINY CLOSING CALLOUT:**
> "A non-compete is worth using only when you have already solved the three problems it cannot solve: IP ownership, trade secret protection, and client retention."

**The prerequisite logic:** You can't use the non-compete until you've solved the things the non-compete can't solve.

---

## FAQ Transformations

**ORIGINAL:** "Can I still include a non-compete clause even if it might not be fully enforceable?"
**TINY:** "Can I enforce an independent contractor non-compete if my contractor lives in a different state?"

**ORIGINAL:** "How do I protect my business if I cannot rely on a non-compete?"
**TINY:** "What should I look for in a contractor agreement to avoid the problems described in this article?"

**Move:** Hypothetical → scenario-specific. "What if I can't?" → "What should I actually do?"

---

## Title

**ORIGINAL:** "Independent Contractor Non-Compete Agreements: What They Can and Cannot Do for Your Business"
**TINY:** "Independent Contractor Non-Compete: What It Actually Covers (and What It Doesn't)"

**Moves:**
- Drop "Agreements" (redundant)
- "Can and Cannot Do for Your Business" → "Actually Covers (and What It Doesn't)" — negative hook outperforms positive claim
- Negative preview in title signals the article will challenge assumptions
