---
name: tiny-style
description: Capture and apply Tiny's sentence-level editorial patterns derived from transcript analysis and actual diffs between original and final versions. Use when Tiny asks to apply his style, when editing drafts, or when building content that should sound like Tiny wrote it. NOT a reference document — this is distilled from Tiny's actual sentence-level edits across the NC article.
---

# Tiny-Style Skill

*Built from transcript analysis of Apr 9-12 NC article session + actual diffs between original and Final-v1.*

---

## Core Principle

**Tiny's style is diagnostic, not decorative.**

He doesn't make writing prettier. He makes it more honest. Every edit reveals something the reader doesn't know about their own situation — then gives them the tool to fix it.

The test for any sentence: does it make the reader feel something they didn't expect to feel? If it just states information, it's probably not Tiny's voice.

---

## Title Craft

**Original:** "Independent Contractor Non-Compete Agreements: What They Can and Cannot Do for Your Business"

**Tiny's version:** "Independent Contractor Non-Compete: What It Actually Covers (and What It Doesn't)"

**The moves:**
1. Drop "Agreements" — redundant with context
2. Replace "Can and Cannot Do for Your Business" with "Actually Covers (and What It Doesn't)" — the "(and What It Doesn't)" creates a negative hook that previews the contradiction
3. Keep "Independent Contractor Non-Compete" as anchor phrase — Google-friendly, clear subject

**Pattern:** Titles that include a negative preview outperform positive-claim titles. "What It Actually Covers (and What It Doesn't)" signals the article will challenge assumptions. "What They Can and Cannot Do" states the obvious.

---

## Meta Description

**Original:** "Non-compete clauses for contractors sound like protection. They are not. Learn what these agreeme..."

**Tiny's version:** "Most micro-business owners include a non-compete in their contractor agreements thinking it protec..."

**The moves:**
1. Add the specific audience: "micro-business owners"
2. Add the specific action: "include a non-compete... thinking it protects"
3. Drop "They are not" — showing is better than telling

**Pattern:** Meta descriptions work better when they describe the reader's specific behavior than when they make global claims. Tiny's meta description puts the reader inside the action ("you included a non-compete"), then implies it might not work. The original was a declaration. Tiny's is an accusation.

---

## Opening Hook — Story Before Lesson

**Original:**
> "An employee spent 8 months developing and building sales funnels and marketing material for a small business. The business..."

**Tiny's version:**
> "An employee spent 8 months developing and building sales funnels and marketing materials for a small business. The business..."

**The change:** Tiny kept the story form. The hook IS the case — not an illustration of a principle, but the principle itself. The story IS the argument.

**Tiny's opening principle:** The case in the first paragraph should contain the entire article's argument in miniature. Reader should be able to predict every H2 from the hook alone.

**Pattern:** Open with the case, not the category. Not "independent contractors often face non-compete issues" — open with "An employee spent 8 months..." and let the reader arrive at the category themselves.

---

## H2 Titles — Insight, Not Topic

**Original H2s:**
- "What a Non-Compete Actually Does"
- "What Courts and States Have Decided"
- "The Control Contradiction"
- "What Actually Protects You"
- "When a Non-Compete Might Actually Apply"

**Tiny's H2s:**
- "Independent Contractor Non-Competes: The Promises and the Gaps"
- "The Non-Compete Contradiction: Misclassification Risk"
- "Effective Tools That Protect Your Business"
- "When Non-Compete Agreements Are Worth the Effort"

**The moves:**
1. "What a Non-Compete Actually Does" → "The Promises and the Gaps" — adds the gap frame, signals this is not just explanation
2. "What Courts and States Have Decided" → "The Non-Compete Contradiction: Misclassification Risk" — replaces legal process with the insight (the contradiction), adds the misclassification risk which is the real danger
3. "What Actually Protects You" → "Effective Tools That Protect Your Business" — "effective" is the judgment, implies the alternatives are not effective
4. "When a Non-Compete Might Actually Apply" → "When Non-Compete Agreements Are Worth the Effort" — "worth the effort" is the new frame, sounds like a cost-benefit calculation

**Pattern:** H2 titles should name the insight, not the topic. The reader should be able to read H2s in order and get the article's argument without reading body text.

---

## Callout Quotes — The Contradiction Principle

**Original callouts:**
> *"A non-compete controls where a contractor works next. It says nothing about what they know, what they build, or who they take with them."*

**Tiny's callouts:**
> *"The non-compete protects a geographic territory that no longer exists in the knowledge economy. Your customer list is in their head, not on a map."*

**The difference:** The original callout explains what the clause does (functional description). Tiny's callout reveals what the reader didn't know (the territory argument is obsolete, the real asset is in their head).

**Original callout:**
> *"Four states void non-compete clauses entirely. Others enforce them only above specific income thresholds that most micro-business owners never meet."*

**Tiny's version:**
> *"The non-compete protects a geographic territory that no longer exists in the knowledge economy. Your customer list is in their head, not on a map."*

**The contradiction pattern:** Every callout should contain a contradiction the reader didn't see coming. The reader thought the non-compete was protecting them. The callout reveals what it's actually protecting — and the gap is usually embarrassing.

**New callout added by Tiny:**
> *"Enforcing a non-compete does not prove the contractor was yours. It proves you treated them like an employee. That is the exact opposite of what you were trying to establish."*

**The causal chain:** This is the signature Tiny move. Action → unintended consequence → the consequence is the opposite of the goal. He doesn't say "be careful of misclassification." He shows that the protective action IS the misclassification evidence.

---

## Body Voice — The Story Captures the Fear

**Original:**
> "The belief that a non-compete clause protects a small business from this exact scenario is widespread, intuitive, and, for most business owners, catastrophically wrong."

**Tiny replaced this with:**
> "The story above captures a fear that lives in every founder who has ever hired offshore and handed a contractor the keys to their marketing infrastructure."

**The moves:**
1. Replace stated principle ("The belief... is widespread") with felt experience ("a fear that lives in...")
2. Add specificity: "hired offshore" and "handed a contractor the keys" — these are concrete actions, not abstract categories
3. Replace "catastrophically wrong" with describing the scenario the fear is about — showing beats telling

**Pattern:** When describing reader beliefs or fears, Tiny names the specific context ("hired offshore") rather than the generic category ("small business owner"). The reader recognizes their situation, not their label.

---

## H3s — The Mechanism Is the Lesson

**Original H3:** "What the Clause Actually Restricts"

**Body text:** "The non-compete does not restrict what the contractor knows: the skills, the experiences, the processes, or the trade secrets they accumulated while working with you."

**Original H3:** "The Enforceability Landscape"

**Body text:** "Just as the clause's impact on a contractor is limited, the legal framework around non-compete enforceability is generally unfavorable to businesses with standard contractor relationships."

**Tiny's H3:** "The State-by-State Problem"

**Body text:** "The clause feels solid because it sits in a contract. Contracts feel permanent because they are documents, and documents feel enforceable because they are documents with signatures."

**The Tiny pattern:** The H3 names the problem ("State-by-State Problem"). The body explains WHY it's a problem — the mechanism, not the fact. He explains why the clause "feels solid" and why that feeling is wrong.

**Contrast with AI writing:** Most AI body text explains what the clause does. Tiny's body text explains why the reader's intuition about it is wrong.

---

## Causal Chain — "Consequently" and "Worse"

**Original:** No causal connector between misclassification risk and enforcement action.

**Tiny added:**
> "Consequently, when you send a cease-and-desist or file an injunction over a contractor violation, you are demonstrating to the court that you treated the contractor as an employee."

**Original:** No escalation connector.

**Tiny added:**
> "Worse, this gap is not visible until it is too late."

**Pattern:** Every consequence should be connected to its cause with a specific word:
- "Consequently" — logical outcome of the previous point
- "Worse" — escalation, usually revealing the hidden second-order effect
- "Beyond" — adding a dimension the reader hasn't considered

---

## The "So Bad It's Good" Spin (Chavez-DeRemer)

**Original framing:** The case is a warning about non-competes backfiring.

**Tiny's framing:**
> "The lesson is not that you should avoid non-competes entirely. The lesson is that non-competes in the wrong context are not just useless — they are actively dangerous. They do not merely fail to protect you. They provide evidence that you need protection from."

**The spin:** Non-competes don't just fail in this context. They compound the problem. The evidence of failure IS the misclassification evidence. Tiny turns the failure into a structural indictment.

---

## FAQ Transformations

**Original FAQ:** "Can I still include a non-compete clause even if it might not be fully enforceable?"

**Tiny's FAQ:** "Can I enforce an independent contractor non-compete if my contractor lives in a different state?"

**Original FAQ:** "How do I protect my business if I cannot rely on a non-compete?"

**Tiny's FAQ:** "What should I look for in a contractor agreement to avoid the problems described in this article?"

**The moves:**
1. Replace hypothetical questions with scenario-specific questions
2. Replace "what if I can't protect myself" with "what should my agreement actually include"
3. The Tiny FAQ assumes the reader already knows they have a problem — they want to know what a good agreement looks like

---

## Summary: The Tiny Sentence Patterns

| Pattern | Avoid | Use Instead |
|---------|-------|------------|
| Topic-label H2 | "What a Non-Compete Does" | "The Promises and the Gaps" |
| Functional callout | "X controls Y" | "X protects something that no longer exists" |
| Stated principle | "The belief X is wrong" | "A fear that lives in every [specific context]" |
| Explanatory body | "The clause does X" | "The clause feels X because Y — but Y doesn't mean what you think" |
| Hypothetical FAQ | "What if I can't protect myself?" | "What should my agreement actually include?" |
| Neutral transition | "Additionally" | "Consequently" / "Worse" / "Beyond" |
| Label description | "small business owners" | "founders who hired offshore" |
| Standalone warning | "misclassification is a risk" | "enforcing a non-compete proves you treated them as an employee" |

---

## When Triggered

- Editing any article or post draft
- Writing H2 or H3 titles
- Writing callout quotes
- Building new content that should carry Tiny's voice
- Reviewing AWAA or NavaAA output for Tiny-style compliance

## Source Files

- `references/tiny-style-sentences.md` — full diff analysis, every changed sentence labeled
- `references/session-review-excerpts.md` — Apr 12 teaching moments in Tiny's words
