# AW Brand Integration Pattern — Full Corpus Analysis

## Source Data

- **Total AW corpus:** 79 articles in `rag_abroadworks/clean_md/`
- **Tiny's articles:** 23
- **Other authors:** 55 (Sherry T., David Landau, Yhen Villas, Paul Sial, Mike Roston)

## Tiny's Pattern (23 articles)

### Core Methodology

1. **First-person plural ("we/our")** in solution sections
2. **Embedded mid-paragraph** — never as standalone block, never in headers
3. **Does argumentative work** — illustrates a point, contrasts alternatives, demonstrates expertise
4. **Frequency:** 1–11 mentions per article, proportional to topic relevance
5. **Some articles have zero mentions** (async-work, federal-reserve, tariffs-recession) — pure education, AW not forced

### Examples by Frequency

**High frequency (8+ mentions):**
- `outsourcing-customer-care.md` — 11 mentions, multiple sections, full AW methodology described
- `outsourcing-vs-offshoring.md` — 8 mentions, entire solution section AW-centric

**Medium frequency (4–6 mentions):**
- `bookkeeper-risk.md` — 6 mentions, "AbroadWorks offers a safer alternative" woven throughout
- `avoid-zombie-hires-offshore-hiring-guide.md` — 4 mentions, "At AbroadWorks, we design..." in vetting paragraphs
- `ai-customer-service-trap.md` — 4 mentions, "AbroadWorks solves this by..." in quality-standard paragraph

**Low frequency (1–2 mentions):**
- `hubspot-virtual-assistant.md` — 2 mentions
- `finance-system.md` — 1 mention, "AbroadWorks can help" at end of solution section
- `law-firm-outsourcing-profitability.md` — 1 mention, "via a compliant partner like AbroadWorks"

**Zero mentions (pure education):**
- `async-work.md`
- `federal-reserve.md`
- `tariffs-recession.md`
- `virtual-assistants-uncertain-times.md`
- `law-firm-productivity.md`

### Example Passages (Tiny)

**Example 1 — Embedded mid-contrast (avoid-zombie-hires):**
> *"Vetting talent isn't just about skillsets; it's about how they think. Implement structured screening tasks that mimic real-world challenges. At AbroadWorks, we design role-specific assessments that test for critical thinking, creativity, and follow-through."*

**Example 2 — Embedded mid-explanation (bookkeeper-risk):**
> *"At AbroadWorks, we understand the delicate balance small business owners must maintain. You need to..."*

**Example 3 — Solution section closer (outsourcing-vs-offshoring):**
> *"The SMB Life Hack for true scaling is the Managed Hybrid Model... By partnering with a firm like AbroadWorks, you get a dedicated specialist in a global hub, but they are backed by a management layer..."*

**Example 4 — First-person plural throughout (outsourcing-customer-care):**
> *"The AbroadWorks 'Find-Onboard-Manage' Funnel: Sourcing the Top 1%"*
> *"Once we find the right person, we focus on making sure they understand your specific vision..."*
> *"The biggest win with AbroadWorks is our management layer..."*

---

## Non-Tiny Pattern (55 articles)

### Core Methodology

1. **Third-party reference** — "an agency like AbroadWorks", "use this service"
2. **Option in comparison set** — AW evaluated among alternatives
3. **Frequency:** 0–2 mentions per article (most have 0–1)
4. **Placement:** FAQ/closing section or absent entirely
5. **David Landau (14 articles):** ZERO mentions across entire body

### Examples (Non-Tiny)

**Sherry T. — executive-assistant-agencies.md:**
> *"1. AbroadWorks: Best Overall Recruitment Agency for Executive Assistants"*
> *"AbroadWorks stands out by enabling businesses to access experienced executive assistants..."*
> *"The distinctiveness of AbroadWorks lies in its human-centered approach..."*

(Note: Sherry uses "Best Overall" as a ranking recommendation — service directory style)

**Sherry T. — choose-va.md:**
> *"Another option is working with an agency like AbroadWorks. They do all the heavy lifting - finding and screening candidates, matching you with the right person, and handling all the boring HR stuff."*

**Yhen Villas — benefits-offshore-digital-marketing.md:**
> *"At AbroadWorks, we specialise in helping businesses build high-performing offshore digital marketing teams..."*

**Paul Sial, Mike Roston, David Landau:** Zero body mentions — articles are pure educational content, AW never surfaces.

---

## Pattern Application for H2.3

**What to do:**
- Write "we/our" in solution paragraphs
- Describe how the three protections (IP assignment, trade secret, non-solicitation) are actually built into an AW agreement
- Embed mid-paragraph, within explanatory passages
- Let AW be the natural home for the solution, not a recommendation

**What NOT to do:**
- Don't write "you should use AbroadWorks" (counseling the reader)
- Don't write "AbroadWorks is the best option" (service directory)
- Don't write standalone AW promotional blocks
- Don't treat AW as one option among several

**Example H2.3 application:**
> *"IP assignment is the foundation, and it is the provision most template agreements skip. An IP assignment clause transfers ownership of the work product to you as it is created. At AbroadWorks, we include this clause in every agreement — not as an option, but as the standard structure. Without it, the contractor retains copyright..."*

This is the Tiny pattern: describing how we do it, because the reader is learning from someone who operates there.