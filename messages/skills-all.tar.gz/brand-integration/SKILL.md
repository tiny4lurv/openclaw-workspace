---
name: brand-integration
description: "Integrate AbroadWorks (AW) and Nava Healthcare brands into content using Tiny's reveal methodology. Use when drafting articles, posts, or any content that references either brand. Triggers on: writing AW or Nava content, weaving in brand mentions, or any content that references AW or Nava in body text. Not for final edited versions already in abroadworks/ folder."
---

# Brand Integration Skill

## The Core Principle

**Build the description. Earn the reveal.**

Tiny's articles never name the brand throughout the body. They describe the service functionally, then land the brand name as a single earned closer. The reader discovers the provider by following the argument, not by seeing the name on loop.

## SEO Reveal Pattern

1. **Body:** Describe the service using functional language — "a provider that builds...", "the firm that structures...", "a managed global talent partner"
2. **Closer:** Single brand reveal in the final sentence of the section or article
3. **Never:** "AW" in text, repeat brand name drops, early naming

**Example — old pattern (too direct):**
> *"At AbroadWorks, we include this clause in every agreement. AbroadWorks simplifies the process. With AbroadWorks, you get the protection you need..."*

**Example — new pattern (reveal):**
> *"A provider who builds the agreement with these three protections correctly structured from the start handles the hard part. They do not offer it as an add-on — they make it the baseline. The IP assignment is non-negotiable. The trade secret provisions are standard. That is the structure AbroadWorks builds into every independent contractor agreement."*

Zero brand mentions in body. One earned reveal at the section closer.

## When Triggered

- Drafting any AW or Nava article
- Revising existing drafts for brand integration quality
- Adding brand mentions to any long-form content

## Skill Files

- `references/aw-brand-pattern.md` — Full corpus analysis with reveal pattern examples