# AbroadWorks Writing Feedback — Editor Notes
## Source: customGPT feedback loop + Forensic Critique documents
## Saved: 2026-03-27 (from Downloads: Forensic Critique and Strategic Recovery*.md)

---

## CORE FAILURE PATTERN

**What the AI kept doing wrong:**
- Every paragraph exactly 3 sentences — felt thin, "breezy," lacked analytical weight
- Paragraphs were isolated "islands" — no logical progression from one to the next
- Choppy reading experience even though each paragraph was locally correct
- No connective tissue — reader has to work to follow the argument flow

**What Tiny's feedback targeted:**
1. Paragraph density (too short)
2. Transitions between paragraphs (missing bridges)
3. Readability through connected prose

---

## THE 2x4-6 RULE (Non-Negotiable Structural Rule)

Every sub-heading (H3) must contain exactly **two paragraphs**, and each paragraph must be between **4 and 6 sentences**.

**Why it matters:**
- 3-sentence paragraphs feel thin — making a claim and stopping before proving it
- 4-6 gives enough space for: claim → mechanism → evidence → implication → bridge
- Enforces forensic depth over surface-level observations

**The 5-sentence paragraph template:**
1. **Sentence 1:** The claim
2. **Sentence 2:** The "Why it happens" (Mechanism)
3. **Sentence 3:** The Math/Evidence
4. **Sentence 4:** The Founder/Customer Implication (the result for their life/business)
5. **Sentence 5:** The Bridge to the next paragraph

**The rule:** Never just extend a paragraph with filler. Add forensic evidence or an implication.

---

## THE BRIDGE PROTOCOL (Transition Rule)

Every paragraph must **lead with a transition word** that signals logical progression to the reader.

**Approved transition words:**
- Furthermore (addition, building on prior point)
- Consequently (因果 — cause → effect)
- Worse (escalation)
- Ultimately (conclusion of a line of reasoning)
- Beyond (pushing past the surface level)
- Once (temporal/conditional logic)
- Moreover (supporting evidence)
- Therefore (deductive conclusion)
- Simultaneously (parallel processes)

**Why it matters:**
- Without transitions, paragraphs are isolated "islands"
- Bridge Protocol creates smooth logical flow
- Reader can follow the argument without effort
- The alternative is choppy, stop-start reading

**The test:** Does each paragraph's first word signal how it connects to what came before?

---

## STREET-LEVEL REALISM (Tone)

Plain English that highlights the "clerical weeds" and operational reality — not consultant-speak.

**Forbidden patterns:**
- "Let me show you what actually works"
- "The reality is far more nuanced"
- "The difference isn't [X], it is [Y]" (forbidden [X] isn't [Y] pattern)
- Weak hedgers: "Most founders feel..." → be specific and assertive
- Buzzword fluency over substance

**What works:**
- Direct, aggressive imagery
- Data-driven assertions
- Founder-specific pain points named precisely
- "Street-level" not "boardroom level"

---

## NO-BOLD RULE

**Bolding is for headings and blockquote callouts ONLY.**
- Never bold percentages, keywords, or key phrases in body text
- Body bolding looks "salesy" and unprofessional
- Exception: blockquote callouts (axiom quotes at end of H2 sections)

---

## INTRODUCTION STRUCTURE (Suspend-and-Pivot Model)

**Paragraph 1 (The Allure):** Acknowledge the "instant win" promise. Name-drop the alternatives the reader is considering. Build recognition.

**Paragraph 2 (The Air of Mystery):** Pivot to the hint of hidden failure. Signal that the obvious solution has a catch — without giving away the answer. Build tension.

**The error:** Giving away the solution in paragraph 1. Killing the tension before it can build.

---

## CALLOUT PROTOCOL

End every H2 section with a provocative axiom in a blockquote.
- The axiom should distill the section's core insight
- It should be quotable — something a reader would screenshot
- Format: `> "Exact quote text."`

Example:
> "In an unmanaged sales engine, activity is a mask for inefficiency; more dials do not equal more dollars if the discovery is dead."

---

## THE 5 ESSENTIAL QUESTIONS BEFORE PUBLISHING

(For editor review of any draft)

1. **Paragraph density:** Are all paragraphs 4-6 sentences? Does each one earn its length?
2. **Bridge protocol:** Does each paragraph lead with a transition word? Do the transitions form a logical chain?
3. **Street-level realism:** Does it sound like an operator wrote it, not a content farm?
4. **No bold in body:** Are there any stray bolds outside headings and blockquotes?
5. **Callout check:** Does every H2 end with a blockquote axiom?

---

## APPLICATION TO NAVA CONTENT

These rules apply to Nava LinkedIn posts and blog articles:
- 4-6 sentence paragraphs minimum (no 1-liners, no 2-3 sentence "thin" paragraphs)
- Every paragraph leads with a transition word (Furthermore, Consequently, Worse, etc.)
- Bold = narrative pivot ONLY, not emphasis within body text
- No em-dashes (per Tiny's rule — use commas, semicolons, or separate sentences)
- Flowing prose over structured lists/bullets in post body
- Grounded claims: never say "we tried X" unless it actually happened

---

## WHAT THE CUSTOMGPT GOT WRONG (Editorial Failure Analysis)
### Source: HumanizedGemini.html — Full editing session log

The CustomGPT made consistent, predictable errors throughout the session. These are not random — they reflect how AI writing tools think, and they are the specific failure modes the editor skill must prevent.

---

### FAILURE 1: Hallucinating Supporting Content
**What happened:** The CustomGPT invented two AbroadWorks articles ("The Upwork Trap" and "The Fiverr Illusion") that don't exist. When presented with actual article links, it couldn't distinguish between real content and its own confabulation.

**The lesson:** AI will fill gaps in its knowledge with confident fabrications rather than admit uncertainty. The editor skill must:
- Never trust the AI's recall of specific existing content
- Always verify against the actual corpus before referencing prior articles
- Flag any "I've seen this article" claims as needing verification

---

### FAILURE 2: Assuming Human Edits Were Errors
**What happened:** When Tiny made deliberate cuts or changes, the CustomGPT flagged them as "omissions" and asked if they were intentional. It couldn't tell the difference between a deliberate choice and an accidental deletion.

**The lesson:** The editor skill must recognize deliberate structural changes as valid editorial decisions, not anomalies to question. Specific signals:
- If a paragraph is shorter than the 2x4-6 minimum, don't ask "did you mean to cut this?" — ask "do you want me to expand this or is the compression intentional?"
- If a story/anecdote is removed, don't flag it — the author's compression instincts are valid
- Tiny's cuts are almost always deliberate: he is killing darlings efficiently

---

### FAILURE 3: Tone Miscalibration
**What happened:** The CustomGPT kept proposing "ultimate guide" framing (soft, helpful) when Tiny wanted contrarian positioning (strategic, challenging). Even after explicit pushback, it oscillated between the two registers.

**The lesson:** When Tiny says "I don't like this direction," the skill must immediately abandon that register entirely and propose alternatives in a different voice. Do not:
- Revise the same idea with minor word swaps
- Explain why the original was good
- Offer alternatives in the same rejected tone

---

### FAILURE 4: Confirmation Bias Blindness
**What happened:** The CustomGPT proposed angles Tiny hadn't considered, but framed them as validation rather than expansion. It reinforced what it thought Tiny wanted to hear rather than genuinely stress-testing the thesis.

**The lesson:** The skill must actively surface the counter-position before drafting. Specifically:
- Before any H2 structure is finalized, state the strongest argument AGAINST the article's thesis
- If the article argues "freelancers are a risk," the editor must articulate "when freelancers are actually the right choice"
- This isn't hedging — it's editorial rigor that makes the final argument stronger

---

### FAILURE 5: Keyword Overload
**What happened:** The CustomGPT stuffed keywords into H1s in ways that sounded mechanical ("Freelance Administrative Assistant: The Ultimate Guide for Growing Businesses") rather than organic.

**The lesson:** Keywords belong in the article body, naturally integrated. The H1 must work as prose first; keyword placement is secondary. Better: "What if your freelance administrative assistant was secretly working for three competitors?" — keyword present but buried in a question that creates tension.

---

## WHAT TINY DID MANUALLY (Editorial Signature)

The HumanizedGemini.html session shows exactly what Tiny does without the GPT's input. These are the signature moves:

---

### MOVE 1: Kill the Hype, Keep the Data
Tiny stripped the "instant win" framing from the intro and replaced it with forensic urgency. Where the GPT offered false promise ("Marketplaces look like an easy fix"), Tiny wrote the actual consequence ("they often hide a messy reality that only becomes apparent once growth hits a wall").

**Pattern:** Replace benefit language with consequence language. Not "save money" — "avoid the specific failure mode that costs more than you save."

---

### MOVE 2: Hard Section Headlines
The GPT proposed soft headers. Tiny's revisions are sharp and specific:
- GPT: "The Management Burden of a Freelance Administrative Assistant"
- Tiny-approved: "The Executive Focus Penalty"

**Pattern:** Section headers should name the specific cost, not describe the topic. "Penalty," "Drift," "Gap," "Paradox" — each signals a failure mode.

---

### MOVE 3: The Black Box Principle
The recurring theme across both articles (Outsource Sales Rep and Freelance Admin) is the "black box" metaphor — systems that look safe from outside but contain uncontrolled risk inside.

**Pattern:** Every AbroadWorks article should identify a black box in the reader's current approach — the hidden interior that contradicts the safe exterior.

---

### MOVE 4: The 15% Threshold
From the Freelance Admin research: "a 15% to 20% conversation fail rate caused by cultural misalignment." This number anchors the abstract "trust signals" discussion in forensic reality.

**Pattern:** Every major claim needs a specific number or mechanism. "Cultural misalignment" is abstract; "15% of conversations fail due to linguistic warmth mismatch" is concrete.

---

### MOVE 5: Manual Paragraph Compression
Tiny repeatedly cut paragraphs to 2-3 sentences where the GPT had expanded to 4-6. This suggests the 2x4-6 rule has an exception: **when the compression is deliberate rhythmic choice**.

**Revised rule:** Aim for 4-6 sentences. If a paragraph is shorter, confirm with "expand or intentional?" before flagging as thin.

---

### MOVE 6: The Moral Observation (Visa Pathway, 2026-04-02)
From the EB-3 vs TN article: A GPT-generated article will sanitize everything — including the uncomfortable truths. Tiny keeps the paragraph about premium processing ("it feels bizarre to have such an option when considering that the roles in question are often a matter of life and death") because the discomfort IS the point.

**Pattern:** When something is uncomfortable-but-true, don't smooth it over. The friction is often the most credible thing in the piece. If the editor is uncomfortable saying something, that's usually a signal it's worth keeping — not cutting.

---

### MOVE 7: Scoping the Example Correctly
CustomGem defaulted to "LTC facility" as the framing. Tiny broadened it to "300-bed acute care hospital running both tracks." More realistic, less niche.

**Pattern:** Don't let the AI default to the most extreme/specific example. Push toward the reader's actual context. "A 300-bed acute care hospital" is more useful than "an LTC facility" for a general recruitment audience.

---

### MOVE 8: Precision on Dates
GPTs write vague temporal references ("recently," "in recent years"). Tiny sharpens to "Early 2026" when the specific timing matters to the argument.

**Pattern:** Every temporal reference should be as specific as the argument requires. "Recently" is a cop-out; "Early 2026" or "Q1 2026" is credible.

---

### MOVE 9: Socialite Extroverts — The Edgy Joke Test
When Tiny keeps something that sounds like a joke ("socialite extroverts"), the editor should not ask "are you sure?" The joke was stress-tested and kept deliberately.

**Pattern:** If Tiny keeps an edgy or unusual phrase, assume it's a deliberate stylistic choice under consideration. Do not question it — the burden is on the editor to prove it doesn't work, not on Tiny to justify keeping it.

---

### MOVE 10: Financial Estimates — Trust the Lower Number
When comparing AI-generated financial estimates against Tiny's manual revisions, Tiny's numbers are typically lower and more grounded. CustomGem inflates; Tiny deflates to realistic range.

**Pattern:** When Tiny revises financial figures downward, accept the revision as the more credible number. CustomGem optimizes for "impressive-sounding"; Tiny optimizes for "defensible under scrutiny."

---

## EDITORIAL PROCESS — HOW TINY WORKS

When Tiny gives you a document to review, the workflow is:

1. **You read the full piece** and give him a scored verdict (e.g., 8/10) with the top 3 specific issues
2. **He fixes them manually** — he doesn't want you to revise; he revises
3. **He gives you the final link** — the published or near-final version

**The three types of issues Tiny fixes himself:**
- Missing contextual explanation (reader setup) — "Non-immigrant intent needs a one-line setup"
- Structural clarity — "This section needs an intro paragraph explaining where the five variables come from"
- Technical precision — "Dates for Filing = Current" needs plain-English parenthetical

**What Tiny expects from you:**
- Editorial verdict first (score + top issues)
- Don't fix — identify
- Be specific: "the second sentence of paragraph 3 is doing too much work" not "the pacing could be tighter"

**What you should NOT do:**
- Don't produce a marked-up version with inline corrections
- Don't offer three alternative rewrites of the problem section
- Don't re-read the document back to him sentence by sentence

---

## TECHNICAL CONTENT — EDITORIAL DIFFERENCES

The Visa Pathway Comparison (EB-3 vs TN) is strategic/technical content — different weightings than creative blog posts:

**What changes in technical content:**
- 4-6 sentence paragraphs still apply, but "consequence framing" becomes "specific cost/benefit framing"
- Street-level realism = naming actual price ranges ($7k-$15k TN all-in, $25k-$35k EB-3 all-in)
- The moral observation paragraph (premium processing) is NOT softened — discomfort is the credibility signal
- Financial estimates should be deflated (see Move 10), not inflated to impress
- Examples should be realistic operational scope ("300-bed acute care hospital"), not edge cases

**What stays the same:**
- No em-dashes
- No bold in body
- Every paragraph leads with a transition word
- No one-liners — flowing prose
- Keywords naturally integrated, not forced into headings

---

## THE THREE REMAINING ITEMS (from v5.md editorial pass)

These were the issues I flagged in Visa Pathway Comparison v5.md that the ODT (Tiny's current draft) resolved. They are the pattern for what Tiny fixes manually:

1. **"Dates for Filing = Current"** — first mention needs a parenthetical explaining what it means in plain English
2. **Five H2 sections need an intro** — the Five Variables must be explained as a group before the individual breakdowns
3. **"Non-immigrant intent"** — needs brief setup for readers unfamiliar with immigration law

These are not style issues — they are reader-assumption gaps. Tiny fills them from the outside.

---

## THE COMPLETE EDITORIAL PRINCIPLES (Final)

### Structural
1. **2x4-6 Rule:** Every H3 = exactly 2 paragraphs, each 4-6 sentences
2. **Bridge Protocol:** Every paragraph leads with a transition word
3. **No bold in body:** Headings and blockquotes only
4. **Blockquotes:** Every H2 ends with a provocative axiom

### Tonal
5. **Street-Level Realism:** Plain English, operator voice, "clerical weeds" not consultant-speak
6. **Consequence framing:** Replace benefit language with specific failure modes
7. **No em-dashes:** Use commas, semicolons, or separate sentences
8. **No "Trap" or "Tax" terminology:** Use "penalty," "burden," "drift," "gap," "paradox"

### Argumentative
9. **Suspend-and-Pivot intro:** Paragraph 1 acknowledges the promise; Paragraph 2 reveals the hidden cost
10. **Acknowledge the counter-position:** State the strongest argument against your thesis before proving it wrong
11. **Keywords:** Naturally integrated in body, not forced into headings
12. **Math anchors:** Every major claim supported by specific numbers or mechanisms

### Process
13. **Verify before referencing:** Never cite a prior article without checking the actual corpus
14. **Don't question deliberate cuts:** If content is missing, ask "expand or intentional?" not "did you mean to cut this?"
15. **Propose in a new voice:** When Tiny rejects a direction, abandon that register entirely — don't revise with minor word swaps

---

*HumanizedGemini.html session analyzed: 2026-04-01*
*ODT editorial pass analyzed: 2026-04-02 (Visa Pathway Comparison — EB-3 vs TN)*
*Key files cross-referenced:*
- `Updated_ Outsource Sales Rep.md` (final output)
- `Final_ Outsource Sales Rep Guide.md` (near-final)
- `Outsource Sales Rep Guide.md` (earlier draft)
- `Forensic Critique and Strategic Recovery Plan 2.md` (Draft 3-4 analysis)
- `Forensic Critique and Strategic Recovery_ Outsource Sales Rep.md` (Draft 2 analysis)
- `HumanizedGemini.html` (full editing session log — CustomGPT internal monologue + Tiny's overrides)*
