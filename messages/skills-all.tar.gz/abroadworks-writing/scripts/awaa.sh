#!/bin/bash

# AWAA (AbroadWorks Article Architect) Execution Script
# Creates an isolated agent instance with the AWAA system prompt

# Default values
AGENT_DIR="/home/tiny4lurv/.openclaw/workspace/awaa-writer"
AGENT_NAME="awaa-agent"
MODEL="ollama/nemotron-3-super:cloud"

# Parse command line arguments
while [[ $# -gt 0 ]]; do
  case $1 in
    --model)
      MODEL="$2"
      shift 2
      ;;
    *)  # If it's not an option, it's the start of the task
      break
      ;;
  esac
done

# Remaining arguments form the task description
TASK="$*"

# If no task provided, show help
if [[ -z "$TASK" ]]; then
  echo "AWAA - AbroadWorks Article Architect"
  echo ""
  echo "Usage: $0 [options] \"TASK DESCRIPTION\""
  echo ""
  echo "Options:"
  echo "  --model MODEL     LLM model to use (default: ollama/nemotron-3-super:cloud)"
  echo ""
  echo "Examples:"
  echo "  $0 \"Write an article about offshore bookkeeping benefits\""
  echo "  $0 --model ollama/gemma3:27b-cloud \"Create H1 options for virtual staffing topic\""
  echo ""
  exit 1
fi

# Create the isolated AWAA agent
echo "🚀 Creating AWAA agent..."
echo ""

# Remove existing agent directory if it exists
if [ -d "$AGENT_DIR" ]; then
  echo "🗑️  Removing existing AWAA agent directory..."
  rm -rf "$AGENT_DIR"
fi

openclaw agents add \
  "$AGENT_NAME" \
  --model "$MODEL" \
  --workspace "/home/tiny4lurv/.openclaw/workspace" \
  --agent-dir "$AGENT_DIR"

echo ""
echo "✅ AWAA agent created at: $AGENT_DIR"
echo ""
echo "To interact with AWAA:"
echo "  openclaw message send --target '$AGENT_DIR' -m '<your message>'"
echo ""
echo "Example:"
echo "  openclaw message send --target '$AGENT_DIR' -m 'You are AWAA. $TASK'"
echo ""
echo "💡 Begin by asking your clarifying questions about the topic and current workflow phase."