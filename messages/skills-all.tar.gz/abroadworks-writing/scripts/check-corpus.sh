#!/bin/bash

# Simple corpus checker for AbroadWorks content
# Scans the clean_md directory for article topics and metadata

CORPUS_DIR="/home/tiny4lurv/.openclaw/workspace/rag_abroadworks/clean_md"

echo "📊 AbroadWorks Corpus Analysis"
echo "=============================="
echo ""

if [[ ! -d "$CORPUS_DIR" ]]; then
  echo "❌ Corpus directory not found: $CORPUS_DIR"
  exit 1
fi

# Count total articles
TOTAL_COUNT=$(find "$CORPUS_DIR" -name "*.md" -type f | wc -l)
echo "📄 Total articles in corpus: $TOTAL_COUNT"
echo ""

# Show recent articles
echo "📰 Recent articles (by modification time):"
echo "----------------------------------------"
find "$CORPUS_DIR" -name "*.md" -type f -printf "%T@ %f\n" 2>/dev/null | sort -nr | head -10 | while read -r timestamp filename; do
  date=$(date -d "@${timestamp%.*}" "+%Y-%m-%d %H:%M" 2>/dev/null || echo "unknown date")
  echo "  $date - $filename"
done
echo ""

# Show authors.txt if it exists
if [[ -f "$CORPUS_DIR/authors.txt" ]]; then
  echo "👥 Authors in corpus:"
  echo "---------------------"
  cat "$CORPUS_DIR/authors.txt"
  echo ""
fi

# Show some sample titles
echo "📋 Sample article titles:"
echo "-------------------------"
find "$CORPUS_DIR" -name "*.md" -type f -exec basename {} .md \; | head -10 | sed 's/-/ /g' | sed 's/\b\(.\)/\u\1/g'
echo ""

echo "💡 To get detailed analysis of a specific article, use:"
echo "   openclaw read <path-to-article>"
echo ""
echo "💡 To run AWAA on a topic from the corpus:"
echo "   ./awaa.sh \"Write article about [topic from corpus]\""