# AbroadWorks Writing Skill

This skill enables the creation of AWAA (AbroadWorks Article Architect) - a specialized writing agent that produces blog articles following the AbroadWorks Editorial SOPs and Content Architect methodology.

## Components

- `awaa-system-prompt.md` - The core AWAA agent instructions
- `SKILL.md` - Documentation on how to use this skill
- `scripts/awaa.sh` - Execution script to spawn AWAA sessions
- `scripts/check-corpus.sh` - Utility to examine the AbroadWorks corpus

## Usage

### Spawn an AWAA session:
```bash
./awaa.sh "Write an article about the benefits of offshore bookkeeping for startups"
```

### With custom options:
```bash
./awaa.sh --model ollama/gemma3:27b-cloud --timeout 7200 "Create H1 options for virtual staffing topic"
```

### Check the corpus:
```bash
./check-corpus.sh
```

## Methodology

AWAA follows the strict 5-phase workflow from AbroadWorks Session Rules:
1. **Phase 1**: Present 3-4 H1 options for approval (keyword must appear in H1)
2. **Phase 2**: Propose H2 structure (Problem → Agitation → Solution)
3. **Phase 3**: Propose H3 sub-headings with main ideas (3 H3s per H2)
4. **Phase 4**: Expand outline to include main idea of every paragraph (2x4-6 rule)
5. **Phase 5**: Write full article only after paragraph-level ideas are approved

## Constraints Enforced

- No self-references ("This section...", "In this article...")
- Strict 3-phase workflow (Problem → Agitation → Solution)
- Target 1,800-2,500 words
- No em-dashes or en-dashes
- Periods after close-quotes
- No needless capitalization of concepts
- Bold = headings and callouts only (never in body text)
- Every H3: exactly 2 paragraphs, 4-6 sentences each
- Every paragraph (except first in section): leads with transition word/phrase
- Every H2: intro paragraph + transition sentence to H3s
- Every H2 section: concludes with bold/italicized callout quote (> "**Quote**")
- Article ends with 3 distinct FAQs (no repeated math/figures from body)
- Primary keyword in: H1, intro first paragraph, at least one H2, conclusion
- Natural keyword integration only (semantic variations throughout)
- No statistical claims without sources in provided documents
- No "internal knowledge" language
- All URLs must be direct from source documents
- Math shown for all figures (e.g., $150/hr x 15 hrs = $117k)
- Suspend-and-pivot model followed in introduction
- Final CTA explicitly positions AbroadWorks as solution
- Internal links woven seamlessly into narrative

## Corpus Location

The AbroadWorks article corpus is located at:
`/home/tiny4lurv/.openclaw/workspace/rag_abroadworks/clean_md/`

## Related Skills

- `nava-writing` - For Nava Healthcare content creation
- `linkedin-writer` - For LinkedIn post creation
- `visible-browser` - For browser automation tasks