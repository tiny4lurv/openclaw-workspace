---
name: deep-research-prompt
description: Generate research briefs for Gemini deep research. Use when Tiny gives you a topic and asks for a deep research prompt. Produces an internal research document — factual, source-backed, no marketing language, no internal context leaked.
---

# Deep Research Prompt Generator

## When to Use This Skill

Use when Tiny gives you a topic and asks you to generate a deep research prompt for Gemini deep research. The output is a research brief — factual, source-backed, and for internal eyes only.

**Prerequisite:** Do your own preliminary research first (Step 1). Not optional.

---

## The Process

### Step 1 — Preliminary Research (Mandatory)

Before drafting the prompt, do light research:
- `web_search` for key terms, statistics, major players
- `web_fetch` on relevant-looking pages
- RAG corpus check for related content already in the workspace
- `web_search` on key jurisdictional or topic-specific government sources

Goal: know the terminology, major sub-topics, credible source types, and what a reader would already know.

---

### Step 2 — Draft the Prompt

The prompt has four parts. That's all:

**1. Topic statement** — what the research is about
**2. Sub-questions** — the specific things to investigate (bullet list)
**3. Source types** — what to prioritize (government, legal, industry)
**4. What to surface** — concrete data points, numbers, case outcomes, jurisdictional specifics

**Hard rules:**
- No mention of audience, tone, format, or how the output should be structured
- No internal references (AWAA, NavaAA, "the client", "our blog", "our article")
- No preferred conclusions — don't encode what you want the article to say
- International scope only if the topic warrants it — don't add it by default
- Sub-questions should be specific enough to produce actionable facts, not vague directions

**Example of what TO say:**
"Non-compete enforceability for independent contractors in the US — state-by-state bans and restrictions, income thresholds, the classification risk problem"

**Example of what NOT to say:**
"This research will inform an article for our blog about why businesses need managed contractor solutions" — this leaks the angle

---

### Step 3 — Deliver

Present the prompt. Ask if scope or emphasis needs adjustment. Don't finalize until Tiny approves.

---

## What the Output Looks Like

Gemini produces a raw research document. The format is Gemini's to decide — don't specify it. What matters is:
- Factual claims with inline sources
- Concrete data (numbers, thresholds, case outcomes)
- Jurisdictional specifics
- Source quality noted where relevant

Use the output to draft. The research is not the article.

---

## Key Principles

- **No confirmation bias** — don't design sub-questions that seek evidence for a predetermined conclusion
- **Facts lead** — surface what is true, not what supports a thesis
- **Specificity over breadth** — better to answer 10 narrow questions well than 1 vague one
- **Source quality matters** — government and legal primary; law firm client alerts are tertiary at best
- **International only if warranted** — check before adding UK/EU/Australia dimensions
