# Deep Research Prompt — Core Principles

## The Goal

A deep research prompt produces a **Statement of Trade (SoT)**: a factual, source-backed research document that serves as the foundation for a Nava article. The SoT is not the article. It is raw material — organized, sourced, substantive — from which Tiny or NavaAA will later construct a narrative.

## The Mindset

Think of yourself as a research editor at a trade publication, not a content marketer. You are assembling a briefing for a senior reporter who needs to understand the full landscape before writing a single word of copy.

**Questions you are not allowed to ask the data:**
- "Show me why X is better than Y"
- "Find evidence that supports Z"
- "What are the advantages of X?"

**Questions you are allowed to ask the data:**
- "What is the current state of X?"
- "What do credible sources say about X, including any disagreements or tensions?"
- "What statistics, timelines, and real-world data points are relevant to understanding X?"
- "What are the known complexities and tradeoffs?"
- "What is contested, and what is well-established?"
- "What related adjacent information is useful for understanding X in context?"

## Source Quality Hierarchy

Use this to evaluate what goes into the SoT:

| Tier | Source Type | Examples | Notes |
|------|-------------|----------|-------|
| 1 | Government / official agencies | USCIS, DOL, WHO, BLS, CDC, state DOHs | Primary data, official statistics |
| 1 | Industry associations | AHCA, LeadingAge, NSNA, AONL | Peer-reviewed position papers, surveys |
| 2 | Academic / peer-reviewed | PubMed, JSTOR, industry journals | Good for clinical/operational data |
| 2 | Established trade publications | Modern Healthcare, Becker's, Health Affairs | Journalistic rigor, fact-checked |
| 3 | Industry reports | Mercer, McKinsey, Deloitte, Korn Ferry | Useful but often proprietary |
| 4 | Supplier/vendor content | Staffing firms, recruiting agencies, SaaS vendors | Exclude as primary source; ok as secondary if verified |
| 5 | General web / blogs | Anonymous blogs, unverified articles | Exclude unless nothing else available |

**Rule:** If you cannot verify a claim with a Tier 1-2 source, flag it as unverified and note it separately.

## Prompt Language Guide

### Neutral Framing Examples

| ❌ Leaks conclusion | ✅ Neutral |
|--------------------|-----------|
| "Why EB-3 visas are failing healthcare recruitment" | "The use of employment-based visas in healthcare staffing: current state, processing times, and employer experiences" |
| "The benefits of TN visas over EB-3" | "TN visas and EB-3 visas: comparative analysis of processing timelines, eligibility requirements, and strategic use cases in healthcare staffing" |
| "How visa reform will solve the nursing shortage" | "The relationship between immigration visa pathways and healthcare workforce availability: what the data shows" |

### What "Neutral" Means in Practice

- **Do not use:** advantage, benefit, problem, challenge, solution, fix, better, worse, winning, losing, success, failure — as framing devices
- **Do use:** landscape, state of, current picture, data shows, evidence suggests, sources indicate, comparative analysis, tradeoffs, considerations
- **The goal:** describe the terrain, not grade it

### Phrases That Leak Conclusions

Avoid these patterns:
- "the benefits of [X]" — implies X is good
- "why [X] is broken" — implies X is broken
- "how to solve [X]" — implies X is a problem with a solution
- "[X] vs [Y]: why [X] wins" — already decided the winner
- "the truth about [X]" — implies there's a lie being corrected
- "everything you need to know about [X]" — implies completeness when we don't know what's relevant yet

## The Five Rules (Summary)

1. **Sources first** — specific types, credible quality, verifiable
2. **Facts over opinions** — data, statistics, real-world outcomes; forecasts acceptable, hot takes not
3. **Neutral framing** — no predetermined conclusions, no thesis leaked into the prompt
4. **Broad scope** — adjacent areas, related tradeoffs, complexities; don't narrow prematurely
5. **Authority, not marketing** — substantive, professionally written, credible to a skeptical audience

## What the SoT Is NOT

- It is **not** a LinkedIn post or article draft
- It is **not** a sales enablement document
- It is **not** a pros/cons list with recommendations
- It is **not** written in the Nava voice (that comes later)
- It does **not** have a thesis or H1 — those emerge from the data

## Workflow Recap

1. User gives topic/theme → preliminary research (web search, RAG check)
2. Draft prompt using principles above → present to user
3. User approves or adjusts → prompt goes to Gemini Deep Research
4. Gemini produces SoT → Tiny reviews → approves or sends back for revision
5. Approved SoT → NavaAA (Article Architect) for annotated outline → draft → Nava voice

## Example: TN Visa / EB-3 Prompt Framing

**Topic given:** "Yosef says Nava is pivoting from EB-3 to TN visas. EB-3 timelines are getting longer. TN is faster but only for Canadians/Mexicans. EB-3 still needed for Filipinos."

**Wrong prompt framing:**
> "Write a report on the benefits of TN visas for healthcare recruitment and why they are better than EB-3 visas."

**Correct prompt framing:**
> "Analyze the use of TN (Treaty Trader/Treaty Investor) visas and EB-3 employment-based immigrant visas in the US healthcare staffing sector. Cover: (1) current processing timelines and recent trends for each pathway; (2) eligibility requirements and restrictions; (3) strategic considerations for healthcare employers using each route; (4) the interaction between visa pathways and healthcare workforce supply, particularly in long-term care settings. Prioritize official government sources, peer-reviewed research, and established healthcare industry publications. Note any significant timeline changes, policy shifts, or data quality concerns in the available evidence."

**Why the correct version works:**
- No predetermined conclusion ("TN is better")
- Identifies both pathways symmetrically
- Includes "strategic considerations" rather than "advantages"
- Notes the healthcare workforce supply angle without framing it as a "problem"
- Sources are specified (government, peer-reviewed, industry publications)
- The phrase "recent trends" invites current data, not historical assertion
