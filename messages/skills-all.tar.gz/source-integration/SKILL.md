---
name: source-integration
description: "Find and embed relevant external sources and internal cross-links into AW article content. Use when instructed to add citations to an article, embed links, or prepare an article for publication. Triggers on: add citations, embed links, source integration, cross-links, bibliography. Not for initial research — this is embedding citations into a near-final draft."
---

# Source Integration Skill

Embed 5 external sources + up to 10 internal cross-links into an AW article. Task 2 (external) and Task 3 (internal cross-links) combined.

---

## Step 1 — Identify External Sources

Source = SoT bibliography entry or other cited research document.

**Rules:**
- Each external source must directly support a claim in the article
- Sources must be from the SoT bibliography or other credible source
- Minimum: 5 sources. Maximum: 8 unless article requires more
- External link anchors: embed at first use of the supported claim

**External source format:**
```markdown
[descriptive anchor text, 4 words max](https://source-url.com)
```

**Example:**
> California's non-compete ban [has been on the books since 1872](https://eig.org/state-noncompete-map/) and consistently enforced by state courts.

The anchor text is a natural phrase in the sentence, not the URL or a generic "click here."

---

## Step 2 — Identify Internal Cross-Links

Internal cross-links = other AW blog articles on related topics.

**Rules:**
- Links must be to confirmed-live URLs (test before embedding)
- Maximum 10 cross-links per article
- Place cross-links in body sections where the reader would naturally want to read more

**Finding live URLs:**
- Base URL: `https://www.abroadworks.com/blog/`
- Slug = article filename (minus `.md`) from RAG corpus
- Test with `web_fetch` — confirm status 200 before embedding
- If 404: search `site:abroadworks.com/blog` for correct slug

**Current confirmed live AW articles (from RAG corpus):**
1. `7-figure-contractor-risk-employer-of-record-eor` — https://www.abroadworks.com/blog/7-figure-contractor-risk-employer-of-record-eor
2. `bookkeeper-risk` — https://www.abroadworks.com/blog/bookkeeper-risk
3. `outsourcing-vs-offshoring` — https://www.abroadworks.com/blog/outsourcing-vs-offshoring
4. `async-work` — https://www.abroadworks.com/blog/async-work
5. `outsourcing-customer-care` — https://www.abroadworks.com/blog/outsourcing-customer-care
6. `offshore-vs-local-labor` — https://www.abroadworks.com/blog/offshore-vs-local-labor
7. `ai-customer-service-trap` — https://www.abroadworks.com/blog/ai-customer-service-trap
8. `offshore-bookkeeping` — https://www.abroadworks.com/blog/offshore-bookkeeping
9. `outsourcing-popularity` — https://www.abroadworks.com/blog/outsourcing-popularity

**Do not link to:** articles not yet published, draft articles, or the current article itself.

---

## Step 3 — Anchor Text: Natural, Not Promotional

**THE GOLDEN RULE: Link phrases, not titles.**

Anchor text must be a natural part of the sentence. The reader should not feel the insertion. The sentence must read normally whether the link is there or not.

**Correct anchor text:**
- "serious consequences" — a natural phrase in the sentence
- "evidence of economic dependence" — flows from the paragraph's argument
- "the geographic patchwork of offshoring versus local hiring" — descriptive phrase embedded in the text

**Incorrect anchor text (article titles forced into sentences):**
- "Outsourcing versus Offshoring — Finding the Shortcut to a Leaner Business"
- "The 7-Figure Contractor Risk: Why You Need an EOR"
- "A Cheat Code to Elevate Your Business"

**Examples:**

Correct:
> This matters because misclassification carries its own **serious consequences** [that are independent of whatever breach the non-compete was meant to address](https://www.abroadworks.com/blog/7-figure-contractor-risk-employer-of-record-eor).

Incorrect:
> [Outsourcing versus Offshoring — Finding the Shortcut to a Leaner Business](https://www.abroadworks.com/blog/outsourcing-vs-offshoring) is the context most miss.

Correct:
> The [geographic patchwork of offshoring versus local hiring](https://www.abroadworks.com/blog/outsourcing-vs-offshoring) compounds this.

Incorrect:
> [Why US Companies Are Increasingly Outsourcing in 2026](https://www.abroadworks.com/blog/outsourcing-popularity) reflects the scale of this shift.

**Max anchor text:** 4 words for anchor text itself (the linked phrase). The broader sentence context can be longer.

---

## Step 4 — Embed Links

**Internal cross-link format:**
```markdown
[natural phrase in the sentence](https://www.abroadworks.com/blog/slug)
```

**Placement rules:**
- Embed inline where the concept is being discussed
- Not as standalone sentences introducing the link
- Not as "here" or "click here" anchors
- External sources: at first supported claim, not every mention
- Cross-links: at the paragraph where reader would naturally want more

---

## External Source List — NC Article (reference)

1. State Noncompete Law Tracker — https://eig.org/state-noncompete-map/
2. IRS Employee (common-law employee) — https://www.irs.gov/businesses/small-businesses-self-employed/employee-common-law-employee
3. IRS Topic No. 762 — https://www.irs.gov/taxtopics/tc762
4. Non-Compete Agreements in Ontario — https://achkarlaw.com/insights/ontario/non-compete-agreements-explained/
5. Spilling Secrets: 2025 Non-Compete Year in Review — https://www.ebglaw.com/insights/podcasts/spilling-secrets-2025-non-compete-year-in-review