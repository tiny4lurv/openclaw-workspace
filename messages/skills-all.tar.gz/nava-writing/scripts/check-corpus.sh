#!/bin/bash
# check-corpus.sh — Enhanced Gap Analysis Tool for Nava Corpus

CORPUS_DIR="/home/tiny4lurv/.openclaw/workspace/nava-corpus"
BLOG_DIR="/home/tiny4lurv/.openclaw/workspace/rag/clean_txt"
LAST_UPDATED_FILE="/home/tiny4lurv/.openclaw/workspace/rag/last_updated.txt"

# Check for and store last index update timestamp
if [ ! -f "$LAST_UPDATED_FILE" ]; then
    echo "$(date -u +%Y%m%d_%H:%M:%S)" > "$LAST_UPDATED_FILE"
fi
LAST_UPDATE="$(cat "$LAST_UPDATED_FILE")"

echo "=== LINKEDIN/X CORPUS ==="
echo "LinkedIn posts: $(wc -l < "$CORPUS_DIR/linkedin-posts.md") lines"
echo "X posts: $(wc -l < "$CORPUS_DIR/x-posts.md") lines"
echo ""
echo "=== BLOG CORPUS ==="
echo "Total articles: $(ls "$BLOG_DIR" | wc -l)"
echo ""

# Accept input: concept, SoT, or outline to evaluate against corpus
INPUT="$1"
if [ -z "$INPUT" ]; then
    echo "Error: No input provided. Please provide a concept, SoT, or outline to evaluate." >&2
    exit 1
fi

# Use RAG query to check semantic similarity against corpus
# Output: JSON with query, results array, and metadata
RESULTS_JSON=$(python3 /home/tiny4lurv/.openclaw/workspace/rag/index/query_rag.py \
    "$INPUT" \
    --mode hybrid \
    -k 5 \
    --source both \
    2>/dev/null)

# Parse and process results
if [ -z "$RESULTS_JSON" ] || [ "$RESULTS_JSON" = "null" ]; then
    echo "Error: RAG query failed or returned no results." >&2
    exit 1
fi

# Output similarity scores and matched documents above threshold (0.8)
echo "$RESULTS_JSON" | jq -r '
    .results[] | 
    select(.score >= 0.8) | 
    "Score: \(.score) | Matched: \(.id) | Path: \(.path)"
'

# Suggest variations to avoid repetition (from lower-scoring matches)
echo "$RESULTS_JSON" | jq -r '
    .results[] | 
    select(.score < 0.8) | 
    "Consider angle " + .id + " or alternative to avoid repetition"
'

# Corpus freshness check
CURRENT_TIMESTAMP="$(date -u +%Y%m%d_%H:%M:%S)"
if [ "$CURRENT_TIMESTAMP" != "$LAST_UPDATE" ]; then
    echo "Warning: Corpus may be outdated — last updated $LAST_UPDATE, current $CURRENT_TIMESTAMP"
fi

