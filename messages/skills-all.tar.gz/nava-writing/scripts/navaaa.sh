#!/bin/bash
# navaaa.sh — Start a NavaAA writing session
# Usage: bash navaaa.sh [topic]

TOPIC="${1:-}"

if [ -z "$TOPIC" ]; then
  echo "Usage: bash navaaa.sh <topic>"
  exit 1
fi

echo "Starting isolated NavaAA agent for topic: $TOPIC"
echo ""
echo "Creating agent..."

# Create the isolated NavaAA agent
openclaw agents add \
  --model "minimax-m2.7:cloud" \
  --workspace "/home/tiny4lurv/.openclaw/workspace" \
  --agent-dir "/home/tiny4lurv/.openclaw/workspace/navaaa-writer"

echo ""
echo "NavaAA agent created. To interact with it:"
echo "  openclaw message send --target /home/tiny4lurv/.openclaw/workspace/navaaa-writer '<your message>'"
echo ""
echo "Example:"
echo "  openclaw message send --target /home/tiny4lurv/.openclaw/workspace/navaaa-writer 'You are NavaAA. Write a LinkedIn post about: $TOPIC'"