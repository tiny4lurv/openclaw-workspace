---
name: editor
description: Use when refining AWAA or Nava content drafts, evaluating writing quality, or running a 6-pass editorial review. Covers arc/structure verification, readability sweep, brand integration, and source integration checks. Triggers on edit request, editorial review, refine draft, improve writing.
---

# Editor Skill — AWAA + Nava Content Refinement

## Purpose
This skill encodes the editorial standards and revision workflows for AbroadWorks (AWAA) and Nava Healthcare content. Use when refining drafts or evaluating writing quality.

## Foundational Principle — Articles Are Journeys, Not Reference Docs

Every article is a journey for the reader. The reader starts with an assumption — often wrong — and ends with a transformed understanding. The arc is the spine of the article. Everything serves the arc.

**The hierarchy:**
- **H1** — the thesis, what the article proves or demonstrates
- **H2s** — the acts, the chapters of the reader's transformation (Resonate → Educate → Disrupt → Convert, or whichever arc fits the argument)
- **H3s** — the scenes inside each act, the specific proof points, evidence, and details that make each section land

The structure is NOT: topic → sub-topic → details. It IS: assumption → transformation → conclusion.

Each H2 must transition the reader's understanding. The reader should never finish an H2 section wondering "why are we talking about this now?" If the section exists, it earns its place by moving the reader closer to the article's conclusion.

**Why this matters:**
- H2s without arcs → isolated islands of information, reference-doc style
- H2s with arcs → chapters in one argument, each building on the last
- The CTA at the end feels earned when the arc is right, bolted-on when the arc is missing

**The arc serves both AWAA and Nava content.** The transformation frame is universal. Nava articles use a different format (flat H2 structure, Key Takeaways, Sources section) but they still need a reader journey — a starting assumption to dismantle and a conclusion that lands differently than where the reader began.

## Outlining Phase — Validate the Bones Before Filling

**The outlining phase with NavaAA/AWAA is where repetition and noise are prevented, not fixed.**

### Structural Targets (Non-Negotiable)
- **3-4 H2s total** — this is the target range for every article. Fewer than 3 and the argument is thin. More than 4 and the reader loses the thread.
- **3-4 H3s per H2** — each H2 contains 3-4 subsections, not 2 and not 5+. This gives enough density without bloating.
- **Merge related H2s** — if H2.1 and H2.2 both deal with the same subject (e.g., non-competes), they belong under a single H2. The split should reflect a genuine narrative pivot, not topic granularity. When in doubt: fewer H2s with more H3s underneath is better than many thin H2s.
- **Split when examples warrant** — H2.3 can absorb multiple examples from the source text and break them into separate H3s. The constraint is 3-4 per H2, not a fixed number — use the range deliberately based on what the material demands.

If the underlying H2 structure (the arc) is not strong, the H3s will be generic content containers. Generic containers repeat across sections because they have no distinct job. Strong arcs produce distinct H3s because each section has a specific narrative purpose.

**Outlining workflow (mandatory before drafting):**
1. **H1** — What is the single thesis this article proves?
2. **H2 structure** — Map the reader's transformation. What does the reader believe at the start? What do they believe at the end? What are the intermediate states between those two points?
3. **H3 within each H2** — What are the specific scenes, evidence, or proof points that make each section earn its place? Each H3 should do work that no other H3 in the article does.
4. **Canvas review** — Before drafting, confirm each paragraph's job is distinct from paragraphs in adjacent sections.

**Repetition is a structural failure, not a language failure.** When the same point appears in two sections, it means one of those sections does not have a distinct job. Fix the structure first. Editing individual sentences will not fix a repetition problem that originates in the outline.

**Signal that the outline needs work:**
- Two H2 sections that could swap H3s without the article breaking
- The same stat or example appearing in two different sections
- A transition that says "now that you understand X, let's talk about Y" without Y being genuinely different from X
- H3s that are topic labels rather than specific proof points

## The Core Principle — Every Section Has a Distinct Purpose

This is the foundation of the entire editor skill.

**No two sections look and feel the same. No two subsections share the same evidence. Each one has a different job in the journey.**

If two sections feel similar, one of them doesn't belong. If two subsections could swap their content without the reader noticing, the outline is not distinct enough. If the same evidence appears in two places, one of those sections is redundant.

This is not a formatting rule. This is the internal logic of the article. The arc determines everything:
- What each section proves
- What evidence it uses
- How it transitions to the next section
- Why it comes in this order and not another

**When reviewing a draft, the core question is always:** Does this section do something no other section does? If the answer is no, cut or redirect the section.

**The test for distinct purpose:**
- Could this H3 appear in a different section and do the same work? If yes, it's not distinct.
- Does this section's evidence overlap with another section's evidence? If yes, one is redundant.
- Does this section feel the same as the section before it? If yes, one of them is filler.

Understanding this principle — truly internalizing it — is what separates editorial work from copy-editing. The editor is not polishing sentences. The editor is ensuring the argument holds together, section by section, because every section earned its place.

This is the core of the editor skill. Everything else — the structural rules, the mechanical checks, the review process — serves this principle.

Never submit a draft without running it through this review sequence. This is how you catch logical failures, not just mechanical ones.

### Step 1: Establish the Foundation
Before touching the draft, write down:
- **Who is this article for?** (the reader's starting assumption)
- **Why are we writing it?** (what belief are we changing)
- **What is the thesis?** (the single thing the article proves)
- **What is the arc?** (the reader's transformation — step by step)

### Step 2: Build the Section Checklist
For each H2 section, write down in one sentence what the section is supposed to DO:
- What does this section prove that the previous section did not?
- What assumption does it dismantle or what new information does it add?
- Where does it fit in the reader's transformation?

### Step 3: Review Each Section Against Its Purpose
As you read each section, ask:
- Does this section do what the checklist says it should?
- Does it advance the arc or does it repeat what came before?
- If this section were removed, would the reader lose something the other sections don't provide?
- Is the transition into this section earned by the previous section?

---

### The Arc Sequence — What Each Section Is Supposed to Do

**Intro / Hook** — Resonate. Bring in readers who came in with a specific assumption. Show them we understand their pain or their situation. They should see themselves in the opening.

**First H2** — Poke the first holes. Explain what the thing they came in believing actually is. Show them the gap between what they think they're getting and what the clause actually delivers. This is the first disruption.

**Subsequent H2s** — Agitate, escalate, or introduce alternatives. The reader is now questioning their original assumption. Show them why the obvious alternatives also fail. ("You think X might work instead — here's why it doesn't either.")

**Final H2(s)** — The solution. Show them what actually works. By this point, the reader has had every shortcut closed off. The solution feels earned, not bolted on.

**CTA** — The journey is complete. The reader arrived with one understanding and left with another. The CTA is the natural next step, not a pivot.

---

**None of this works without the backbone.** If the arc is wrong, no amount of sentence-level editing saves the article. The arc is the spine. The H3s, the evidence, the prose — all serve the arc. If a section doesn't have a distinct job within the arc, it doesn't belong in the article.

Every sentence must do one of two things: advance the argument or land a pivot. If a sentence does neither, it is filler and it must be cut.

Every paragraph must either introduce new information or redirect what came before. A paragraph that re-states the previous paragraph's point in different words is redundant — cut or redirect.

Every H3 subsection must prove something no other subsection in the article proves. If two H3s in different sections could be combined into one without losing anything, they should be.

**The filler tests:**

- **Sentence test**: Does this sentence add information the previous sentences did not contain? If not, cut it.
- **Paragraph test**: Would the reader understand this paragraph if they skipped the one before it? If yes, one of them is redundant.
- **Section test**: Could this H3's job be done by a different H3 in a different section? If yes, the outline is not distinct enough.

**Why filler is costly:**
- Filler dilutes the argument. When every sentence is doing work, the article is dense and persuasive. When sentences exist to fill space, the reader feels the article not earning their time.
- AI drafts are particularly prone to filler — they generate coverage rather than argument. Every paragraph that re-states a previous point is AI filler.
- The reader's trust is earned when every sentence respects their time.

**The standard Tiny applies:**
- No sentence that merely restates the previous sentence
- No paragraph that merely amplifies the previous paragraph
- No section that merely covers the same ground as another section
- When in doubt: cut the sentence. If it was doing work, the paragraph will survive without it. If it wasn't, the paragraph is stronger without it.

**Repetition is a structural failure before it is a language failure.** The editor must catch repetition at the outline level (same point in two H2s), the paragraph level (same claim in adjacent sections), and the sentence level (same word or phrase used twice in close proximity).

**Three levels of repetition to catch:**

1. **Structural repetition** — the same point made in two different H2 sections. This means one section does not have a distinct job. Fix by clarifying what each H2 section is specifically proving. If two sections could swap their H3s without the article breaking, the outline is wrong.

2. **Logical repetition** — the same claim re-stated with different words in adjacent paragraphs or sections. The test: can you identify which paragraph introduced the point and which is the echo? If yes, the echo must be cut or redirected to new information.

3. **Surface repetition** — the same word or phrase used twice in the same paragraph or in consecutive paragraphs. Read the paragraph aloud. Ears catch what eyes miss.

**The noise problem:** AI drafts are particularly prone to repetition because they optimize for coverage — they cover the same ground from slightly different angles rather than advancing. The editor must treat any repeated point as a signal that the outline is not distinct enough.

**How to eliminate repetition:**
- Every section's first sentence must be NEW information, not a restatement of what came before
- Every paragraph must add something the previous paragraphs did not say
- The same stat or example should appear in only one section
- If a transition paragraph is repeating the section that preceded it, the transition paragraph is redundant

**What to do when repetition is found:**
- Never paper over repetition with a thesaurus swap — this creates awkward, overstuffed prose
- Either cut the repeated content entirely, or redirect it to new information
- If the repetition is structural, go back to the outline and clarify each H2's distinct job

A story in an article is a logical proof, not decoration. It must be validated before the draft is considered ready.

**Before writing or replacing any story or example, confirm:**
1. What belief does this story prove wrong?
2. Is the story about the right party? (reader as employer, not client, not third party)
3. Does the outcome the reader fears connect DIRECTLY to what the article's solution actually addresses?
4. If the article says "X won't protect you from Y" — does the story actually show Y happening, not Z?

**The funnel story failure (Apr 10):**
- Original story: micro-business owner hired contractor, contractor took information to competitors after leaving
- My replacement: agency owner built funnels for a CLIENT, client replicated the work
- Problem: the client scenario is a different threat model entirely — a non-compete on a contractor does NOT prevent a client from using what they were given
- The replacement story proved nothing about the article's thesis
- This slipped through v1-v5 because there was no validation check — only structural rules

**Story logic is harder to encode than structure rules** (paragraph length, transition words) because it requires understanding the argument at a deeper level. The validation check exists precisely because story errors are not caught by format audits.

## The Hook — How the Article Opens

The hook is not decoration. It is the promise to the reader. It determines whether they keep reading or leave.

The reader arrived with a specific state of mind — a question they want answered, a problem they want solved, a belief they hold. The hook either makes them feel at home in that state, or it disrupts it in a way that makes them want to keep reading.

**Four ways to open:**

1. **Make them feel at home.** Show the reader you understand their situation, their frustration, their starting assumption. They see themselves in the opening. This works when the reader is immediately arriving at the article because of a specific pain point.

2. **Present a mystery.** Open with a scenario or a question the reader can't immediately answer. Promise them the explanation is coming. "You think X. You're wrong. Here's why." They stay to find out how.

3. **Challenge their worldview.** Open with a statement that contradicts what the reader believes. They feel the friction and read to resolve it. "The thing you think protects you actually exposes you." This works when the reader has a strong held belief that the article will change.

4. **Present context and promise a reframe.** Open with background or a market situation the reader recognizes, then signal that the conventional understanding of it is wrong. "Everyone in your industry thinks X. They're all looking at it backwards." This works when the reader needs the full article to understand why the reframe is true.

**The promise:** Whatever opening approach is used, the reader must know by the end of the first paragraph what the article is going to do for them. The hook creates momentum. The article keeps the promise.

**Example from IC Non-Compete:**
The opening story makes the reader feel at home — they recognize the fear of a contractor taking their business infrastructure. Then the article disrupts: "The non-compete you added cannot prevent this." The reader stays to find out why — and what to use instead.

## Phase 6 — Hook/Intro Evaluation Criteria (After Phase 5 Approval)

The hook/intro is a different weapon from the body prose. It runs after the full arc is known (Phase 5 complete), but it is not part of Phase 5 generation. AWAA pitches 2-3 options. The editor evaluates, refines, and presents for Tiny's final approval.

**The Phase 6 workflow:**
1. AWAA generates 2-3 hook options (2 paragraphs each), each distinct in angle
2. Editor evaluates each against the criteria below
3. Editor edits for polish and structural fit
4. Editor presents refined options to Tiny
5. Tiny approves — final discretion is Tiny's
6. Hook is prepended to Phase 5 draft as the article opener

---

### The Purpose of the Hook — Empathy Before Instruction

The hook's job is to meet the audience where they ARE, not to tell them where the article is going.

Every reader arrives in a specific emotional state — anxious, seething, uncertain, overwhelmed. The hook reflects that state back at them so they feel witnessed. Only then does the article say "come on, let's go somewhere."

**The hook meets the audience where they are.** (Emotional state at point of reading)
**The arc takes them somewhere they weren't.** (Transformation from H2.1 to conclusion)

The hook doesn't preview the arc. It resonates with the starting state. The arc is what happens after the reader thinks "yes, that's me."

**Two examples from recent articles:**

*Article 1 (firing contractors):* Hook opens with the invoice moment — that specific pause before paying, the discomfort you couldn't name. Reader thinks: "yes, that's exactly how I felt." THEN H2.1 begins the journey: "let's examine whether firing is actually the right move."

*Article 2 (IC non-compete):* Hook opens with a scenario where a contractor sold business secrets to a competitor. Reader thinks: "I'm sitting here shaking in my boots, is my non-compete even worth anything?" THEN H2.1 begins the journey: "let's look at what non-competes actually cover."

In both cases, the hook creates belonging before it creates momentum. The journey (H2.1 onwards) transforms the reader from that anxious starting state to a clear, decisive understanding.

### What Makes a Hook Work

**It stops the scroll, not summarizes the article.** The reader should feel the problem before they understand the solution. A hook that explains what the article is about is a table of contents — not a hook.

**It is specific and concrete.** The invoice example (Option 2, Apr 12) wins because it describes a moment the reader recognizes: that specific pause before paying, the discomfort they couldn't name. Abstract hooks ("firing a contractor is hard") are filler. Concrete hooks create instant recognition.

**It implies the stakes without resolving them.** The reader should finish the hook thinking "yes, exactly, and then what?" — not "okay, I get it." A hook that fully resolves the problem is a conclusion, not an invitation.

**It leads with the Rorschach, not the lecture.** The best hooks present a scenario the reader projects themselves into. Option 2 starts with "someone sent you an invoice" — every founder has been that person. They don't need to be told the problem; they need to see it reflected back at them.

---

### The TinyQE Hook Evaluation Checklist

Apply to every hook option before presenting to Tiny:

**Structure:**
- [ ] Exactly 2 paragraphs — no structural headers, no H2s, no H3s
- [ ] No "this article," "in this section," "by the end of"
- [ ] No brand mentions (AbroadWorks, Nava, etc.)
- [ ] No contractions (same formality standard as body)

**Arc fit:**
- [ ] Hook leads naturally into H2.1 without tonal whiplash
- [ ] H2.1's intro is not structurally similar to hook's opening ("Most founders..." after a hook that also opens with "you/your" is fine; "Most founders..." after another "Most founders..." is not)
- [ ] The hook's implied stakes match the article's actual argument arc

**Tone:**
- [ ] Edgy, confrontational, or emotionally disruptive — not warm or explanatory
- [ ] Specific scene or moment, not abstract principle
- [ ] Does not read like an introduction ("In this article, we will explore...")

**TinyQE override:** If Option 2 exists in a set, it wins by default unless it structurally fails. Option 2 that stops the scroll beats Options 1 and 3 that explain the scroll.

---

### The "Most Founders" Clash — A Specific Hook Failure Mode

When a hook ends with a framing that H2.1's intro then repeats in the same words, the reader experiences a flatline. They read the same idea twice in back-to-back paragraphs.

**Example of failure (Option 1, Apr 12):**
- Hook opened with "You already know. You've known for three weeks..." — visceral, personal
- Hook closed with: "That's not a personality problem. That's a math problem you haven't run."
- H2.1 opened with: "Most founders already know something is wrong."
- The "you already know / founders already know" echo killed the hook's momentum

**The rule:** After inserting a hook, scan H2.1's opening for structural repetition with the hook's closing. Two paragraphs back-to-back that use the same word family at the start are a flatline, not a bridge.

**Fix:** The hook and H2.1 intro are separated by a blank line and the reader processes them differently — the hook creates a felt experience, H2.1 transitions to intellectual framing. As long as H2.1 isn't lecturing on the same specific point the hook just made, the sequence works.

---

### The Hook Is Bare-Knuckle. The Body Is Tuxedo.

The hook is the exception to the body prose rules:
- First person allowed ("you" — in fact required)
- Shorter, punchier sentences allowed
- Emotional register: raw, confrontational, personal
- No transition words required
- The hook does NOT follow the 2-paragraph-per-H3 rule

The body prose (Phase 5) returns to full formality:
- Third person, "the reader," "founders," "you" as rhetorical address only
- 4-6 sentences per paragraph
- Transition words on all non-first paragraphs
- No contractions, no em-dashes

The transition between hook and H2.1 is tonal, not structural. H2.1 shifts from felt experience to intellectual framing — that shift is the article's first proof of sophistication.

---

**This belongs in the editor skill as Phase 6.** The hook is designed after the full arc is known, because the hook's job is to make the reader want to take the journey — not to describe where they're going.

The transition between sections is not a linguistic connector ("Therefore", "Furthermore", "Consequently"). It is a psychological bridge based on anticipating the reader's state of mind at the end of the previous section.

**The mechanic:**
1. After reading H2.1, the reader's mental state has changed — they have new information
2. The editor anticipates what the reader is now thinking: the workaround they are considering, the objection they are raising, the next question forming
3. The intro of H2.2 names that thought and shows why it does not fully solve the problem
4. This leads the reader naturally into the next chapter without a connector word

**Why this is better than transition words:**
- Transition words are mechanical. They say "we are moving on" without saying why the move is earned.
- Psychological transitions are earned. The reader finishes H2.1 already asking the question H2.2 opens with. The transition is already inside the reader's head.
- The editor simulates the reader's journey: if their state of mind at the start is X, and H2.1 gives them new information Y, then their state of mind at the end of H2.1 is Z. H2.2 must address Z.

**Two examples from the IC Non-Compete article:**

*H2.1 ends → H2.2 intro:*
Reader thinks: "Okay, so I need to make sure the non-compete meets all the legal requirements and is properly drafted."
H2.2 intro: "It may seem that the solution is ensuring the requirements are met and coupled with other agreements — but courts have reached various conclusions on this."

*H2.2 ends → H2.3 intro:*
Reader thinks: "So I need to control the relationship carefully to make sure the non-compete is binding."
H2.3 intro: "You are now aware of the pitfalls and look to tightly control the environment so the non-compete is binding — but that may actually backfire."

**Dead stop transitions:**
A section does not always need to flow into the next one with a bridge sentence. Sometimes the previous section comes to a dead stop and the transition happens entirely inside the intro of the next section. The section intro names the reader's new objection and opens the next chapter directly. This is cleaner than forcing a bridge paragraph that says "now that you understand X, let's talk about Y."

**The principle:**
The editor must always know what the reader is thinking at the end of each section. The transition is not a word — it is the answer to the question the reader is already forming.

## Legacy Notes (Preserved)

The rules below were learned from forensic analysis of previous article drafts. They are superseded by the HumanizedGemini.html lessons but retained for reference.

### What Went Wrong (Draft 1-5 Analysis)
- **Paragraph density wall**: Every paragraph was exactly 3 sentences — failed the 2x4-6 rule. Felt like "claim then stop before proving it."
- **Tone softness**: "Most founders feel the pinch" too conversational. Needed "Street-Level Realism."
- **Missing blockquotes**: Draft 4 had visceral intro but missed blockquote axioms at end of each H2 section.
- **Wrong word choices**: Used "Trap" repeatedly — needed harder language like "Executive Focus Penalty" or "Clerical Impasse."
- **AI vocabulary leaks**: Used "nuanced," "best practices," "scalable," "proactive" — flagged by humanizer (33/100).
- **Phase jumping**: AWAA jumped from H1 selection straight to full draft without canvas approval — most repeated failure.
- **Visa pathway article (v3)**: Used "16 to 54 months" for EB-3 (incorrect), em-dashes throughout, contractions in formal article, close-quote punctuation violations, bold labels in body. All caught by Custom GPT. Fixed in v4.
- **Visa pathway article (v4 critique)**: Missing meta-title and meta-description (CMS scaffolding), Key Takeaways block (required for Nava blog format), "Furthermore" transition crutch throughout, EB-3 timeline still wrong in critique's source (12–48 months per SoT, not 16–54), premium processing called "45 calendar days" (should be 15 business days), operational terms capitalized ("Critical Mass", "Job Embeddedness") when they should be lowercase. All fixed in v5.

### What Fixed It (Draft 5)
- Split intro into visceral scene + pivot to stat
- Expanded paragraphs to 4-6 sentences with forensic depth
- Added blockquotes to all H2 sections
- Math as payoff ($117,000)
- Transition words (Furthermore, Consequently, Worse)
- "Suspend the win" intro approach

---

## Core Editorial Principles (from HumanizedGemini.html — definitive version)

### Phase Enforcement (Critical — most repeated failure)
AWAA/NavaAA will try to jump phases. It may present H1 options and then immediately jump to "here's the full article" before H2s and H3s are approved. **This is forbidden.**

**Mandatory sequence:**
1. H1 options → User selects
2. H2 structure → User approves
3. H3 sub-headings → User approves
4. Canvas (paragraph-level ideas) → User approves
5. Draft generation → User approves

**No auto-generation at outline stage. The agent never produces a draft until canvas is explicitly approved.**

### Comprehension vs Vocabulary
When someone says "I don't understand" — unpack the logic first, don't synonym-swap. Fix the underlying concept before reaching for different words. Tiny supplied "hiring revolving door" when CustomGPT offered "hiring stall" and "hiring impasse" — the problem wasn't the word, it was that neither word described the actual mechanism.

### Hallucination Prevention
Never hallucinate file names, article titles, or stats. Always verify against actual files and documents before referencing. CustomGPT invented "The Upwork Trap" and "The Fiverr Illusion" — articles that don't exist on AbroadWorks.

### Factual Accuracy (Critical — immigration content especially)
Immigration facts are verifiable and readers WILL catch errors. Before publishing:
- **EB-3 processing times**: Verify current DoS and USCIS published times. Do not use outdated figures. Premium processing for EB-3 I-485 is 15 business days (FY2026), not 45 calendar days.
- **Visa bulletin designations**: Confirm "Dates for Filing" vs "Final Action Date" behavior per current bulletin.
- **Numbers in quotes**: Spell out numbers in text when used as proper nouns (write "EB-3" not "EB3" or "eb-3").
- **Fee structures**: Verify all-in costs against current USCIS/NVC fee schedules.
- **When in doubt**: Flag uncertain claims to the user rather than publishing unverified facts.

### Paragraph Independence
Each paragraph must be a distinct logical beat — not a restatement of the previous point. If two paragraphs feel like they're saying the same thing, they need sharpening.

### Transition Discipline
Every paragraph leads with a transition word that signals logical connection to the previous idea. Narrative flow: Problem → Agitation → Solution. Each section earns its place. A solution paragraph doesn't belong in the agitation section.

### "Suspend the Win" Intro
Acknowledge the appeal of the thing first, then reveal the failure. Not "here's why X is bad" — more "here's why X seems great, here's what's actually happening." Start with platform name-drops (Upwork, Fiverr) — what they promise, who uses them, the appeal.

### "Edgy" Voice
Every article needs its own edge — the intro sets the tone for the whole piece. Reject intros that feel templated or "like my other work."

### Avoid Overlap with Existing Content
Check existing corpus before proposing H2s that repeat previous arguments. Use old articles as linked references, not content to replicate. "We literally just wrote about focus drain" is a valid objection.

### Editorial Housekeeping (Final Step — never skip)
1. **Meta info + callouts** — update to match the article
2. **Keyword placement** — Primary keyword: H1 + first paragraph + one H2 + Conclusion. Secondary keywords: woven through body. **Never bold keywords in body text.**
3. **FAQ integrity** — FAQs at the end are perfect; don't repeat math or figures from the body
4. **Internal links** — embed in first paragraph, don't re-explain

## Hard Constraints (Non-Negotiable)

### Structure
1. **2x4-6 Rule**: Each H3 section contains 2 paragraphs, each with 4-6 sentences. Applies to blog articles. Does NOT apply to: LinkedIn posts (use bold-for-pivots structure), X/twitter threads (one idea per tweet), or Statement of Trade (SoT) formats which follow different conventions.
2. **H2 Introductions**: Every H2 heading must have a contextualizing paragraph immediately beneath it before H3s begin.
3. **Blockquote Callouts**: Each H2 section ends with a blockquote axiom — the "social media snippet" that anchors the section's meaning.

### Formatting
1. **No Bold in Body**: Bold is for headings (H1, H2, H3) and blockquote callouts only. Never bold individual words or phrases within paragraphs.
2. **No Em-Dashes**: Never use `—` or `–`. Use periods, commas, or separate sentences instead.
3. **No Close-Quote Punctuation Violations**: When a quoted phrase ends a sentence and the quote is a standalone fragment (not a full sentence), the period goes outside the closing quote. E.g., `the word "EB-3"` not `"EB-3."` at end of clause.
4. **No Numbered Lists**: Use prose paragraphs, not bulleted or numbered lists in body content.
5. **No Contractions (Formal Content)**: In articles and formal long-form, use "do not" not "don't", "it is" not "it's", "cannot" not "can't". Contractions are acceptable in LinkedIn/X posts where casual tone fits the platform.

### Voice
1. **No "Trap" Language**: Avoid "trap" as a noun. Use alternatives: "hurdle," "penalty," "clerical impasse," "executive focus penalty."
2. **No Strawmen**: Acknowledge the other side's valid arguments before dismantling them.
3. **Killshot Idiom**: When killing a hypothetical, use "Nice dream. But impractical." — never "we stopped chasing X."
4. **No AI Vocabulary**: Avoid: "nuanced," "best practices," "scalable," "proactive," "leverage," "robust," "ecosystem," "synergy."
5. **No Self-Referencing**: The article must never reference itself. No "this article explains," no "as we will see," no "in this article." The content delivers what the opening promises. Drawing attention to the fact that this is an article breaks the illusion of direct conversation.

**The fix:** Replace meta-references with substance. "This article explains why X and what actually works" → just state what actually works and why. Never say "article" or "explains" — just deliver.

### Paragraph Mechanics
1. **Never Write Exactly 3 Sentences**: A 3-sentence paragraph is the most common AI drafting pattern and fails because it states a claim then stops before proving it. Always expand to 4-6 sentences with forensic depth, OR cut to 1-2 sentences if the thought is complete at that length. When in doubt, add a sentence — the extra detail is what separates good prose from AI filler.
2. **Paragraph Density**: Never write exactly 3 sentences. Expand to 4-6 with forensic depth.
2. **2x4-6 Expansion Technique**:
   - Sentence 1: The claim
   - Sentence 2: The "Why it happens" (mechanism)
   - Sentence 3: The math/evidence
   - Sentence 4: The founder implication (result for their life)
   - Sentence 5: The bridge to next paragraph
3. **Math as "Aha!"**: Numbers should be the payoff moment, not buried. Example: `$150/hr × 15 hrs × 52 weeks = $117,000 annually`
4. **Word Repetition**: Don't reuse the same word multiple times in close proximity. Read aloud — ears catch what eyes miss.

### Narrative Structure
1. **Suspend-and-Pivot Intro**: Hook the reader with a visceral scene or pain point, pivot to a stat or observation, then introduce the solution.
2. **Narrative Headers**: Use story-chapter headers like "The Acquisition Impasse" — avoid "Stats Spoilers."
3. **Bridge Protocol**: Use transition words (Furthermore, Consequently, Ultimately, Worse) to connect paragraphs. Avoid "island" paragraphs with no logical thread.

## AWAA Draft Review Workflow (Critical — Apr 11, 2026)

⚠️ **Passes 1 and 2 and their phases are non-negotiable. Never skip, never shortcut. This is the review sequence that catches what went wrong with H3.2.1 P2.**

Triggered by: AWAA Phase 5 output. Run before any readability sweep or line-by-line editing. Each pass narrows focus from big picture to detail.

---

### Phase 1: Arc & Structure (Big Picture)

**Pass 1.1 — Arc Integrity**
- Does the article tell one story with momentum, or does it feel like a reference doc?
- Do the H2s form 3-4 acts of the same story, each building on the last?
- Does the reader's understanding transform from opening to close?
- If arc is broken → send back to AWAA with arc instructions. Do not proceed.

**Pass 1.2 — Section Audit (H2 by H2)**
- For each H2 section, list the main ideas of each H3 in a temporary notepad
- Ask: is each H3 contributing something new and unique to its parent H2?
- Flag any H3 that overlaps with a sibling H3 in the same or another section
- Flag any H3 that feels like it has no distinct job
- If overlaps or redundancies found → send back to AWAA with specific H3s to redirect or cut

**Pass 1.3 — Paragraph Audit (H3 by H3)**
- For each H3, go paragraph by paragraph
- Ask: does each paragraph support its parent subsection, or is it repetition/irrelevant?
- If a paragraph doesn't serve its H3 → flag it
- Do not fix — flag and return to AWAA if structural

---

### Phase 2: Readability Sweep (My Edit — I Run This)

**Pass 2.1 — Section Intro Audit**
- Go section by section
- Does each H2 intro represent the general gist of the section? (Compare against the notepad from Pass 1.2)
- Is the intro previewing, not parroting? (See Principle 7: intro parroting)
- If intro misrepresents or parrots → fix the intro

**Pass 2.2 — Transition Audit**
- Go paragraph by paragraph within each H3
- Is there a transition between this paragraph and the next?
- Does the transition signal logical connection, or is it just a mechanical connector word?
- Fix missing or weak transitions silently

**Pass 2.3 — Sentence-Level Audit (MEAL Plan)**
- Go paragraph by paragraph
- Apply MEAL test: **Main idea → Evidence → Analysis → Link/Transition**
  - **Main**: Does the paragraph have a clear main idea that supports the H3?
  - **Evidence**: Is there specific evidence (stat, example, mechanism) that supports the main idea?
  - **Analysis**: Does the paragraph explain *why* the evidence matters, not just what it is?
  - **Link/Transition**: Does the paragraph end by signaling what the next paragraph will address?
- Flag repetition within the paragraph — if a sentence merely restates the previous one, cut or redirect
- Flag paragraphs that announce their logical chain ("The logical chain is direct: X, Y, Z") then restate it step by step — this is explainer language, not analysis
- Flag sentences that exist to fill space rather than add value
- Fix silently — this is my readability sweep

**The MEAL caveat (Ty's):** "This does not always apply but it helps." MEAL is a diagnostic aid, not a rigid formula. The goal is paragraph coherence — every sentence earns its place by serving the main idea.

**What Tiny's analysis step fix taught (H3.2.1 P2):** AWAA jumped from "finds excessive control" to "reclassify" without the causal mechanism. Tiny added the conditional: "If your independent contractor solely relies on you for income, and cannot independently determine when and how to work, the court will find this to be excessive control and will reclassify them as employees." This is the missing causal link — financial dependence → reclassification. Without it, the paragraph states consequences without explaining why they follow from the evidence.

**MEAL checklist (Pass 2.3):**
- Main: Clear controlling idea of the paragraph?
- Evidence: Specific proof (stats, examples, factors, data)? Or just description of the concept?
- Analysis: Does it explain *why* the evidence matters, not just what it is?
- Link/Transition: Does it end with the next paragraph's concern, or just a dead-end consequence?

---

### How to Keep the Notepad (Pass 1.2)

As you read each H3, write down its main idea in one line. Keep a running list:

```
H2.1: What the clause actually restricts
  H3.1.1: [main idea]
  H3.1.2: [main idea]
  H3.1.3: [main idea]
H2.2: The control contradiction
  H3.2.1: [main idea]
  H3.2.2: [main idea]
  H3.2.3: [main idea]
```

Compare each H3's main idea against siblings. If two H3s in the same H2 are doing the same job, flag it. If an H3 in H2.1 sounds like one in H2.2, flag it.

---

**Workflow summary:**

| Pass | Scope | Question | Action if fail |
|------|-------|----------|---------------|
| 1.1 | Arc | Is this one story with momentum? | Return to AWAA |
| 1.2 | Section | Is each H3 distinct? | Return to AWAA |
| 1.3 | H3 | Does each paragraph serve its H3? | Return to AWAA |
| 2.1 | Intro | Does intro preview vs. parrot? | Fix silently |
| 2.2 | Transitions | Are paragraphs logically connected? | Fix silently |
| 2.3 | MEAL | Does every sentence add value? | Fix silently |

**Never skip Phase 1.** If Phase 1 finds problems, do not proceed to Phase 2. Return the draft to AWAA with specific instructions.

---

## Revision Workflow

### Pass 1: Structure Audit
- [ ] All H2 sections have contextualizing intros
- [ ] All H2 sections end with blockquote
- [ ] Each H3 has exactly 2 paragraphs
- [ ] Each paragraph has 4-6 sentences (not 3)

### Pass 2: Voice Audit
- [ ] No bold in body (headings only)
- [ ] No em-dashes or en-dashes
- [ ] No "trap" language
- [ ] No AI vocabulary markers
- [ ] No strawmen arguments

### Pass 3: Depth Audit
- [ ] Math is visible and positioned as payoff
- [ ] Every paragraph has forensic depth (mechanism + evidence + implication)
- [ ] Word repetition check — read paragraphs aloud
- [ ] Transition words connect paragraphs logically

## Real-Time Editorial Principles (from Tiny line-by-line review — Apr 11, 2026)

*These are lessons from live editing sessions where Tiny explains his changes paragraph by paragraph. The focus is on WHY, not WHAT. Mechanics are evidence of principles, not the principles themselves.*

---

### Principle 1: Micro-Transitions Within Paragraphs

**What Tiny observed:** AI writing is choppy — ideas connect abruptly within single paragraphs. Humans naturally use small connecting words at the sentence-to-sentence level, not just between sections.

**The fix:** Add transitional words between sentences *inside* paragraphs. These are micro-connectors: "and", "but", "so", "yet", "while", "as a result", "unexpectedly." They create flow at the sentence level.

**Example (before):**
> "An employee spent 8 months developing... The business started gaining edge... The employee resigned and reached out to competitors..."

**Example (after):**
> "An employee spent 8 months developing... The business started gaining edge in the local market. **Unexpectedly,** the employee resigned and reached out to competitors..."

**Editorial principle:** Transitions aren't only structural (section-to-section). The real flow work happens at the sentence-to-sentence level inside paragraphs. AI drafts often have correct paragraph structure but choppy intra-paragraph rhythm. Read each paragraph aloud — if you stumble between sentences, there's a missing micro-connector.

---

### Principle 2: Vocabulary Variation at Paragraph Boundaries

**What Tiny observed:** Two consecutive paragraphs that use the same word family at the end of one and the start of the next reads as recycled. In the NC article: P1 ended with "believed" → P2 opened with "The belief." Same root word family, adjacent paragraphs.

**The fix:** Vary vocabulary at paragraph boundaries. When two paragraphs back-to-back use the same root word at the start/end, restructure or use a synonym.

**Editorial principle:** Word families at paragraph boundaries are a stealth AI signal. Watch for: belief/believed/believes, contract/contracted/contracting, business/businesses, protect/protection. This isn't about avoiding repetition for its own sake — it's about precision. Using the same word twice in close proximity signals the writer didn't consciously choose each word.

**The deeper point:** Precision isn't only about choosing the "right" word — it's also about avoiding accidental repetition. When you use the same word family at both ends of adjacent paragraphs, it looks like the writer defaulted rather than chose.

---

### Principle 3: "Perhaps" Hedge on Counterfactual Causal Claims

**What Tiny observed:** The original intro said the non-compete "would have prevented this loss." But we don't actually know if it would have. The employer believes it — but belief ≠ fact. Using "would have" closes the argument too soon and makes an unverified claim sound like established fact.

**The fix:** When making a causal claim about a hypothetical past event ("X would have prevented Y"), guard it with "perhaps" or "likely." This does two things: (1) it accurately represents uncertainty, and (2) it ominously sets up that we're about to debunk the employer's belief.

**Example:**
- Before: "...a strict non-compete clause that would have prevented this loss."
- After: "...a strict non-compete clause that, perhaps, would have prevented this loss."

**Editorial principle:** Counterfactual causal claims ("X would have prevented Y") require hedging when the causal relationship isn't proven. The "perhaps" keeps the argument open — the reader feels the setup and waits for the debunk. A flat "would have" forecloses the reader's curiosity. The hedge creates narrative tension and credibility simultaneously.

---

### Principle 4: Skip the Obvious, Go for Pain Points

**What Tiny observed:** The original P2 said "Most micro-business owners who add a non-compete to a contractor agreement do so because they want protection against the contractor taking knowledge, clients, or work product." This explains what a non-compete is to someone who doesn't know. The audience already knows this — they've been through it. Explaining itinsult their intelligence.

**The fix:** Skip the explain-like-I'm-5 explanation. Go straight to the emotional register: years of sacrifice, capital sunk, opportunity costs, the pain of a competitor cloning your business overnight. The reader recognizes their own experience before being told what they were trying to protect.

**Example (before):**
> "Most micro-business owners who add a non-compete to a contractor agreement do so because they want protection against the contractor taking knowledge, clients, or work product."

**Example (after — rebuilt entirely):**
> "Intellectual property, trade secrets, clients, or work product, and combinations thereof, give each business a unique identity and, particularly in micro-businesses, developing that unique niche and succeeding in highly competitive markets often means years of the founders' time. It means significant capital sunk and a lot of opportunity costs. Having a competitor obtain the culmination of your hard work and sacrifice overnight and cloning your business is a painful experience..."

**Editorial principle:** AI drafts explain. Human writers implicate. The original told the reader what NCs are for. The revision makes the reader feel what they stand to lose. The reader arrived already knowing the factual premise — the article's job is to activate the emotional consequence, not restate the premise.

**The test:** If you can explain the paragraph's point in one sentence to a 5-year-old, you've stated the obvious. Rewrite to surface the stakes, not the mechanism.

---

### Principle 5: The Pivot Sentence — Implicating the Owner

**What Tiny observed:** The rewritten P2 ends with "The real safeguard for your business is you and who you trust." This lands as a pivot point — it signals that the article will now show the reader what actually protects them.

**The function:** This sentence does two things: (1) it acknowledges that protection starts with the owner's own judgment and choices, and (2) it sets up the rest of the article as a guide to making better decisions. It's the promise of the journey.

**Editorial principle:** The pivot sentence at the end of the introduction is the article's thesis statement in disguise. It doesn't say "this article will explain X" — it says "you need to understand X, and here's where we're going." The reader finishes the intro knowing exactly what kind of transformation is coming, without the article having to announce itself.

**When drafting:** If the introduction doesn't end with a pivot sentence that implicates the reader's agency, the article lacks momentum. The intro has resonance and disruption — but the pivot is what makes the reader commit to the journey.

---

### Principle 8: Repetition → Evidence (MEAL Evidence Step — Applied)

**The failure (AWAA paragraph 2, H3.2.1):**
Three sentences saying the same thing:
1. "Courts do not just read the contract. They examine the relationship behind it."
2. "the court looks at the full picture of how you managed this worker"
3. "the court examines the relationship. Finds excessive control."

**What Tiny did:**
Collapsed three description sentences into one colon-led evidence list:
> "Courts go beyond merely reading the contract and examine the relationship behind it: the scheduling, the exclusivity of the relationship, the resources and tool specifications used, the integration into your operations, the hourly oversight."

**Why this is MEAL Evidence step:** The "evidence" in MEAL is the specific proof — not a description of what courts do, but *what courts look at*. The multi-factor test items ARE the evidence. AWAA was naming the concept (courts examine relationship) three times. Tiny replaced it with the specific factors courts actually examine.

**The pattern:** When a paragraph has three sentences doing the same job, the fix is not to merge them into one shorter sentence. The fix is to replace the repetition with the specific content the repeated description was gesturing toward. The multi-factor test items = the evidence. Use them.

**Editor check (Pass 2.3):** If three consecutive sentences could be collapsed into one by removing the repetition, the paragraph is announcing rather than proving. Replace the announcement with the specific evidence the announcement was standing in for.

**What Tiny stated explicitly:** "I don't want you to overly focus on the mechanics of which words changed to what. I want the focus to be on why I changed it, and you can then use the actual mechanics of what I changed as an example. The concept is what matters."

**Editorial principle:** Capturing editorial learning is not documenting edits — it's distilling the reasoning behind edits. The mechanic is evidence of the principle, not the principle itself. When taking notes during a line-by-line review, always ask: what is Tiny correcting, and why is the correction better? The "why" is the durable lesson. The specific word change is just an instance of that principle in action.

**The skill application:** When reviewing AWAA/NavaAA drafts, apply the *why*, not the *what*. Ask: does this paragraph feel choppy (Principle 1)? Does it restate the obvious (Principle 4)? Is there an unhedged counterfactual claim (Principle 3)? The mechanical checks (word count, transition words, vocabulary variation) serve the conceptual goals — they are not the goal themselves.

---

### Principle 7: Intro-to-H3 Parrotting — AWAA Writes Paragraphs First, Intros Last

**What happened (H2.2 intro, Apr 11):** AWAA's H2.2 intro opened with "The mechanism is counterintuitive and it works like this" — then explained the entire mechanism: courts examine control, more control = employment, non-competes are control so using them = evidence of employment relationship. H3.3.1 then opened with the exact same courts/control paragraph, word for word.

**Why it happens:** AWAA drafts paragraphs first, then writes the intro last. The intro is a summary of AWAA's own completed work, not a preview of what's coming. Because AWAA already knows what it wrote in the H3s, the intro becomes a digest of those H3s rather than a guidewire for the reader.

**The diagnostic:** Read the first sentence of each H3. If the intro's second or third paragraph says the same thing in the same depth as the first H3, the intro is parroting — it is summarizing completed work instead of previewing what's coming. The intro and the H3 are doing the same job; one of them has the wrong job.

**The rule for AWAA:** An H2 intro must ONLY preview. It says what's coming, why it matters, what to watch for. It must NOT contain the argument itself. The H3s own the argument. If the intro explains the mechanism, the H3 has nothing left to add except repetition.

**The fix (Tiny's, not AWAA's):** Cut the mechanism explanation from the intro. Leave only the preview: what the second problem is, why it's counterintuitive, why it's dangerous. The reader goes into H3.3.1 not knowing exactly how it works — that's what makes them read.

**The editor check:** For every H2 section, compare the intro against the first H3's opening sentences. If the intro covers the same analytical ground in the same depth, flag it. The intro's job is to make the reader want to read the H3 — not to save the H3 the trouble of explaining itself.

**How to tell if an intro is parroting vs. previewing:**
- Parroting intro: tells the reader exactly what the H3 will say, in the same detail, before the H3 says it
- Previewing intro: names the concept, signals the direction, hints at the consequence — without dissecting the mechanism

The test: after reading the intro, does the reader feel they already understand the H3's argument? If yes, the intro is parroting.

---

## Known Aliases

| Avoid | Use Instead |
|-------|-------------|
| Trap | Hurdle, Penalty, Clerical Impasse, Executive Focus Penalty |
| Leverage | Use, Employ, Harness |
| Best practices | What works, What actually works |
| Scalable | That grows, That scales |
| Proactive | Strategic, Anticipatory |
| Nuanced | Subtle, Complex, Layered |
| Robust | Solid, Strong, Proven |
| Ecosystem | Environment, Network, System |
| Synergy | Alignment, Combined effect |

## Custom GPT Feedback — What It Catches (And What We Should Catch First)

The AbroadWorks Custom GPT provides a second-pass review. It consistently flags these categories of issues. We should catch these in self-edit BEFORE the draft goes to Custom GPT:

### Mechanical Issues (Almost Always Caught)
- Contractions in formal content (flagged as register inconsistency)
- Em-dashes (flagged as non-standard punctuation)
- Bold in body (flagged as formatting error)
- Close-quote punctuation violations
- Word repetition in close proximity
- 3-sentence paragraphs

### Immigration Factual Issues (Always Caught)
- Outdated processing time claims
- Visa bulletin designation confusion (Dates for Filing vs Final Action)
- Incorrect EB-3 timeline ranges
- Numbers used inconsistently with USCIS/NVC conventions

### Structural Issues (Sometimes Caught)
- Missing transitions between paragraphs
- Paragraphs that feel like restatements of each other
- H2 sections without contextualizing intro paragraphs
- Missing blockquote callouts at end of H2 sections

### What the Custom GPT Misses (Human Eye Catches)
- The "beautiful hypothetical" that's easy to dismantle
- Claims that sound plausible but lack Nava-specific grounding
- Arguments that don't reflect how Tiny would actually write them
- Tone that's technically correct but lacks the edge Tiny demands

## Nava Blog Article Requirements

Nava blog articles follow a specific format that differs from generic long-form. This format is defined by the published blog at navahc.com, not by the Custom GPT or any external template.

### Required Front Matter (Scaffolding — strip at publish)
Every Nava blog article draft must include at the top:
```
**Meta-title:** [SEO title, max 60 chars]
**Meta-description:** [meta description, max 160 chars]

**Key Takeaways:**
1. [Point 1]
2. [Point 2]
3. [Point 3]
4. [Point 4]
5. [Point 5]
```
- Key Takeaways go at the very top of the article, before the H1
- Meta fields go in the document for CMS reference, stripped at publish
- 5 Key Takeaways required (not 3, not 6)
- Key Takeaways must be substantive (specific numbers, specific claims — not vague headers)

### Required Back Matter
Every Nava blog article must end with a **Sources** section:
```
**Sources:**
- [Department of State Visa Bulletin — April 2026](url)
- [USCIS Premium Processing](url)
- [Healthcare Workforce Resilience Act or applicable](url)
```
- Include raw URLs (not just in-text links) for the three most authoritative external sources cited in the article
- Department of State Visa Bulletin and USCIS are standard; third source is article-specific

### Structural Requirements
- **H2 sections**: Each H2 must have a contextualizing intro paragraph (2-3 sentences) before any sub-content
- **Blockquotes**: Each H2 section ends with a blockquote axiom (provocative single sentence that sums the section's meaning)
- **No H3s required** — Nava blog articles use a flat H2 structure, not nested H2/H3
- **In-text links only** — markdown links embedded in body text, no URL footer list (exception: Sources section at bottom)
- **Bold**: Bold is for headings only. No bold in body text for labels or callouts.

### Mechanical Rules (Non-negotiable for Nava articles)
1. **Zero contractions** — "do not" not "don't", "it is" not "it's"
2. **Zero em-dashes** — use commas, semicolons, or separate sentences
3. **Zero en-dashes** — same rule as em-dashes
4. **Periods outside close-quotes for fragments** — `"Current"` not `"Current."` when the quote ends a clause
5. **EB-3 timeline: 12 to 48 months** — not 16 to 54, not other ranges
6. **Premium processing: 15 business days** — not 45 calendar days
7. **Operational terms lowercase** — "job embeddedness" not "Job Embeddedness"
8. **No numbered lists in body** — Key Takeaways is the only exception; all body content is prose

### Transition Rules
- Never use "Furthermore" as a generic bridge — it reads as filler
- Use **diagnostic** transitions: "From a budgetary perspective," "The legal distinction lies in,"
- Use **additive** transitions: "In addition to urgency," "Beyond the cost differential,"
- Never start two consecutive paragraphs with the same word

## LinkedIn Post Editor Rules

LinkedIn posts follow different structural rules than blog articles. Apply this section when editing LinkedIn/X content.

### Structure
1. **No H2/H3 headings** — LinkedIn posts use bold for narrative pivots only, not section labels
2. **Short paragraphs** — 1-3 sentences max per paragraph. White space is structural.
3. **Line breaks between every paragraph** — single blank line between each block
4. **4-6 paragraphs total** — more than 6 and the post loses LinkedIn algorithm performance
5. **First 2 lines are everything** — they show in the preview before "...see more"
6. **End with a CTA or question** — drives comments, which drives reach

### Voice
1. **No bullet lists** — prose only in the post body
2. **No em-dashes** — short sentences, not dashes
3. **No bold in body** — bold is for narrative pivots only (max 1-2 per post)
4. **Contractions** — "don't" not "do not"
5. **Operator tone** — compressed sentences, like someone who actually does the work
6. **No buzzwords** — synergy, leverage, ecosystem, game-changer, disrupt

### The Intro Problem (Most Common Failure)
AI drafts lead with context ("In today's competitive healthcare landscape..."). Tiny leads with a visceral concrete moment or a confrontational claim that makes the reader stop scrolling.

**Bad opener:** "Healthcare facilities face significant challenges when choosing between EB-3 and TN visas..."

**Good openers:**
- A specific dollar amount the reader recognizes
- A scene: "Your travel nurse invoice arrives every 13 weeks."
- A confrontation: "Stop pretending you can only pick one."
- A stat that reframes the question

### Paragraph Architecture (LinkedIn)
Each paragraph does ONE thing:
- Paragraph 1: Hook (visceral scene OR confrontational claim)
- Paragraph 2: Establish the false binary / the wrong question
- Paragraph 3: The math OR the evidence that reframes it
- Paragraph 4: What the right decision looks like
- Paragraph 5: The Nava pivot + CTA

### X/Twitter Thread Rules
- Each tweet stands alone ( reader may not see the thread context)
- End each tweet with a hook for the next one
- Max 280 characters per tweet
- Punctuation > emoji as separators
- Punchline comes last

## Tone Targets

**Street-Level Realism**: Visceral, confrontational, specific. Anchor readers in moments like "You scroll through Upwork at 11 PM."

**Analytical Depth**: Forensic evidence, math shown, structural analysis. Don't just claim — prove it.

**Narrative Pacing**: Bold for dramatic turns only. Flowing prose with transitions. No bullet fragments.
---

## Apr 12 Session — Editorial Principles (Tiny Line-by-Line Teaching)

*From Apr 12 line-by-line review of IC Non-Compete article. These are hard rules, not suggestions.*

### Prohibited Contrast Patterns

**"X is not just Y" is a prohibited AI template.** It signals a strawman contrast structure — the writer builds a version of the argument that's easy to knock down.

**The correct contrast pattern:**
> "X does A; Y does B — with substantive distinction."

Two parallel statements, each doing real work, with a colon or em-dash signaling the comparison. The reader draws their own conclusion.

**Why it matters:** "Not just" templates invite the writer to dismiss the counterargument with a wave rather than engaging it substantively. The clean contrast forces the writer to actually know what X does and what Y does.

---

### Case Facts Before Analysis (H3.2.2 Rule)

**Every case-study H3 must lead with the story.** What business were the parties in? What did the contract say? What happened? THEN the legal mechanism and analysis.

**The sequence:**
1. What happened (story)
2. What the court found (analysis)
3. What it means for the reader's situation (implication)

**Never:** Lead with the dollar judgment, then backfill the facts. The reader needs the story to care about the outcome.

**This applies to all case-study sections in any article.** If an H3 uses a case name or a specific example, it opens with what happened to the parties, not what the lesson is.

---

### Brand Reveal Pattern

**Zero brand mentions through the body of any section or article.** Build to the brand name the way the article builds to its conclusion — through implication, through earned proximity.

**The mechanic:**
- Describe the provider's function: "A provider who builds the agreement with these three protections correctly structured from the start handles the hard part."
- Never name the brand until the final sentence of the final section
- The first mention is earned — it lands because the reader has been primed to recognize what good looks like

**What NOT to write:**
> "At AbroadWorks, we include this clause in every agreement."

**What TO write:**
> "A provider who builds the agreement with these three protections correctly structured from the start handles the hard part. They do not offer it as an add-on — they make it the baseline. The IP assignment is non-negotiable. The trade secret provisions are standard. That is the structure AbroadWorks builds into every independent contractor agreement."

**The brand reveal is the payoff, not the pitch.** It works because the reader has already arrived at the conclusion. The name confirms what they just understood.

---

### "Perhaps" Hedge Rule

**In analytical/counterfactual context:** Use "perhaps" to hedge causal claims about hypothetical past events.

**The case:** "A strict non-compete clause that, perhaps, would have prevented this loss." — We don't know if it would have. The employer believes it. "Perhaps" keeps the argument honest and sets up the debunk.

**"Perhaps" vs. "likely":** "Perhaps" works for counterfactual causal claims (what would have happened). "Likely" works for forward-looking predictions. Use each in its correct context.

**In analytical context (NOT counterfactual):** "Perhaps" is a weak hedge and should be avoided. State the analysis directly.

---

### Non-English Character Removal

**Chinese characters and other non-English scripts do not belong in English body text.** If found, remove and replace with English equivalent.

**Example:** "客户" found in body → replace with "clients" or appropriate English term.

**Always scan body text for non-Latin scripts before finalizing.** This is a publication integrity issue.

---

### Redundancy Merge Rule (Adjacent H3s)

**If two H3s at the same altitude cover the same argument, they must be merged or deleted.** Adjacent H3s with overlapping content = structural failure.

**The test:** Can section A's job be done by section B without the reader losing anything? If yes, one of them doesn't belong.

**H3.2.3 removed Apr 12:** Was redundant with H3.2.1 P2 (economic dependence / reclassification mechanism already covered after MEAL fix). Adjacent sections at same altitude, same argument.

---

### "We Stopped Chasing X" Rule

**Never generate an action Nava or AW did not actually take.** "We stopped chasing X" is a claim about historical behavior. If Nava didn't chase X, don't write it.

**The "Nice dream. But impractical." pattern** is the correct killshot for a hypothetical:
> "Perhaps you could try [unsupported approach]. Nice dream. But impractical."

This destroys the hypothetical without claiming Nava tried and abandoned something.

---

### MEAL Plan (Formalized Apr 12)

**M**ain → **E**vidence → **A**nalysis → **L**ink/Transition

Every paragraph has:
1. A clear main idea (what this paragraph proves)
2. Specific evidence (stats, examples, factors, data)
3. Analysis explaining *why* the evidence matters
4. A transition that names the next paragraph's concern

**The 5-sentence architecture:**
1. The claim
2. Why it happens (mechanism)
3. The math or evidence
4. The implication for the reader's business
5. The bridge to the next paragraph

**Application:** Used to fix H3.2.1 P2 where AWAA stated consequences without the causal mechanism. The fix added the conditional: "If your independent contractor solely relies on you for income, and cannot independently determine when and how to work, the court will find this to be excessive control and will reclassify them as employees."

**MEAL caveat:** "This does not always apply but it helps." MEAL is a diagnostic aid, not a rigid formula. The goal is paragraph coherence — every sentence earns its place.

---

### Redundant Validation Sentences

**If a sentence merely validates the previous sentence, cut it.** "That fear is real" after "a fear that lives in every founder" = redundant validation. The previous sentence already established the fear. Repeating it doesn't reinforce — it dilutes.

**The test:** Does this sentence add information the previous sentences did not contain? If not, cut it. If it's just rephrasing, it's filler.

---

### Meta-Commentary in Body

**Replace meta-commentary with real analytical first sentences.** "The logical chain is direct" followed by the mechanism laid out step by step = meta-commentary. The reader doesn't need to be told the chain is direct. Just write the direct chain.

**Better first sentence:** The mechanism itself, stated plainly, IS the direct logical chain. Let the structure speak, don't announce it.

