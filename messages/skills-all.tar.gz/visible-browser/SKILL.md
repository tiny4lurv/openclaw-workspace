# Visible Browser Skill — WSL + Windows Chrome Relay

_Teaches OpenClaw to display and control a browser you can see on your Windows desktop, with your logged-in sessions intact._

## The Two Modes

| Mode | What it is | Use when |
|------|-----------|----------|
| **WSL Chromium + xvfb** | WSL browser on a virtual display | Screenshot/automation only, you CAN'T see it |
| **Windows Chrome + chrome-relay** | Your real Windows Chrome via relay | You can SEE it AND control it with your logged-in sessions |

**The skill:** Knowing which to use and how to switch between them.

---

## Mode 1: Windows Chrome Relay (what you want for logged-in accounts)

This lets you see and control Tiny's actual Windows Chrome browser, with all his logins intact.

### Setup (one-time)

1. **Chrome Extension** — Install `chrome-extension/` folder in Windows Chrome:
   - Open `chrome://extensions/`
   - Enable "Developer mode" (top right)
   - Click "Load unpacked" → select the `chrome-extension/` folder
   - The extension connects to WSL relay on port 18792

2. **Start the relay server** (done automatically by OpenClaw gateway)

3. **Verify connection:**
   ```bash
   openclaw browser profiles
   ```
   You should see `chrome-relay: running (1 tabs) [extension]` — that's your relay.

### Use it

```bash
# Screenshot (sees what Tiny sees in his Windows Chrome)
openclaw browser --browser-profile chrome-relay screenshot

# Navigate
openclaw browser --browser-profile chrome-relay navigate <url>

# Click/type/scroll
openclaw browser --browser-profile chrome-relay click "#selector"
openclaw browser --browser-profile chrome-relay fill "#selector" "text"
openclaw browser --browser-profile chrome-relay scroll down
```

### Why this matters
- Tiny is ALREADY logged into Twitter/X, LinkedIn, etc. on his Windows Chrome
- The relay piggybacks his existing sessions → no re-login needed
- He can WATCH the browser move on his screen

### Profile names (from `openclaw browser profiles`)
```
default:       WSL Chromium (port 18800) — headless, NOT visible
chrome-relay:  Windows Chrome extension relay (port 18792) ← USE THIS for visible control
visible:       Manual Chrome on port 18801 (stopped by default)
user:          Existing chrome-mcp session (stopped)
```

### Current config (working)
```json
"browser": {
  "relayBindHost": "0.0.0.0",
  "relayHttp": true
}
```
⚠️ No `defaultProfile` key — that was the bug that broke the relay. The `chrome-relay` profile is auto-created by the extension.

---

## Mode 2: WSL Chromium (automation only, NOT visible)

Use this when you need a disposable browser for scraping pages Tiny isn't logged into.

### Setup (one-time)

```bash
# Install xvfb (X Virtual Framebuffer)
sudo apt update && sudo apt install -y xvfb

# Install Chromium
sudo apt install -y chromium-browser
```

### Use it

```bash
# Launch with virtual display
xvfb-run -a openclaw browser screenshot

# Full command template (profile: default = WSL Chromium)
xvfb-run -a openclaw browser <command>
```

### Limitation
**You cannot see this browser.** xvfb creates a virtual display with no physical screen. Use Mode 1 if you need to show Tiny something or use his logged-in sessions.

---

## Switching Between Modes

```bash
# Use Windows Chrome relay (VISIBLE to Tiny)
openclaw browser --browser-profile chrome-relay screenshot

# Use WSL Chromium (headless, NOT visible)
xvfb-run -a openclaw browser screenshot
```

### Common errors and fixes

**"Profile not found"**
- Cause: `defaultProfile` is set in config but doesn't exist
- Fix: Remove `defaultProfile` key from config, or always pass `--browser-profile chrome-relay`

**Black screen / extension not connecting**
- Fix: Restart gateway: `openclaw gateway restart`
- Then: `openclaw browser profiles` to verify profile is detected

**Only one tweet/post visible on relay**
- Cause: Pages like Twitter/X load content dynamically; relay captures the initial render
- Fix: Use `scroll` command to load more content before screenshot

**xvfb-run not found**
- Fix: `sudo apt install -y xvfb`

---

## Quick Reference

```bash
# See both browser modes side by side
openclaw browser profiles

# Test relay (Windows Chrome)
openclaw browser --browser-profile chrome-relay screenshot

# Test WSL Chromium (invisible)
xvfb-run -a openclaw browser --profile openclaw screenshot

# Navigate relay to a URL
openclaw browser --browser-profile chrome-relay navigate https://twitter.com
```

---

## The Decision Tree

```
Do you need to see the browser on Tiny's screen?
├── YES → Use chrome-relay (Windows Chrome)
│         openclaw browser --browser-profile chrome-relay <cmd>
│
└── NO (just scraping/automation)?
    └── Use WSL Chromium + xvfb
        xvfb-run -a openclaw browser --profile openclaw <cmd>
```

---

## Gotchas

- **chrome-relay and openclaw profile are DIFFERENT.** The `chrome-relay` profile is the Windows Chrome relay. The `openclaw` profile is WSL Chromium.
- `xvfb` only works for screenshots and non-visual automation — Tiny cannot see a WSL browser
- For TeamViewer sharing: Tiny shares his screen → I watch via VNC or screenshot workflow
- After Windows restarts: chrome-relay may need gateway restart to re-establish connection
