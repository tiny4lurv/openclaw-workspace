---
name: LinkedIn Writer
description: Writes LinkedIn posts for Nava Healthcare. Applies the Nava voice, post structure, and editorial rules. Updated: 2026-04-09 with humanizing editorial framework.
---

# LinkedIn Writer — Nava Healthcare

Writes LinkedIn posts that sound like a real operator, not a content mill. Applies the Nava editorial framework learned from Tiny's feedback loop.

## Humanizing Editorial Framework — Apr 9, 2026

These are the hard lessons. Learn them.

### 1. No Lore Assumptions
**Every post must stand alone for a reader who knows nothing about Nava.** They don't know NurseSphere, Reclaimix, the 13-week cycle, or Nava's history. Don't assume shared context. Lead with evidence, not references.

**Wrong:** "This is the 13-week merry-go-round problem we keep talking about."
**Right:** Name the mechanism first. The reader discovers the pattern before you name it.

### 2. Never Land a Reveal Before the Reader Is Primed
**"Designed this way" is a conclusion, not evidence.** If you land the structural reveal before the reader has the evidence to follow, they think "wtf are you talking about?"

**The sequence:**
1. Show what happens (nurse's experience)
2. Show it happens repeatedly (the pattern)
3. Explain the mechanism (why the system keeps producing it)
4. Name it (the business model)

Reader reaches the conclusion themselves. Then you name it. That's when it lands.

### 3. Fairness — Acknowledge Variation in Human Systems
**Don't trade one extreme for another.** If you previously implied all nurses have no agency, don't now imply all nurses love being moved around.

- Some nurses negotiate to come back
- Some choose their contracts carefully
- Some leave because the model requires it — not because they chose to exit

The pattern is structural. Individuals vary. State the pattern without Universalizing.

### 4. The Karaoke Test — Social vs Logistical Learning
**The real learning curve is social, not logistical.** A child can find a medicine cabinet in two days. If your hook is about learning where supplies are, you've named the wrong problem.

**What actually takes weeks to learn:**
- Culture and belonging
- Where the best karaoke in town is
- Which physicians prefer which workflows
- The social texture of a unit

This is the human side of clinicians. Not just their professional profile.

### 5. Don't State the Obvious
**If the travel model requires something, don't also explain that clinicians didn't choose to leave.** Your reader is a healthcare executive. They can connect dots.

**Wrong:** "Many leave because the structure requires it — not because the clinician chose to exit."
**Right:** "Many leave because this is how to make a living in this industry."

Humanize the mechanism, not the explanation of the mechanism.

### 6. Watch for Repetition of Key Concepts
**Repetition of key words ("structure") signals you've said the same thing twice.** If you use a key phrase twice, one is redundant. Cut it or rephrase.

### 7. TinyQE Cold-Run Only
**Never feed corpus context to TinyQE.** Run on text alone. The tool evaluates what the post SAYS, not what the corpus SUPPOSES it means.

### 8. Bullets CAN Work — For Scannable Closer Lists Only
Bullet lists are acceptable in the closing section if:
- They're 3 items or fewer
- Each item is one line
- They're explaining what Nava does differently

They are NOT acceptable in the post body.

### 10. "That Happens" Is Too Weak — Be Visceral, Not Abstract
When describing a pattern or mechanism, "that happens" is an abstract placeholder. The reader needs a concrete, emotional reality to hold onto.

**Wrong:** "So the system moves them before that happens."
**Right:** "So the system moves them before they feel at home."

"Feel at home" is visceral — it names the specific thing being lost. "That happens" names nothing. Apply this test to every structural claim: can the reader see, feel, or imagine the thing you're describing? If not, be specific.

### 11. The Punchy Closer Contrast
End with a word that lands. Continuity vs循环. "Merry-go-rounds." The contrast should be memorable, not promotional.

### 12. Don't Assume Gender — Male Nurses Are Not Mythical
Never default to "she" for nurses or "he" for doctors. These are stereotypes. Use "they" for individuals when gender is unknown, or name the role. The post is about the human side of clinicians — that includes not perpetuating tired clichés.

This applies to every reference: nurse, doctor, administrator, leader. If you don't know, use "they" or the role.

---

## The Canonical Nava Post Structure

**5 paragraphs. No more.**

Each paragraph has exactly one job:

1. **Hook** — visceral scene OR confrontational claim. No context-setting.
2. **Wrong question** — expose the false binary or bad assumption the reader is making.
3. **Math or evidence** — the number that reframes the conversation.
4. **What the right decision looks like** — the pivot to Nava's approach.
5. **CTA** — Nava-specific, no commitment required.

## The Intro Problem (Most Common AI Failure)

AI drafts open with context: *"In today's competitive healthcare landscape..."* — wrong, kills the post before it starts.

Tiny's openers do one of these:
- **Visceral scene**: "Your travel nurse invoice arrives every 13 weeks."
- **Confrontational claim**: "Stop pretending you can only pick one."
- **Concrete dollar amount**: "$40,000 to $80,000 per open req. That's the math nobody runs."
- **Wrong question exposure**: "EB-3 or TN? You're asking the wrong question."

First 2 lines show in the LinkedIn preview before "...see more." They either stop the scroll or they don't.

## Formatting Rules

- **Line breaks between every paragraph** — single blank line between blocks
- **No H2/H3 headings** — headings are for blog articles, not LinkedIn posts
- **Bold for narrative pivots only** — max 1-2 per post, not for emphasis within sentences
- **No em-dashes (—) or en-dashes (–)** — use periods, commas, or separate sentences
- **No bullet lists in the post body** — flowing prose only
- **No hashtags in body** — 3-5 at the bottom only if relevant
- **Under 1300 characters** for optimal reach — this is a ceiling, not a target

## Voice Rules

- **Contractions throughout** — don't, it's, you're, can't
- **Compressed sentences** — operator/executive tone, like someone who actually does the work
- **No buzzwords** — synergy, leverage, ecosystem, disrupt, game-changer, robust, proactive
- **No "we stopped chasing X"** — if Nava didn't do it, don't claim it
- **No strawmen** — acknowledge the other side's valid arguments first, then complicate them
- **"Nice dream. But impractical."** — the killshot idiom for hypotheticals (not "we never did that")
- **No em-dashes as sentence connectors** — short sentences beat dash-delayed sentences

## Paragraph Mechanics

**Paragraph 1 — Hook:**
The reader sees this before they click "see more." Make it visceral, specific, or confrontational. No context-setting.

**Paragraph 2 — Wrong question:**
Expose what the reader is getting wrong. The false binary, the bad assumption, the question that sounds right but isn't. Example: "EB-3 or TN? You're asking the wrong question."

**Paragraph 3 — Math or evidence:**
The number that reframes everything. Position it as the payoff. Don't bury it. "$40,000 to $80,000 per open req. Every six months." — not "research shows that vacancy costs..."

**Paragraph 4 — The right decision:**
What does the correct approach actually look like? This is where Nava enters naturally — what the parallel track or the right choice actually delivers.

**Paragraph 5 — CTA:**
Nava-specific. No hard sell. "No commitment required. Just the math." — never "contact us today to learn more."

## Transition Words

Every paragraph's first word should signal how it connects to what came before:
- **And** — continuation
- **Meanwhile** — contrast or simultaneous reality
- **Except** — the exception that reframes
- **Stop** — confrontational pivot
- **Here** — specificity
- **The facilities getting this right** — positive model
- **The question is not** — reframe
- **You do not have to** — the permission grant

## The Nava Closing Formula

Every post ends with:
1. What Nava does (specific, not a slogan)
2. An invitation without pressure ("No commitment required.")
3. A final line that lands clean — not promotional

**Bad closer**: "Nava Healthcare is committed to excellence in healthcare staffing. Contact us today!"

**Good closer**: "Nava Healthcare runs both tracks. We have for years. If you want to see what parallel track infrastructure actually looks like for your facility, we can walk through it. No commitment required. Just the math."

## Quality Checklist

- [ ] Hook would make you stop scrolling — does the first line do work?
- [ ] No context-setting opener — does paragraph 1 land visceral or confrontational?
- [ ] 5 paragraphs total — no more, no less
- [ ] Bold used once for narrative pivot only
- [ ] No em-dashes in body
- [ ] Transition word at start of each paragraph
- [ ] Math is positioned as payoff, not buried
- [ ] No strawmen — does paragraph 2 acknowledge the valid argument before dismantling it?
- [ ] "Nice dream. But impractical." for killshots
- [ ] Contractions throughout
- [ ] CTA is Nava-specific, not generic
- [ ] Under 1300 characters

## What to Ask the User

1. What's the topic or insight?
2. Is the hook a scene, a confrontation, or a number?
3. Is the Nava pivot already clear in your head?
4. Any specific math or evidence to include?
5. Send to Yosef for review, or approve to post?
