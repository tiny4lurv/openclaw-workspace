# SKILL.md — Gemini Deep Research

Use Gemini's Deep Research mode via the visible Chromium browser to conduct comprehensive, multi-source research on any topic. This is a slow, high-quality tool — expect 10–15 minutes per research run.

## Prerequisites

- Visible Chromium running at `localhost:18801` (remote debugging)
- Tab ID: `AD378E93BF8A442760F24992D4F49938`
- WebSocket: `ws://localhost:18801/devtools/page/AD378E93BF8A442760F24992D4F49938`
- Gemma3 vision model available at `http://localhost:11434` for screenshot analysis

## When to Use This

- Multi-source, comprehensive research on a topic
- SoT (State of Thought) research reports
- When Tiny asks to "research X" or "do deep research on Y"
- Not for quick lookups — this takes ~10–15 minutes

## The Workflow (MUST FOLLOW IN ORDER)

### Step 1 — Fresh Page
Navigate to `https://gemini.google.com/` and verify it's a **fresh conversation** ("Hi Tiny, where should we start?"). If an old conversation loads, close it first.

### Step 2 — Paste the Prompt
Use `Input.insertText` to paste the research prompt into the `contenteditable` div. Do NOT simulate typing — use `Input.insertText`.

```python
ws.send(json.dumps({"id": 2, "method": "Runtime.evaluate",
    "params": {"expression": "document.querySelector('[contenteditable]').focus()"}}).encode())
time.sleep(0.5)
ws.send(json.dumps({"id": 3, "method": "Input.insertText",
    "params": {"text": prompt}}).encode())
```

### Step 3 — Select Deep Research Tool (ONCE)
Click the **Tools button** in the prompt bar, then select **Deep research** from the dropdown. This is done ONCE — do NOT re-select it after submitting.

- Tools button position: ~(831, 522)
- Deep research option position: ~(934, 694)

### Step 4 — Submit
Click the **Send button** at ~(1455, 491).

### Step 5 — Wait for Research Plan (~30 seconds)
After submitting, wait ~30 seconds. A research plan will appear with:
- A structured outline of what Gemini will research
- **"Edit plan"** button (left)
- **"Start research"** button (right)

### Step 6 — Click "Start research" (ONLY this button)
Find and click ONLY the "Start research" button. Do NOT:
- Re-select Deep Research
- Press Enter
- Click "Edit plan"
- Click anywhere else

Button location (from DOM query):
- Index: 51 in `document.querySelectorAll('button')`
- Position: (1389, 616), size 150×40

```python
# Use JS click (most reliable)
code = """
var btns = Array.from(document.querySelectorAll('button'));
var btn = btns.find(b => b.textContent.trim() === 'Start research');
if (btn) { btn.click(); } btn.getBoundingClientRect(); }
"""
# OR use mouse click at (1389, 616)
```

### Step 7 — Wait for Research to Complete (~10 minutes)
Research runs in the background. Typical timeline:
- 1–2 min: "Analyzing results..." + website grid
- 5–10 min: Full report generates
- Do NOT interact with the page during this time

Check progress by taking a screenshot. Look for:
- "Analyzing results..." = in progress
- "Report ready" / new content in chat = complete

### Step 8 — Extract the Report
When complete, take a screenshot first to confirm, then extract the text content via DOM query or `sed` tag stripping from a page dump.

## Key Button Positions (2026-03-24, 1908×848 viewport)

| Element | Index | Position | Size |
|---|---|---|---|
| Tools button | — | (831, 522) | ~80×40 |
| Deep research option | — | (934, 694) | ~150×40 |
| Send button | — | (1455, 491) | ~80×40 |
| **Start research** | **51** | **(1389, 616)** | **150×40** |
| Edit plan | 50 | (1249, 616) | 115×40 |

## Python Control Script

```python
#!/usr/bin/env python3
import websocket, json, time, base64

TAB_ID = "AD378E93BF8A442760F24992D4F49938"
WS_URL = f"ws://localhost:18801/devtools/page/{TAB_ID}"

def ws_connect():
    ws = websocket.create_connection(WS_URL, timeout=10)
    ws.settimeout(15)
    return ws

def click(ws, x, y):
    ws.send(json.dumps({"id": 1, "method": "Input.dispatchMouseEvent",
        "params": {"type": "mousePressed", "x": x, "y": y, "button": "left", "clickCount": 1}}).encode())
    time.sleep(0.1)
    ws.send(json.dumps({"id": 2, "method": "Input.dispatchMouseEvent",
        "params": {"type": "mouseReleased", "x": x, "y": y, "button": "left", "clickCount": 1}}).encode())
    time.sleep(0.5)

def screenshot(ws, path):
    ws.send(json.dumps({"id": 99, "method": "Page.captureScreenshot",
        "params": {"format": "png"}}).encode())
    time.sleep(4)
    for _ in range(8):
        resp = ws.recv()
        data = json.loads(resp)
        if data.get('id') == 99:
            img = data['result']['data']
            with open(path, "wb") as f:
                f.write(img.encode('ascii'))
            return img
    return None

ws = ws_connect()
# ... workflow steps ...
ws.close()
```

## Report Extraction — Decoding Inline Image Numbers

Gemini renders ALL numeric data as inline base64 PNG images — NOT as readable text. The markdown download contains `![][imageN]` image references pointing to base64 data URIs. To extract the actual numbers:

### Step 1 — Extract all base64 images
```python
import re

with open("Travel Nurse Contract Research Request.md", "r") as f:
    content = f.read()

pattern = r'data:image/png;base64,([A-Za-z0-9+/=\r\n]+)'
matches = re.findall(pattern, content)
print(f"Total images: {len(matches)}")
```

### Step 2 — Decode images to PNG files
```python
import base64

for i, data in enumerate(matches):
    clean = re.sub(r'\s+', '', data)  # Remove whitespace
    missing = (4 - len(clean) % 4) % 4
    clean_padded = clean + '=' * missing  # Fix base64 padding
    png = base64.b64decode(clean_padded)
    with open(f"/tmp/research_img_{i+1}.png", "wb") as f:
        f.write(png)
```

### Step 3 — Read numbers with vision model
Send all images to gemma3:27b-cloud in one vision request:
```python
import base64, json, urllib.request

images = []
for i in range(1, len(matches)+1):
    with open(f"/tmp/research_img_{i}.png", "rb") as f:
        images.append(base64.b64encode(f.read()).decode())

payload = {
    "model": "gemma3:27b-cloud",
    "messages": [{"role": "user", "content": 
        "Read every number. Reply: img1 = [value], img2 = [value], etc.",
        "images": images}],
    "stream": False
}
req = urllib.request.Request("http://localhost:11434/api/chat",
    data=json.dumps(payload).encode(),
    headers={"Content-Type": "application/json"}, method="POST")
with urllib.request.urlopen(req, timeout=300) as r:
    print(json.loads(r.read())["message"]["content"])
```

### Step 4 — Build the number map and replace in markdown
```python
img_map = {
    1: "$39.4", 2: "63%", 3: "$24.2",  # ... all 62 values
}

# Remove reference definitions and data URIs
clean = re.sub(r'\[image\d+\]: .+?$', '', content, flags=re.MULTILINE)
clean = re.sub(r'data:image/png;base64,.+?$', '', clean, flags=re.MULTILINE)

# Replace ![][imageN] with actual values
def replace_ref(m):
    idx = int(m.group(1))
    return img_map.get(idx, f"[img{idx}]")

clean = re.sub(r'!\[\]\[image(\d+)\]', replace_ref, clean)

# Fix double-dollar artifacts
clean = clean.replace('$$5,000', '$5,000')
clean = clean.replace('$$ - $$', '–')

with open("travel_nurse_research_report.md", "w") as f:
    f.write(clean)
```

**Known image count:** 62 images (1–62). The img_map values vary per report — extract fresh each time.

## Troubleshooting

**"Start research" button not found in DOM:**
- The plan card may not have fully rendered. Wait 2 more seconds and re-query.
- Use `Array.from(document.querySelectorAll('button')).find(b => b.textContent.includes('Start'))` instead of exact match.

**Research plan doesn't appear:**
- The prompt may have been too long or the page didn't load correctly. Reload and start fresh.

**Button coordinates wrong:**
- Viewport size affects positions. Always re-query `getBoundingClientRect()` before clicking if last run was >1 hour ago.

**WebSocket timeout:**
- Recreate the connection. Sometimes the Chrome debugger connection drops.

## Important Rules

1. **Select Deep Research ONCE** — before submitting, not after
2. **Click ONLY "Start research"** — nothing else after submitting
3. **Wait 10 minutes** — don't check every 30 seconds
4. **Fresh page every time** — close old conversations before starting
5. **Let it cook** — don't improvise or deviate from the workflow
