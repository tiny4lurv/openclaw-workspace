---
name: article-revision-skill
description: "Execute a full article revision workflow: validate SoT, instruct AWAA with specific edits, run 6-pass editor review, check brand-integration and source-integration skills, and either approve for Tiny or send back to AWAA. Use when Tiny assigns an article revision task. NOT for initial drafting — this is a revision/refinement workflow only."
---

# Article Revision Skill

A multi-step revision workflow for polishing AWAA drafts to publication quality. Each revision cycle: instruct AWAA → editor review → Tiny or AWAA.

---

## Step 1 — SoT Validation

Before any revision work begins:
1. Confirm the SoT document exists and is a research document (not a previous draft of the same article)
2. State: `[SoT confirmed]: /path/to/SOT-document.ext`
3. If SoT is missing: `[SoT required]` — do nothing until provided

**SoT Location:** `~/.openclaw/workspace/rag_abroadworks/drafts/Contractor Non-Competes and Termination.odt`

---

## Step 2 — AWAA Instructions

Assemble a complete instruction packet for AWAA including:
- **Draft file:** `awaa-output/phase-5-full-draft.md`
- **Edits to apply:** specific changes from Tiny's line-by-line review
- **Structural changes:** which H3s to remove/merge (Tiny's decision)
- **Brand integration:** reveal pattern (see brand-integration skill)
- **Links to embed:** 5 external sources + up to 10 internal cross-links
- **SoT reference:** confirm SoT document name

**Instruction format:**
```
[AWAA Instruction Packet]
Draft: awaa-output/phase-5-full-draft.md
SoT: Contractor Non-Competes and Termination.odt (rag_abroadworks/drafts/)
[Specific edits from Tiny's review]
[Structural changes]
[Brand integration: reveal pattern]
[All 14 links with placement guidance]
Output: awaa-output/phase-5-revised.md
```

---

## Step 3 — Editor Review (6-Pass)

After AWAA delivers revised draft, run full 6-pass review:

**Phase 1 — Arc & Structure:**
- Pass 1.1: H2s form a coherent 3-4 act story
- Pass 1.2: H3 main ideas in temp notepad — flag overlaps/similarities
- Pass 1.3: Each paragraph supports its H3

**Phase 2 — Readability Sweep:**
- Pass 2.1: H2 intro previews (not parrots) the section's argument
- Pass 2.2: Paragraph transitions — logical thread, not just transition words
- Pass 2.3: MEAL plan check — Evidence is specific, Analysis is causal, Link connects to next paragraph

**Sub-checks (run as part of review, not after):**
- **Brand integration:** Run brand-integration skill. Zero brand mentions in body. Single earned reveal at section/article end.
- **Source integration:** Run source-integration skill. Links embedded at claims that benefit from citation. Anchor text is descriptive (4 words max).

---

## Step 4 — Decision Gate

**If polished → deliver to Tiny.**

**If improvements needed → return to AWAA with specific, targeted instructions.** Do not rewrite AWAA's content. Send back with explicit directives.

---

## Skills Required at Each Step

| Step | Skills |
|------|--------|
| Instruct AWAA | phased-outlining, brand-integration |
| 6-pass editor review | editor-skill |
| Brand check | brand-integration |
| Source/link check | source-integration (when formalized) |

---

## Relevant AWAA Instruction Reference (NC Article)

**Structural:** Remove H3.2.3 (redundant with H3.2.1 P2 after MEAL fix). H3.2.2: lead with case facts, then analysis.

**Brand integration:** Reveal pattern only. No brand mentions in body until section closer or article end.

**Links — 14 total:**
- External: EIG state map, IRS common law, IRS topic 762, Ontario non-compete ban, Epstein Becker Green year in review
- Internal: 7-figure EOR risk, bookkeeper-risk, outsourcing-vs-offshoring, async-work, outsourcing-customer-care, offshore-vs-local-labor, ai-customer-service-trap, offshore-bookkeeping, outsourcing-popularity

**Placement:** Cross-links in relevant body sections. External sources at first use of supported claim.