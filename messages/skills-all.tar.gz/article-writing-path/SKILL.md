---
name: article-writing-path
description: "The complete path from keyword selection to published AbroadWorks article. Use when creating a new AW article from scratch. Documents every step, the decisions made, the guardrails established, and the pitfalls encountered. This is the living record of how the NC article was built — and the process to replicate for Article 2 (How to Fire an Independent Contractor)."
---

# Article Writing Path

The complete record of how an AbroadWorks article is built. Every step, every decision, every guardrail. For use when writing any AW article.

---

## The 10 Steps

```
Step 1: Keyword Selection
Step 2: AWAA Spawn + H1 Approval
Step 3: H2 Structure → Tiny Approves
Step 4: H3 Sub-Headings → Tiny Approves
Step 5: Phase 4 Canvas → Tiny Approves
Step 6: Phase 5 Draft Generation (drafting-skill)
Step 7: Editor Review (editor skill — 6-pass review)
Step 8: Article Revision (article-revision-skill) + Source Integration (source-integration skill)
Step 9: Publishing Readiness (publishing-readiness skill)
Step 10: Final Save → abroadworks/
```

**Brand reveal rule:** Zero brand mentions in body. Single earned reveal at section end or article end. Specified in the initial AWAA brief at Step 2 — not added later.

**Phase gates are non-negotiable.** Steps 1-5 each require Tiny's explicit approval before proceeding. No skipping, no assuming.

---

## Step 1 — Keyword Selection

**What to do:**
1. Confirm keyword against live AW corpus (`rag_abroadworks/clean_md/`)
2. Verify related keyword pairs for cross-linking potential
3. Store keyword in article planning document

**Tool:** `grep` or `ls` on the corpus directory. Not memory — actual file check.

---

## Step 2 — AWAA Spawn + H1 Approval

**What to do:**
1. Spawn AWAA with topic, approved H1, primary keyword, reader context
2. **Include brand reveal rule in the initial brief:** "Zero brand mentions in body. Single earned reveal at section end or article end."
3. AWAA proposes H1 → Tiny approves

**File:** AWAA responds with only `[File written]: /path/to/file.md @aw` — no full text in chat.

---

## Step 3 — H2 Structure → Tiny Approves

**Skill:** phased-outlining (Phase 2)

**What to do:** AWAA proposes H2 structure mapping the article's argument arc. Tiny approves before Phase 4.

**Output:** H2 section headers (not full content) — the stages of the reader's journey from problem to solution.

---

## Step 4 — H3 Sub-Headings → Tiny Approves

**Skill:** phased-outlining (Phase 3)

**What to do:** For each H2, AWAA proposes 2-4 H3 sub-headings with one-sentence main ideas. Tiny approves before Phase 5.

**Rules:**
- Each H3 = one rhetorical move (one proof, one disruption, one example)
- H3s within an H2 should be parallel in type
- Main ideas are complete sentences, not topic labels

---

## Step 5 — Phase 4 Canvas → Tiny Approves

**Skill:** phased-outlining (Phase 4)

**What to do:** AWAA writes paragraph-level canvas — main idea + logical flow per paragraph. NOT prose. Structural planning only.

**Output:** For every H3: 2 paragraphs, each with main idea and logical flow. Includes H2 intros, callout quotes, FAQ section, Bottom Line framing.

**Rules:**
- 2 paragraphs per H3, 4-6 sentences each
- Every paragraph (except first in section) leads with a transition word
- No em-dashes, no contractions in formal articles
- No bold in body text
- Vocabulary variation: don't end paragraph N with a word family paragraph N+1 starts with

---

## Step 6 — Phase 5 Draft Generation

**Skill:** drafting-skill

**Input:** Approved Phase 4 canvas

**What to do:** AWAA converts approved canvas to full prose. 4-6 sentences per paragraph. MEAL plan applied to every paragraph.

**Output file:** `awaa-output/phase-5-full-draft.md`

**After Phase 5 delivery:** Run editor review (Step 7) beforeTiny sees it.

---

## Step 7 — Editor Review

**Skill:** editor skill (6-pass review)

**Trigger:** AWAA Phase 5 output

**What to do:** Run full 6-pass review (editor skill, Phase 1 + Phase 2). Verify with actual file reading — not mental assertions.

**Phase 1 — Arc & Structure:**
- Pass 1.1: H2s form a coherent 3-4 act story
- Pass 1.2: H3 main ideas — flag overlaps/similarities
- Pass 1.3: Each paragraph supports its H3

**Phase 2 — Readability Sweep:**
- Pass 2.1: H2 intros preview (not parrot) the section's argument
- Pass 2.2: Paragraph transitions — logical thread
- Pass 2.3: MEAL plan check — Evidence is specific, Analysis is causal, Link connects to next paragraph

**Decision gate:** If problems found → return to AWAA with specific instructions. Do not rewrite AWAA's content. If polished → proceed to Step 8.

---

## Step 8 — Article Revision + Source Integration

**Skills:** article-revision-skill + source-integration

### 8a — Article Revision

**Trigger:** Tiny assigns a revision task

**Skill:** article-revision-skill

**What to do:**
1. Validate SoT (confirm research document exists and is valid)
2. Assemble AWAA instruction packet (draft file + specific edits from Tiny's review)
3. Instruct AWAA with: specific edits, structural changes, brand reveal pattern, links to embed
4. AWAA delivers revised draft → run 6-pass editor review
5. Either approve for Tiny or send back to AWAA

**SoT Location:** `~/.openclaw/workspace/rag_abroadworks/drafts/`

### 8b — Source Integration

**Trigger:** Adding citations and cross-links to a near-final draft

**Skill:** source-integration

**What to do:**
1. Identify external sources (5 min, 8 max) from SoT bibliography — embed at first supported claim
2. Identify internal cross-links (up to 10) — confirm URLs live with web_fetch before embedding
3. Anchor text: natural phrase, NOT article title (4 words max)

**Rules:**
- External sources: embed at first use of the supported claim
- Internal cross-links: place where reader would naturally want more
- Anchor text = natural part of the sentence, not URL or "click here"

---

## Step 9 — Publishing Readiness

**Skill:** publishing-readiness

**Trigger:** Near-final draft after editorial revisions complete

**What to do:** Run three checks:
1. **Keyword audit:** Every phrase in the article's Keywords metadata line appears verbatim in body
2. **Heading signal:** H2s communicate topical relevance to crawlers without sacrificing readability (50 char max per H2)
3. **Secondary keyword scan:** Find semantic adjacencies worth adding naturally

**Rules:**
- Never rewrite body content for SEO
- Add secondary keywords only where the concept is already discussed
- H2s read in sequence should tell the complete story of the article

---

## Step 10 — Final Save

**What to do:**
1. Apply brand reveal (verify zero brand mentions in body, single earned reveal)
2. Save to `abroadworks/` as `[article-name]_Final-v1.md`
3. Keyword count verification
4. Git commit

---

## Guardrails — Non-Negotiables

1. **Never compress an AWAA system prompt.** H3 = 2 paragraphs is non-negotiable. If the prompt changes, Tiny approves.
2. **All verification checks read the actual file.** Assertions are not checks.
3. **Phase gates require explicit Tiny approval.** No skipping.
4. **Brand reveal rule in initial AWAA brief.** Zero brand mentions in body. Built in from the start, not added later.
5. **Nudge = nudge.** Solitary "?" means still here. Not a prompt, not a decision signal.
6. **Research before skill-building.** Don't write rules from memory.
7. **Keyword confirmed against live corpus before article planning.**
8. **Sprint check-ins: memory updates only.** No task systems.
9. **Table output for structured data.** Not narrative prose with embedded qualifiers.
10. **Article priority over skill-building.** Skills are built when there's a pause. Not during active article work.

---

*Last updated: 2026-04-13*
*Status: Revision + Source Integration formally added as Step 8*