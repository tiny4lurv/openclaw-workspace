---
name: drafting-skill
description: Use when converting an approved Phase 4 paragraph canvas into a full draft article. Triggers on "draft from canvas", "write from phase 4", "convert outline to prose", "write the article", "phase 5". This skill executes the prose layer — it does not plan, outline, or approve structure. That work is done in phased-outlining.
---

# Drafting Skill — Phase 5: Canvas to Prose

**Input:** Approved Phase 4 paragraph canvas
**Output:** Complete article with full prose paragraphs, all headings, intros, FAQs, and conclusion

**Prerequisite:** Phase 4 canvas must be approved before this skill runs.

---

## The Four-Step Method

### Step 1 — Convert Paragraph Ideas to Full Prose

**What to do:**
Read each paragraph's main idea and logical flow from the canvas. Write the full paragraph. Every sentence in the logical flow becomes an actual sentence in the prose. Do not add sentences that are not in the logical flow. Do not skip sentences from the logical flow.

**MEAL Plan (apply to every paragraph you write):**
- **Main**: State the paragraph's controlling idea clearly in one sentence. This is what the paragraph proves or argues.
- **Evidence**: Support the main idea with specific proof — stats, examples, mechanism details, test items, data. Do not just describe the concept; give the specific contents.
- **Analysis**: Explain *why* the evidence matters — the causal mechanism, the implication for the reader's situation. Show how the evidence leads to the conclusion.
- **Link/Transition**: End by signaling what the next paragraph will address, or by implicating the reader's next question.

**What each step prevents:**
- Main missing → paragraph has no controlling idea, drifts
- Evidence missing → paragraph announces rather than proves (three sentences doing the same job = evidence is missing)
- Analysis missing → paragraph states consequences without explaining why they follow
- Link missing → paragraph ends as a dead end, next paragraph feels disconnected

**Example (good MEAL application):**
> Main: "Non-competes are enforcement instruments, not ownership instruments."
> Evidence: "They restrict where a contractor can work after the engagement ends — a geographic exclusion that activates only at termination."
> Analysis: "If the contractor never terminates — if they simply add clients — the clause never activates. You paid for a safety net that requires the exact situation you wanted to avoid in order to function."
> Link: "This is why the first thing most owners get wrong about what they bought."

**What NOT to touch:**
- H2 and H3 headings (write around them, they stay as-is)
- H2 intro paragraphs (leave them alone in this step)
- The FAQ section (leave it alone in this step)
- The Bottom Line / conclusion (leave it alone in this step)
- The opening story (leave it exactly as provided)

**Rules for prose:**
- 4-6 sentences per paragraph
- Every paragraph (except first in a section) opens with a transition word
- No em-dashes, no contractions
- No bold in body text
- Primary keyword appears in H1, first paragraph, at least one H2, and conclusion
- "Perhaps" hedge only on counterfactual causal claims — never on analytical claims
- No Chinese characters or any other language leaks in English content

**Transition word library (by function):**
- Adding evidence: Furthermore, Moreover, In addition
- Contrast/concession: Yet, Nevertheless, Still, Despite this
- Causality: Consequently, Therefore, As a result
- Intensification: Worse, Beyond, Even more
- Example/illustration: For instance, Consider, Take the case of
- Concession: Although, Even if, Granted

**Output:** Write to `awaa-output/phase-5-full-draft.md`. Respond with only `[File written]: /path.md @aw`.

---

### Step 2 — Revise H2 Intro Paragraphs

**What to do:**
Read each H2 section. Check that the H2 intro paragraph accurately represents what the section actually covers. The intro should set up the argument arc of the section — not just introduce the topic broadly.

**What to check:**
- Does the intro reference the specific mechanism or evidence discussed in the H2?
- Does the intro create logical momentum toward the H3 arguments?
- Is the "because" or "so" or "yet" relationship between the intro and the section content clear?
- Does the intro use specific language from the section, not generic summaries?

**What NOT to do:**
- Do not turn the intro into a summary of everything in the section
- Do not list the H3 topics in the intro — that destroys the discoverability of the structure
- The intro is a loading dock — it gets the reader onto the right floor, not a map of the whole building

**If the intro needs revision:**
Revise it directly. Then write the revised version to the file.

---

### Step 3 — Check Transitions Between Paragraphs

**What to do:**
Use the transitions-skill (`transitions-skill/SKILL.md`) to audit and fix paragraph-to-paragraph transitions. This step is critical — transitions are not just "add a transition word at the start." The transition must carry the logical thread from one paragraph to the next.

**What to check:**
- Does the first sentence of each paragraph (after the first in a section) connect to the last sentence of the previous paragraph?
- Does each paragraph end with a pivot sentence that implicates reader agency?
- Does vocabulary at paragraph boundaries avoid repetition of the same word family?
- Do H2 intros transition correctly from the previous section's closing argument?

**See:** `transitions-skill/SKILL.md` for the full method.

---

### Step 4 — Check FAQs Against the Article

**What to do:**
Read each FAQ question. Verify that the answer can actually be derived from the article's content — not just the topic area, but the specific argument made. If a question asks about something the article only touches on briefly, revise the question to match what the article actually proves.

**What to check:**
- FAQ 1: Does the article actually explain the state/jurisdiction rule? Does the answer cover the contractor-living-in-a-different-state scenario?
- FAQ 2: Does the article actually explain IP assignment defaults? Does the answer cover what happens without an explicit assignment clause?
- FAQ 3: Does the article actually provide the checklist items? Would a reader know what to look for after reading?

**What to avoid:**
- FAQ questions that are answerable from general knowledge, not from the article's specific argument
- Questions that cover topics the article doesn't actually prove — don't ask about something you didn't establish
- Recycled versions of questions the reader already has from the opening story

**Revision:** If a question doesn't match the article's argument, revise the question to match. Then answer it based on what the article actually says.

---

## Output Format

**File:** `awaa-output/phase-5-full-draft.md`

**Next step:** Once Phase 5 draft is approved, Phase 6 (hook/intro) begins. See `phased-outlining/SKILL.md` — Phase 6. The hook is NOT generated as part of Phase 5.

**Structure:**
```
[META BLOCK — title, meta description, primary keyword, secondary keywords]

[OPENING STORY — do not touch, do not modify, insert as provided]

## H2.1 — Section Title
[H2 intro paragraph — may be revised in Step 2]

### H3.1.1 — Subheading
[Paragraph 1 — converted from canvas]
[Paragraph 2 — converted from canvas]

### H3.1.2 — Subheading
[Paragraph 1]
[Paragraph 2]

[Callout quote for H2.1 section]

## H2.2 — Section Title
[H2 intro paragraph]
[...H3 sections with paragraphs...]
[Callout quote]

[FAQ section — revised in Step 4]

[BOTTOM LINE — conclusion, do not touch unless Step 4 requires FAQ-driven revision]
```

---

## Quality Checklist

Before responding with `@aw`:
- [ ] All H3 subheadings present and match canvas
- [ ] All paragraphs are 4-6 sentences
- [ ] All paragraphs (except first in section) open with a transition word
- [ ] No em-dashes, no contractions
- [ ] No Chinese characters or other language leaks
- [ ] "Perhaps" used only on counterfactual causal claims
- [ ] Primary keyword appears in H1, first paragraph, at least one H2, conclusion
- [ ] H2 intros represent section content (Step 2 done)
- [ ] Paragraph transitions carry logical thread (Step 3 done)
- [ ] FAQ questions match article argument (Step 4 done)
- [ ] Opening story unchanged
