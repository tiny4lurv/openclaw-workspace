---
name: publishing-readiness
description: "Run a final SEO publishing check on a fully polished AbroadWorks article. Use on near-final drafts before publication — after editorial revisions are complete. Covers three checks: (1) keyword audit — every article keyword phrase appears in body, (2) heading signal — H2s communicate topical relevance to crawlers without sacrificing readability, (3) secondary keyword scan — finds semantic adjacencies worth adding naturally. Triggers on: SEO check, publishing readiness, keyword audit, pre-publish review, heading check."
---

# Publishing Readiness Skill

Run this on a fully polished article — after editorial revisions are done, before it goes live. The goal is not to rewrite the article. It is to catch SEO gaps that good writing misses.

---

## The Three Checks

### Check 1 — Keyword Audit

Every phrase in the article's **Keywords** metadata line must appear as an exact phrase in the body. Not as a variation. Not as a related term. The exact phrase.

**How to run:**
1. Extract the `**Keywords:**` line from the article
2. Split on commas — each item is a target phrase
3. Search body for each exact phrase using `grep -c "phrase"` or equivalent
4. Flag any phrase that does not appear verbatim

**Example keyword list:**
```
Keywords:** independent contractor non-compete, contractor non-compete clause, non-compete enforceability, contractor IP protection
```

**What to find in body:**
- "independent contractor non-compete" — must appear exactly
- "contractor non-compete clause" — must appear exactly
- "non-compete enforceability" — must appear exactly
- "contractor IP protection" — must appear exactly

**If a keyword is missing:** Add it naturally in the section where the concept is already being discussed. Do not force it. Find the paragraph that covers the concept and insert the exact phrase where it fits grammatically.

---

### Check 2 — Heading Signal

Each H2 must communicate its topical subject to a search engine crawler AND read like a chapter title in a coherent story. The two requirements are not in conflict.

**The principle:** H2s should read like chapter titles in a story, not SEO templates. They can be descriptive without being keyword-stuffed. The primary keyword lives in the first H2 and throughout the body — subsequent H2s refine and continue the argument.

**The test:** Read only the H2 text. Can you determine what this section covers? Does it continue the story the article is telling?

**Two failure modes:**

**Failure 1 — The clever headline:** Written for narrative, ignores crawlers.
```
The Control Contradiction
```
Problem: Tells readers there's a contradiction involving control. Tells crawlers nothing about employment classification or misclassification.

Revision principle: Lead with the primary keyword in the first H2. After that, use shorthand that continues the argument — the article's topic is already established.

Revision: First H2 → `Independent Contractor Non-Competes: The Promises and the Gaps`
Second H2 (shorthand) → `The Non-Compete Contradiction: Misclassification Risk`

**Failure 2 — The over-long heading:** Tries to be complete and loses its readability.
```
Why the Geographic Patchwork Makes the Protection Feel Absolute When It Is Not
```
Problem: 83 characters. Buries the concept. Hard to scan. Reads like a table of contents entry, not a chapter title.

Revision: `Why Geographic Gaps Undermine Non-Compete Protection` — 7 words. Concept up front.

**Rules:**
- First H2: lead with primary keyword phrase
- Subsequent H2s: use shorthand that continues the argument — the article's topic is already established
- H2 character limit: 50 characters absolute max. 40 or under where possible.
- Every H2 should front-load its primary concept
- H3s are subordinate to their parent H2 — they can be longer and more narrative
- H2s should refine and continue the argument, not just label sections

**Tone principle:** Write H2s the way compelling non-fiction chapter titles sound. "Effective Tools That Protect Your Business" is better than "What Actually Protects You" — active, positive, practical. "When Non-Compete Agreements Are Worth the Effort" is better than "When to Use" — it signals cost-benefit thinking.

**The reader-intent principle:** H2s should encode the reader's intent back to them. A worried founder reads "The Non-Compete Contradiction: Misclassification Risk" and thinks "yes, that's my situation." The heading tells them the section has what they came to find.

**The story principle (critical):** H2s read in sequence should tell the complete story of the article — even without the body text. The reader should know what the article is about from the headings alone. Compare:

Bad — six section labels that could belong to any article:
1. The Promise and the Gap
2. The Control Contradiction
3. What Actually Protects You
4. When It Might Be Worth Using
5. Frequently Asked Questions
6. Bottom Line
→ No arc, no story, no argument.

Good — a narrative arc in heading form:
1. Independent Contractor Non-Competes: The Promises and the Gaps — establishes the arc
2. The Non-Compete Contradiction: Misclassification Risk — introduces the central problem
3. Effective Tools That Protect Your Business — pivots to solution
4. When Non-Compete Agreements Are Worth the Effort — qualified acknowledgment
5. Frequently Asked Questions — practical close
6. Bottom Line — resolution

Read together: what it is → the problem → the solution → the exception → practical → done. The reader knows the article's argument before reading the first body sentence.

---

### Check 3 — Secondary Keyword Scan

Find semantic adjacencies — search terms that share search intent with the article's primary keyword but target adjacent queries — and add them where they fit naturally.

**What to look for:**
- Concepts the article already discusses in depth but does not name explicitly
- Search queries a reader with this problem would actually type
- LSI is outdated — Google does not use it (John Mueller confirmed). Focus on **semantic keywords**: thematically related terms that expand topical coverage

**Finding candidates:**
- Google the primary keyword. Read the "People Also Search For" and autocomplete suggestions. These are the queries your article should touch.
- Ask: what would a founder搜索 (search) who needs this article? What related problems do they have?

**Examples from the NC article:**

The article discusses IP ownership extensively but never uses "contractor IP protection" as a phrase — a real search query. Added naturally in H2.3 intro:
> "If the non-compete is the wrong tool for **contractor IP protection**, the question becomes what the right tools are."

The article covers geographic enforceability but never uses "non-compete enforceability" as a standalone phrase — in the keyword list but missing from body. Added in H2.2 intro:
> "the legal framework around **non-compete enforceability** is geographically fragmented"

Both insertions are: (a) already discussing the concept, (b) adding the exact phrase a searcher would type, (c) grammatically natural.

**Constraint:** Add secondary keywords only where the article has already earned the context. Never introduce a concept solely for SEO. If the paragraph does not already cover the idea, the keyword does not belong there.

---

## Decision Rules

| Situation | Action |
|-----------|--------|
| Keyword missing from body | Add naturally in relevant section |
| H2 does not signal topic to crawlers | Revise H2 — front-load topic, keep readable |
| H2 is overlong (>50 chars) | Trim — cut the flair, keep the topic |
| Secondary keyword candidate found | Add only if concept already discussed in that paragraph |
| Concept covered but phrase not used | Insert exact phrase where grammatically natural |
| Heading works narratively AND body has topical signal | Leave unchanged |

**Never rewrite body content for SEO.** The editorial passes have already done that work. This skill is for gaps — keyword phrases, heading signals, semantic adjacencies.

---

## SEO Publishing Checklist

Run through before declaring an article ready:

- [ ] All keyword list phrases appear verbatim in body
- [ ] Each H2 signals its topic to crawlers
- [ ] No H2 exceeds ~50 characters
- [ ] H1 contains primary keyword
- [ ] Primary keyword in first 100 words of intro
- [ ] Secondary keyword candidates identified and inserted where earned
- [ ] Internal cross-links embedded (5-15 per article — use source-integration skill)
- [ ] Meta description 140-160 characters
- [ ] Title tag 50-60 characters (if separate from H1)
- [ ] External sources embedded where claims are made (source-integration skill)