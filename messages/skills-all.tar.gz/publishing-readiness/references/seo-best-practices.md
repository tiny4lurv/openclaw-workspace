# SEO Best Practices Reference

Sourced from current research (2025-2026).

---

## Keyword Placement

**Primary keyword:**
- Title tag: near the beginning
- H1: exact match
- First 100 words of intro: once
- At least one H2 heading
- Image alt text if applicable

**What Google actually rewards:** Semantic keywords — thematically related terms throughout the body. Google does NOT use LSI (confirmed by John Mueller, 2019). It uses NLP and knowledge graph to understand topical depth.

**Finding semantic keywords:**
- Google Autocomplete: type seed term, capture bold completions
- "People Also Search For" boxes
- Semrush Keyword Magic Tool
- Google NLP API (advanced)

---

## Heading Tags (H1-H3)

**Rules:**
- One H1 per page (contains primary keyword)
- H2s divide content into main sections (3-6 per article typical)
- H3s subordinate to H2s — never skip hierarchy (no H1→H4)
- H2 character limit: 30-40 ideal, 50 absolute max
- Primary keyword in at least one H2
- H3s can be longer and more narrative

**SEO purpose of H2s:** Each H2 signals a subtopic. Crawlers read them to understand article structure and topical coverage. The heading should front-load the concept — words at the beginning carry more weight.

**Heading signal test:** Read only the H2 text. Can you determine what the section covers? If not, revise.

**Editorial vs SEO headings:** Editorial headings are written for narrative logic. SEO headings need to be descriptive and keyword-adjacent. The solution is NOT to abandon editorial headings — it is to ensure each H2, while remaining readable, is scoped so crawlers can parse its topic. An H2 can do both jobs if it front-loads the topic.

---

## Secondary / Semantic Keywords

**What they are:** Search terms sharing intent with the primary keyword but targeting adjacent queries. They expand topical coverage and signal comprehensiveness to Google.

**NOT synonyms.** "IC" and "independent contractor" are the same concept — not two keywords. Secondary keywords are distinct queries: "non-compete enforceability", "contractor IP protection", "independent contractor misclassification".

**Where they live:** In the body where the concept is already being discussed. If a paragraph covers IP ownership but never uses "contractor IP protection" as a phrase, that phrase is a secondary keyword candidate.

**Finding candidates:**
1. Google the primary keyword
2. Note "People Also Search For" and autocomplete suggestions
3. Ask: what would a worried founder search?
4. Check if article covers the concept — if yes, add the exact phrase naturally

**Constraint:** Only add where the article has already earned the context. Never introduce a concept solely for SEO.

---

## What the Rohit Audit Says (June 2025)

- Word count target: 2,000–3,000 words (above top-ranking pages for the query)
- Internal links: 5-15+ per article
- External links: 2-5+ to credible sources
- Meta description: 140-160 characters
- Title tag: 50-60 characters
- Primary keyword in: title, H1, meta description, first 100 words, at least one H2, URL slug
- LSI keywords: each mentioned 2-7 times throughout