---
name: note-taking
description: Use when Tiny asks you to take notes during a teaching session, file review, or transcript analysis. Enforces writing-first behavior: journal before response, timestamped entries, immutable after session end. Triggers on: take notes, journal, distill insights, write down what you're learning, note-taking period.
---

# Note-Taking Skill — Enforced Writing-First Behavior

## Purpose
Forces you to distill and write down key insights before responding. Prevents mental notes and ensures learning gets captured. Used when Tiny is actively teaching or correcting.

## Core Rules (Non-Negotiable)

**1. Journal before response.**  
When Tiny says "take notes" or "I'm teaching you something," you MUST write to the journal BEFORE you give any response. Not after. Not in parallel. Writing first, then response.

**2. Session-bound journal.**  
Each note-taking request gets its own time-bound journal. While the session is active (you're still processing his teaching), you can append, edit, or delete entries. Once the session ends (he moves on or says we're done), the journal becomes immutable — no more changes.

**3. Write as you go.**  
Don't wait until you've read everything. If you read a chunk and something is worth noting — even 0.3% of the session — write it down before continuing. Notes accumulate in real time.

**4. No back-editing after contradictions.**  
If later notes contradict earlier ones, leave both. Contradictions are data — analyze them after the session ends, not during.

**5. Date and timestamp everything.**  
- Live session notes: timestamp with current time  
- Past session notes: journal date = when you took the notes; each entry tagged with the source session date  

## Implementation

### Journal Location
`~/memory/note-taking/YYYY-MM-DD_HH-MM-SS.txt`  
Format ensures sortability and immutability after creation.

Each journal file contains:
```
# NOTE-TAKING SESSION
Started: YYYY-MM-DD HH:MM:SS
Source: [live session or file path]
Rules: [referencing this skill]
```

Then the timestamped entries:
```
[HH:MM:SS] Key insight distilled from what Tiny said...
[HH:MM:SS] Correction received: specific rule to follow...
[HH:MM:SS] Pattern observed: behavior to encode...
```

### Entry Format
`[HH:MM:SS] <insight>` — 24-hour time, bracketed, single space, then the distilled thought.

### Session Boundaries
- **Start:** When Tiny says "take notes" or begins a teaching block  
- **End:** When he says we're done, changes topic, or clearly moves on  
- **Immutability:** Journal file cannot be modified after end timestamp

## Workflow Examples

### During Live Teaching
Tiny: "Let me show you how I edit H3s..."  
You: [open journal, write first insight]  
You: [respond after writing]

### During File Review
Tiny: "Read this session file and take notes..."  
You: [open journal, write first notable thing from first chunk]  
You: [continue reading, write more as you go]  
You: [respond after session ends]

### During Transcript Analysis
Tiny: "Analyze these edits and tell me what patterns you see..."  
You: [open journal, write first pattern from first edit]  
You: [continue analysis, write more patterns]  
You: [respond after session ends]

## Quality Checks
Before responding after a note-taking session:
- [ ] Journal file exists and has content
- [ ] First entry timestamps after the note-taking request
- [ ] Entries are chronological
- [ ] Each entry contains a distilled insight, not verbatim transcription
- [ ] No mental notes claimed — everything is in the journal

## Reference Documents
- Template: `skills/note-taking/templates/journal-template.txt`
- Example: `skills/note-taking/references/example-journal.txt`

*Last updated: 2026-04-13*