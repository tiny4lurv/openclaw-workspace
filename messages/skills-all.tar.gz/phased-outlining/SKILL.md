---
name: phased-outlining
description: "Use when asked to plan, outline, or architect a long-form article, blog post, or content piece. Triggers on outline, plan content, build structure, create canvas, article architecture, content scaffolding. Covers Phases 1-4 only: H1 approval, H2 structure, H3 sub-headings, and paragraph canvas. Phase 5 (draft prose) not included. MANDATORY: AWAA must validate a Source of Truth (SoT) research document before any article work begins."
---

# Phased Outlining — Article Architecture Methodology

**MANDATORY: Source of Truth (SoT) Validation — Before Any Work Begins**

AWAA must validate a Source of Truth research document before Phase 1 begins. This is non-negotiable.

**SoT Validation Rules:**
1. AWAA must be provided a research document (PDF, DOCX, ODT, MD, or similar) — not a previous draft of the same article
2. Before Phase 1, AWAA states: `[SoT confirmed]: /path/to/SOT-document.ext @aw` and names the document
3. If no SoT is provided: AWAA responds `[SoT required]: No research document provided. Awaiting SoT before beginning. @aw` and does nothing else
4. All substantive claims in the article must trace to the SoT. If the SoT does not support a claim, AWAA flags it and awaits guidance before including it
5. AWAA confirms the SoT again at Phase 4 canvas delivery, referencing it by document name

**What is NOT a valid SoT:**
- A previous draft of the same article being worked on
- A style guide or template
- A corpus of other articles

**What IS a valid SoT:**
- A research report with cited sources (internal citations, footnotes, or bibliography)
- A government publication, legal resource, or statistical source
- A primary source document relevant to the article's claims

**SoT Location Format:** State the SoT path explicitly in your phase output header.

# Phased Outlining — Article Architecture Methodology

A strict multi-phase workflow for building a long-form article or blog post. Each phase gates the next. The writer does not move to prose until the editor approves the structure through Phase 4.

**The five phases:**
1. H1 approval
2. H2 structure proposal
3. H3 sub-headings with main ideas
4. Paragraph canvas (main idea + logical flow per paragraph)
5. Full draft prose (Phase 5 — see drafting-skill)

**Phase 6 (hook/intro) runs after Phase 5 is complete and approved.**

---

## The Four Phases

### Phase 1 — H1 Approval

**Input:** Topic, reader context, key facts, hook approach

**Output:** Approved H1 headline

The H1 must state the core promise of the article in concrete, specific terms. No vague headers. The reader should know exactly what they will get.

**Example H1:** "Independent Contractor Non-Compete: What It Actually Covers (and What It Doesn't)"

Present one H1 option. Wait for approval before Phase 2.

---

### Phase 2 — H2 Structure Proposal

**Input:** Approved H1

**Output:** H2 section headers that map the article's argument arc

Each H2 is a stage in the reader's journey from problem to solution. The H2s are not topics — they are rhetorical moves.

**Structure types:**
- **Problem → Disruption → Solution:** H2.1 names the false belief, H2.2 dismantles it, H2.3+ provides the right answer
- **Diagnostic → Evidence → Resolution:** H2.1 explains the mechanism, H2.2 shows the evidence (case study, data), H2.3 gives the prescription
- **Setup → Conflict → Resolution:** H2.1 establishes context, H2.2 introduces the tension, H2.3 resolves it

Present H2 structure with brief rationale. Wait for approval before Phase 3.

---

### Phase 3 — H3 Sub-Headings with Main Ideas

**Input:** Approved H2s

**Output:** For each H2, 2-4 H3 sub-headings. Each H3 has a one-sentence main idea stating what that section proves or establishes.

**Rules:**
- Each H3 = one rhetorical move (one proof, one disruption, one example)
- H3s within an H2 should be parallel in type — if H3.1 is a mechanism, H3.2 should also be a mechanism, not a case study
- Main ideas are complete sentences. "Why the geographic patchwork makes protection feel absolute when it isn't" — that is not a main idea. "The non-compete feels solid because legal language creates the impression of proportional protection, but jurisdiction determines enforceability, not contract quality" — that is a main idea.

Present H3 structure. Wait for approval before Phase 4.

---

### Phase 4 — Paragraph Canvas

**Input:** Approved H3s

**Output:** For every H3, two paragraphs with:
- **Paragraph 1 main idea** — the central claim
- **Paragraph 1 logical flow** — the sentence-by-sentence argument arc (what each sentence does)
- **Paragraph 2 main idea** — the supporting or contrasting claim
- **Paragraph 2 logical flow** — the sentence-by-sentence argument arc

Also include:
- H2 contextualizing intro paragraphs (one per H2)
- Callout quote for each H2 section
- FAQ section (3 questions, each with unique operational anxiety)
- Bottom Line closing framing

**Logical flow format:**
```
- Start with: [what sentence 1 does]
- Establish: [what sentence 2 does]
- Illustrate: [what sentence 3 does]
- Close with: [pivot sentence implicating reader's agency]
```

**Rules:**
- 2 paragraphs per H3, 4-6 sentences each
- Every paragraph (except first in a section) leads with a transition word
- No em-dashes, no contractions in formal articles
- No bold in body text
- Vocabulary variation: don't end paragraph N with a word family that paragraph N+1 starts with

**Transition words by function:**
- Adding evidence: Furthermore, Moreover, In addition
- Contrast/concession: Yet, Nevertheless, Still, Despite this
- Causality: Consequently, Therefore, As a result
- Intensification: Worse, Beyond, Even more
- Example/illustration: For instance, Consider, Take the case of
- Concession: Although, Even if, Granted

Present full canvas. Wait for approval before proceeding.

---

## Phase 6 — Hook/Intro (After Phase 5 Approval)

**Trigger:** Phase 5 full draft is complete and approved by editor.

**Purpose:** The hook/intro is written AFTER the full arc is known. The writer knows the article's full argument — the hook must make a reader stop mid-scroll before they see it. This is a different weapon from the body prose: bare-knuckle, edgy, emotionally confrontational.

**Input:** Approved Phase 5 full draft (complete article with H2s, H3s, body, FAQs)

**Output:** 2-3 hook/intro options, each exactly 2 paragraphs, separated from the article by a blank line after the H1

**Rules:**
- Hook goes between H1 and H2.1 — it does NOT replace H2.1's intro
- H2.1's intro remains untouched; it is NOT rewritten to match the hook's tone or content
- 2 paragraphs only — no structural headers, no H2s, no H3s
- Does NOT use "this article," "in this section," "by the end of this"
- Does NOT mention the brand (AbroadWorks) — brand comes in H2.3/H3.4 only
- No contractions (same formality standard as body)
- The hook is NOT a summary of the article
- The hook implies the stakes — makes the reader feel the problem before they understand the solution
- Must create enough tension that the reader keeps going, not enough that they feel satisfied and leave

**AWAA's job:** Pitch 2-3 options with distinct angles (e.g., emotional/visceral, data-implied, contrast-based). Each option is standalone and replaceable — any can be chosen without breaking the article.

**Editor (Dawn)'s job after AWAA pitches:**
1. Evaluate each option against the article's actual argument arc
2. Check for self-references, structural headers, or brand mentions
3. Check that the hook leads naturally into H2.1 without tonal whiplash
4. Flag any phrase that mirrors H2.1's opening too closely ("Most founders..." clashing with a hook that also opens with "Most founders..." etc.)
5. Edit for polish and structural fit
6. Present final version to Tiny for approval

**Tiny's approval is final.** Once approved, the hook is prepended to the draft as:
```
# [Article H1]

[2-paragraph hook/intro]

## H2.1 — [existing H2.1 title]

[existing H2.1 intro — unchanged]
...
```

**File output:** Write approved hook to `awaa-output/phase-6-hook-intro.md`. The final integrated article (H1 + hook + Phase 5 draft) is assembled by the editor.

---

## Critical Rules

### Phase Gates Are Non-Negotiable

Each phase requires explicit approval before the next begins. Skipping or abbreviating phases produces structurally weak content. The editor reviews each phase. The writer does not move to the next phase without explicit sign-off.

### Editor Role

The editor reviews each phase against these standards:
- Does the structure match the article's argument arc?
- Are main ideas actually claims (not topics)?
- Do logical flows explain WHY, not just WHAT?
- Do paragraph closings implicate reader agency?
- Is vocabulary varied at paragraph boundaries?
- Are transition words at paragraph openings?
- Is the "perhaps" hedge used correctly (counterfactuals only)?
- Are there Chinese characters or other language leaks?

The editor sends back specific, targeted revision requests. Vague rejections are not helpful — state exactly what needs to change and why.

### Writer Role

The writer (human or AI) generates per phase specs. The writer waits for approval. The writer does not interpret "ready when you are" as approval. The writer does not skip to the next phase without explicit sign-off.

### File Output Rule

All phase outputs are written to:
`/home/tiny4lurv/.openclaw/workspace/awaa-output/phase-N-description.md`

The writer responds with only:
`[File written]: /path/to/file.md @aw`

No full text in chat. The file is the output.

---

## Reference Files

See `references/phase4-example.md` for a complete Phase 4 canvas example (Independent Contractor Non-Compete article).
