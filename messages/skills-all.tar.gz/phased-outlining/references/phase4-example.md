# Phase 4 Canvas — Complete Example

**Article:** Independent Contractor Non-Compete: What It Actually Covers (and What It Doesn't)
**Date:** April 2026

This is the complete Phase 4 canvas that was approved before the Phase 5 draft was written. Use this as the reference example when building future Phase 4 canvases.

---

## META BLOCK

**Title:** Independent Contractor Non-Compete: What It Actually Covers (and What It Doesn't)
**Meta Description:** Most micro-business owners include a non-compete in their contractor agreements thinking it protects their client relationships and proprietary knowledge. It rarely does. Here is what actually works.
**Keywords:** independent contractor non-compete, contractor non-compete clause, non-compete enforceability, contractor IP protection

---

## HOOK / OPENING

**Opening Story (provided, do not change):**
An employee spent 8 months developing and building sales funnels and marketing material for a small business. The business started gaining edge in the local market. The employee resigned and reached out to competitors with email sequences, ad copy, and information about internal process in exchange for a lump sum. The original employer lost the ground they had gained and believed enforcing a strict non-compete clause would have prevented this loss.

**Note:** The employer did NOT have the non-compete. The story is about the ASSUMPTION — the employer believed one would have prevented the loss. This is the belief the article dismantles.

---

## H2.1 — THE PROMISE AND THE GAP

### H2.1 Intro Paragraph

The story above captures a fear that lives in every founder who has ever handed a contractor the keys to their customer acquisition system. That fear is real. The protection most people reach for, the non-compete clause, is not where that protection lives. Most states allow non-competes for independent contractors. That fact makes them feel like a legitimate shield. They are not. The gap between what the clause promises and what it actually delivers is wider than most people realize, and understanding that gap is the first step toward building something that actually works.

**[PARAGRAPH 1 — H2.1 intro: 5 sentences, sets up the disconnect between promise and protection]**

---

### H3.1.1 — What the Clause Actually Restricts

**Paragraph 1 — Main idea:** The non-compete does not restrict what the contractor knows or what they do with that knowledge. It restricts where they can physically work — which is meaningless if they operate online or across state lines.

**Paragraph 1 — Logical flow:**
- Start with the core mechanic: non-competes are geographic restrictions on employment or business activity
- Illustrate why this is irrelevant for online contractors: location-based restrictions cannot stop someone from serving clients remotely from anywhere
- Transition to the pain point: the clause protects against a 1950s manufacturing scenario, not a modern knowledge-economy relationship
- Close with reader implicating question about what they actually need to protect

**Paragraph 2 — Main idea:** The information asymmetry problem is fundamentally not addressed by a non-compete. The contractor can carry your pricing model, your outreach scripts, and your conversion data out the door on a laptop. A location restriction stops none of it.

**Paragraph 2 — Logical flow:**
- Bridge: Beyond location, the real value is informational
- Explain what the contractor actually takes: client data, process knowledge, strategic frameworks
- Illustrate with concrete example from the opening story: email sequences and ad copy are the asset, not the physical territory
- Pivot sentence: if geographic restriction is the tool and the threat is informational, you are using the wrong tool entirely

---

### H3.1.2 — The Enforceability Landscape

**Paragraph 1 — Main idea:** The clause is not just limited — it is outright void in four states, and those are not exotic outliers.

**Paragraph 1 — Logical flow:**
- Lead with the four void states: California, Minnesota, North Dakota, Oklahoma
- Address the immediate objection: these are not small or irrelevant markets
- Show the math: California alone represents the 5th largest economy in the world
- Transition: even in states where the clause is technically enforceable, thresholds apply

**Paragraph 2 — Main idea:** The thresholds that apply in Washington and DC are not minor obstacles — they are structural gates that eliminate most small and micro business contractor relationships from protection entirely.

**Paragraph 2 — Logical flow:**
- Bridge: Furthermore, enforceability is not binary — it is threshold-dependent
- Washington threshold: $317,147.09 (annual compensation or contract value)
- DC threshold: $162,164
- Illustrate the practical implication: a contractor billing $25,000 for a three-month engagement falls below both thresholds in most configurations
- Close with reader implicating pivot: if your contractor arrangements do not clear the threshold, the clause you rely on is decorative

---

### H3.1.3 — Why the Geographic Patchwork Makes the Protection Feel Absolute When It Is Not

**Paragraph 1 — Main idea:** The clause feels solid because it sits in a contract, contracts feel binding, and most founders have never had a contractor challenge it. That feeling of solidity is not the same as legal protection.

**Paragraph 1 — Logical flow:**
- Lead with the psychological mechanism: contracts feel permanent because they are documents
- Explain why this feeling is misleading: enforceability depends on the state where the contractor physically works, not where the business is headquartered
- Illustrate: a Colorado founder with a Georgia-based contractor has a clause that may be enforceable in Georgia but irrelevant in Colorado
- Transition to the deeper problem: the contractor does not need to challenge the clause for it to be worthless — the clause simply does not apply to their situation

**Paragraph 2 — Main idea:** The result is a false sense of security. The founder believes they are protected, acts accordingly, and discovers the gap only when the worst happens.

**Paragraph 2 — Logical flow:**
- Bridge: Worse, this gap is not visible until it is too late
- Describe the moment of discovery: contractor leaves, takes client data, begins working for a competitor, founder pulls out the contract and realizes the clause was never enforceable in the contractor's state
- Explain the compounding problem: by the time you discover the gap, the damage is done and legal recourse is expensive and uncertain
- Close with pivot: feeling protected is not the same as being protected; the distinction costs money when it matters most

---

**Callout Quote — H2.1:**
> ***"The non-compete protects a geographic territory that no longer exists in the knowledge economy. Your customer list is not a location."***

---

## H2.2 — THE CONTROL CONTRADICTION

### H2.2 Intro Paragraph

There is a second problem with non-competes that most articles do not mention, and it runs in the opposite direction. The clause does not just fail to protect you. Used aggressively, it can actively create liability. This is the control contradiction, and it is the most counterintuitive and consequential flaw in the standard approach to protecting contractor relationships.

**[PARAGRAPH 1 — H2.2 intro: 5 sentences, sets up the inversion — enforcement creates liability, not just weakness]**

---

### H3.2.1 — The Mechanism: Enforcement Becomes the Evidence of Misclassification

**Paragraph 1 — Main idea:** Courts determine whether a worker is an employee or an independent contractor by looking at the degree of control the hiring business exercises. The more control you exert, the more an employment relationship looks like it exists. Non-competes are a control mechanism.

**Paragraph 1 — Logical flow:**
- Lead with the misclassification test: the multi-factor test looks at behavioral control, financial control, and relationship type
- Explain the connection: a non-compete clause signals that the hiring business expects to control where the worker can and cannot work
- Illustrate: if you are telling a contractor where they cannot work, you are asserting the kind of control that defines an employment relationship
- Transition: this matters because misclassification carries its own serious consequences

**Paragraph 2 — Main idea:** The enforcement action itself becomes the evidence. When you send a cease-and-desist or file an injunction over a contractor violation, you are demonstrating to a court that you treated this person as an employee in practice.

**Paragraph 2 — Logical flow:**
- Bridge: Consequently, the more seriously you enforce the clause, the more you confirm the characterization that undermines your legal position
- Explain the practical loop: enforce the non-compete → court examines the relationship → finds excessive control → reclassifies as employment → now you owe back wages, benefits, and payroll taxes
- Address the irony: you used the clause to protect yourself; the clause is now the exhibit in a case that costs you far more than the original breach would have
- Close with pivot: if enforcement can trigger liability, the clause is not protection — it is a trapdoor

---

### H3.2.2 — The Chavez-DeRemer Case: $9M Judgment Where the Non-Compete Was the Exhibit, Not the Primary Liability

**Paragraph 1 — Main idea:** The Chavez-DeRemer judgment (2024) illustrates exactly how this trapdoor opens. The primary liability was not breach of contract — it was misclassification, and the non-compete was part of the behavioral evidence that proved it.

**Paragraph 1 — Logical flow:**
- Lead with the outcome: $9 million judgment, misclassification as the core liability
- Explain the chain: the business used non-competes to restrict contractor movement → the court read those restrictions as evidence of employment-level control → the misclassification claim succeeded because the control was documented in the contracts
- Illustrate the point: the non-compete was not the cause of the lawsuit, it was the smoking gun in a lawsuit about something else entirely
- Transition: this case is not an anomaly — it is a pattern that plays out in various configurations across jurisdictions

**Paragraph 2 — Main idea:** The lesson is not that you should avoid non-competes. The lesson is that non-competes in the wrong context are not just ineffective — they are counter-productive. They generate the very liability they were meant to prevent.

**Paragraph 2 — Logical flow:**
- Bridge: The logical chain is direct: if the non-compete demonstrates control → and control demonstrates employment → then using the clause aggressively means you were treating the contractor as an employee
- State the implication plainly: you cannot assert employee-level control over a contractor and then deny the employment relationship when it suits you
- Close with pivot: the $9 million check was not for violating the non-compete; it was for treating someone like an employee when you called them a contractor

---

### H3.2.3 — The Irony: The More You Try to Protect, the More You Demonstrate Economic Dependence

**Paragraph 1 — Main idea:** Beyond the legal mechanics, there is an economic dimension. Courts look at whether a worker is economically dependent on the hiring business or whether they operate as an independent business entity. Aggressive non-compete enforcement highlights your dependence on that worker.

**Paragraph 1 — Logical flow:**
- Economic dependence is the state in which a contractor's primary income flows from a single client, making the contractor functionally indistinguishable from an employee in economic substance. Courts examine whether the relationship has this characteristic regardless of what the contract labels it.
- Explain the contradiction: when a business enforces a non-compete to prevent a contractor from working for competitors, it reveals how essential that contractor's knowledge is to the business operations
- Illustrate: if the contractor's departure poses an existential threat to your client relationships, the court reads that as economic dependence — which is the definition of employment
- Transition: the more you protect the relationship through contractual restriction, the more you demonstrate the kind of dependency that reclassifies it

**Paragraph 2 — Main idea:** This creates a structural bind. The business that most needs protection is the one whose protective actions most clearly signal the employment relationship that voids their protection.

**Paragraph 2 — Logical flow:**
- Bridge: Ultimately, this bind punishes the founders who are most thoughtful about protecting their businesses
- Explain the irony: the founder who includes a non-compete because they understand the value of their proprietary systems is simultaneously demonstrating that those systems are so core to the business that the contractor cannot be genuinely independent
- Describe the reader's situation: if you are reading this article, you are probably the thoughtful type — and this is exactly the trap that catches thoughtful founders
- Close with pivot: the non-compete does not protect your proprietary knowledge; it reveals how much you depend on the person who has it

---

**Callout Quote — H2.2:**
> ***"Enforcing a non-compete does not prove the contractor was yours. It proves you treated them like an employee. That is the opposite of what you wanted to show."***

---

## H2.3 — WHAT ACTUALLY PROTECTS YOU

### H2.3 Intro Paragraph

If the non-compete is the wrong tool, the question becomes what the right tools are. Three legal mechanisms actually address the real threat: IP assignment, trade secret law, and client non-solicitation. None of them are glamorous. None of them require a courtroom to enforce. And all of them work in every state.

**[PARAGRAPH 1 — H2.3 intro: 5 sentences, transitions from "what doesn't work" to "what does" with urgency]**

---

### H3.3.1 — IP Assignment: The Foundation Most Agreements Skip

**Paragraph 1 — Main idea:** Intellectual property assignment is the most direct way to address the information problem. Instead of trying to restrict what the contractor knows, you make ownership of what they create unambiguous from the start.

**Paragraph 1 — Logical flow:**
- Lead with the mechanism: IP assignment transfers ownership of work product from the creator to the hiring business
- Explain why this matters: the contractor creates the email sequences, the sales funnels, the strategic frameworks — without assignment, those creations legally belong to the contractor
- Illustrate: if you paid for the work, you should own the work; IP assignment closes the gap between payment and ownership
- Transition: this is not a legal nuance — it is the foundational transaction in any contractor relationship involving creative output

**Paragraph 2 — Main idea:** Most standard contractor agreements skip explicit IP assignment or leave it ambiguous. This is the gap where you lose control of your own operational infrastructure.

**Paragraph 2 — Logical flow:**
- Bridge: Furthermore, the absence of explicit assignment is not neutral — it defaults to the contractor in most jurisdictions
- Explain the default rule: when a contractor creates work without a written IP assignment, they retain the rights to that work even if you paid for it
- Illustrate the consequence: the person who wrote your sales copy can legally repurpose it for your competitor because you never assigned the IP to yourself
- Close with pivot: if your contractor agreement does not have a clear IP assignment clause, you are paying for assets you do not own

---

### H3.3.2 — Trade Secret Law: Federal, State-Robust, Covers the Information Problem

**Paragraph 1 — Main idea:** Trade secret law addresses the information problem directly — it protects confidential business information from being used or disclosed by anyone who had access to it. The Defend Trade Secrets Act (DTSA) provides federal coverage alongside state-level UTSA laws in all 50 states.

**Paragraph 1 — Logical flow:**
- Lead with the scope: trade secret law covers client lists, pricing structures, vendor relationships, operational processes, and strategic plans — exactly the information a departing contractor can take
- Explain the advantage: unlike the non-compete, trade secret law is not geographically limited; it applies in every state and has federal backing through the DTSA
- Contrast with non-compete: trade secret law does not restrict where someone works — it restricts what they do with information they agreed to keep confidential
- Transition: this means you can protect your client relationships and operational knowledge without running into enforceability gaps or misclassification traps

**Paragraph 2 — Main idea:** The key to trade secret protection is the confidentiality agreement — it defines what information is protected and creates the legal obligation to keep it secret. Without it, the information is not legally a trade secret.

**Paragraph 2 — Logical flow:**
- Bridge: Consequently, trade secret protection requires active designation — you have to identify what is secret and require the contractor to acknowledge that obligation
- Explain the requirement: the agreement must specify what categories of information are confidential (client data, pricing, processes) and require the contractor to treat them accordingly
- Illustrate the failure mode: vague confidentiality language that does not define the scope leaves you without clear protection when you need it
- Close with pivot: if your contractor agreement has a non-compete but no explicit, defined confidentiality obligation, you have the wrong protection for the actual threat

---

### H3.3.3 — Non-Solicitation: The Clause That Actually Targets Client Relationships

**Paragraph 1 — Main idea:** Client non-solicitation is the clause that directly addresses the fear behind most non-competes — that a departing contractor will take your customers. It restricts solicitation of YOUR clients for a defined period, which is exactly what you actually want to prevent.

**Paragraph 1 — Logical flow:**
- Lead with the distinction: non-solicitation targets specific clients you named in the agreement; non-compete targets everyone everywhere — one is surgical, one is broad and often unenforceable
- Explain the enforceability advantage: non-solicitation is more narrowly tailored and therefore more consistently enforceable across jurisdictions than non-competes
- Illustrate: a 12-month restriction on soliciting your top 20 clients is defensible; a restriction on working in your industry anywhere is almost always not
- Transition: if your actual fear is that the contractor will go after your customers, non-solicitation is the clause that fits the crime

**Paragraph 2 — Main idea:** The non-solicitation clause works in conjunction with trade secret law and IP assignment — together they cover ownership, confidentiality, and client relationships without the geographic overreach that creates misclassification risk.

**Paragraph 2 — Logical flow:**
- Bridge: Beyond the individual advantages, the three tools work as a system
- Explain the system: IP assignment covers work product ownership; trade secret law covers confidential information; non-solicitation covers client relationships — each addresses a distinct threat without overlapping enforcement problems
- Illustrate: the contractor who takes your client list and starts emailing them has violated your non-solicitation and trade secret obligations, regardless of where they are working
- Close with pivot: when you build protection around these three tools instead of a non-compete, you have coverage that works in every state and does not generate its own liability

---

**Callout Quote — H2.3:**
> ***"You are not protecting your business by keeping a contractor from working in your industry. You are protecting it by owning what they create, keeping it secret, and restricting them from your customers. Those three tools actually do what the non-compete promised."***

---

## H2.4 — WHEN IT MIGHT BE WORTH USING

### H2.4 Intro Paragraph

This is not an article that says non-competes are never appropriate. They are occasionally appropriate, in narrow circumstances, for genuine independent contractors who clear specific thresholds. The problem is that most micro-business owners include them reflexively, as a standard clause, without checking whether those narrow circumstances apply. This section defines those circumstances honestly and tells you what to ask before you use one.

**[PARAGRAPH 1 — H2.4 intro: 5 sentences, closes the loop — non-compete earns its place briefly, but only in specific conditions]**

---

### H3.4.1 — The Narrow Scenario Where It Holds (Threshold Met + Genuine Independence + Narrow Scope)

**Paragraph 1 — Main idea:** The non-compete is worth using only when three conditions are simultaneously true: the compensation threshold is met, the contractor operates genuinely independently (not economically dependent on you), and the geographic and time scope are narrow.

**Paragraph 1 — Logical flow:**
- Lead with the three-part test: threshold, independence, scope — all three must be satisfied
- Explain the threshold condition: in Washington ($317,147.09) and DC ($162,164), the contract value or compensation must clear the bar before the clause is enforceable
- Explain the independence condition: the contractor must genuinely operate as a separate business — multiple clients, own tools, own insurance
- Explain the scope condition: narrow geographic area, short time period (12 months or less), specific industry — not broad industry-wide restrictions
- Transition: when all three conditions are met, the clause is more defensible — but that combination is rare in micro-business contexts

**Paragraph 2 — Main idea:** The honest assessment for most micro-business owners is that one or more of these conditions is not met. The contractor is not clearing the threshold, or they are too dependent on the business for it to be a genuine independent contractor relationship, or the scope required to actually protect the business is too broad to be enforceable.

**Paragraph 2 — Logical flow:**
- Bridge: Perhaps the clearest signal that the conditions are not met is how essential the contractor is to your operations
- Explain the dependency problem: if losing this contractor would meaningfully damage your business, they are not a genuine independent operator — they are functionally an employee, and the non-compete will reflect that if challenged
- Illustrate the scope problem: a contractor who handles your primary lead generation cannot be restricted from the entire marketing industry for two years — the scope required to protect you is too broad to be enforceable
- Close with pivot: before including a non-compete, ask whether your contractor arrangement actually satisfies the three conditions — most do not

---

### H3.4.2 — The Real Question to Ask Your Provider

**Paragraph 1 — Main idea:** The most useful diagnostic question is not whether the non-compete is enforceable — it is whether your contractor agreement actually includes the three protections that work (IP assignment, trade secret confidentiality, non-solicitation). If those are missing, the non-compete is not your primary problem.

**Paragraph 1 — Logical flow:**
- Lead with the diagnostic question: does your contractor agreement cover IP ownership, confidentiality of business information, and client non-solicitation?
- Explain why this question matters: if those three are missing, you have a gap regardless of the non-compete — and if those three are present, the non-compete may be redundant or worse
- Illustrate: a founder who spent $2,000 on a lawyer to draft a non-compete and left out IP assignment has the wrong priority — the work product clause is more important than the restriction clause
- Transition: this is the question to bring to whoever drafted your agreement — not "is the non-compete enforceable" but "what does the agreement actually protect"

**Paragraph 2 — Main idea:** Ask the second question directly: what happens to this clause if a court reclassifies this contractor as an employee? If your lawyer cannot answer that question, or answers it in a way that shows the non-compete creates misclassification risk, you need a different structure.

**Paragraph 2 — Logical flow:**
- Bridge: Ultimately, the legal structure you choose should survive contact with a court
- Explain what to look for: if enforcing the non-compete demonstrates control → and control supports misclassification → then the clause is a liability in the scenario where you most need it
- State the standard: a good contractor agreement protects your assets (IP, client relationships, confidential information) without creating the behavioral evidence that supports an employment claim
- Close with pivot: the real question is not whether the non-compete is enforceable — it is whether the entire agreement holds together when it is tested

---

**Callout Quote — H2.4:**
> ***"A non-compete is worth using only when you have already solved the three problems it cannot solve: IP ownership, information confidentiality, and customer protection. Without those in place, the non-compete is not protection — it is a false sense of security that costs you when it matters."***

---

## FAQ SECTION

### FAQ 1: Can I enforce a non-compete if my contractor lives in a different state?

**Unique operational anxiety:** I hired someone remotely and they are now working in a state where the clause might not be enforceable — what are my actual options if they violate it?

**Answer direction:**
Explain that the clause is governed by the state where the contractor lives and works, not the state where your business is based. Address what to do if the contractor moves to California or another void state after signing. Focus the answer on the three actual protections (IP, trade secrets, non-solicitation) and note that those tools work regardless of geography.

### FAQ 2: My contractor signed a non-compete but I never had them sign an IP assignment — what do I actually own?

**Unique operational anxiety:** I have a signed agreement but it is missing the most important clause — do I own anything they created for me?

**Answer direction:**
Explain the default rule: without explicit IP assignment, the contractor retains ownership of work they created. Explain that payment for work does not transfer ownership. Focus on the urgency of amending the agreement before the contractor creates more work product. Note that going forward matters more than fixing the past perfectly.

### FAQ 3: What should I look for in a contractor agreement to avoid the problems described in this article?

**Unique operational anxiety:** I do not want to make expensive legal mistakes — what does a well-drafted independent contractor agreement actually need to include?

**Answer direction:**
List the three essential clauses (IP assignment, trade secret confidentiality with defined scope, client non-solicitation). Explain what each actually covers and why it is distinct from a non-compete. Note what a good agreement does not include (overly broad non-competes that create misclassification risk). Recommend having a lawyer review the agreement specifically for these three protections.

---

## BOTTOM LINE — CLOSING FRAME

**Closing framing:**
The non-compete was never the right tool for what most micro-business owners actually need to protect. It restricts location when the real threats are informational. It sits in every contractor agreement as a security blanket that evaporates the moment you need it, and it can generate its own liability when you try to enforce it. The three tools that actually work — IP assignment, trade secret confidentiality, and client non-solicitation — are not glamorous. They do not require courtroom enforcement in most cases. And they work in every state, for every contractor relationship, without creating the control evidence that supports misclassification. If you have a non-compete in your contractor agreements and nothing else, you have the wrong protection. The fix is not complicated — it is just a matter of knowing what to ask for.
