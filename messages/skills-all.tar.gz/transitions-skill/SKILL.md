---
name: transitions-skill
description: Use when checking, fixing, or improving paragraph-to-paragraph transitions in article prose. Triggers on "check transitions", "fix transitions", "paragraph flow", "connect ideas between paragraphs", "bridge paragraphs". This skill is NOT about adding transition words — it is about ensuring logical threads carry through from one paragraph to the next.
---

# Transitions Skill — Logical Thread Between Paragraphs

**The problem:** Most AI-written prose has choppy paragraph transitions. Each paragraph starts with a transition word ("Furthermore", "Yet", "Consequently") but the transition word is disconnected from what the previous paragraph actually said. The reader experiences stop-start-stop-start reading. The argument feels like a list, not a flow.

**The solution:** Transitions are not cosmetic. They are logical. A transition is a hinge — it connects what came before to what comes after by making the relationship explicit. Transition words are the signal, not the mechanism. The mechanism is the logical relationship between the last sentence of paragraph N and the first sentence of paragraph N+1.

---

## The Three Levels of Transition

### Level 1 — Vocabulary Bridge

**What it is:** The last word of paragraph N and the first word of paragraph N+1 should not be the same word or same word family.

**Example (wrong):**
> "The non-compete is a geographic restriction. **Geographic** restrictions are meaningless for online contractors."

**Example (correct):**
> "The non-compete is a geographic restriction. **Location-based** controls cannot prevent a contractor from serving clients remotely from anywhere."

**Why it matters:** Same-word repetition at paragraph boundaries creates cognitive friction. The reader feels the jump. Fix it by using a different word family in the opening sentence.

---

### Level 2 — Logical Thread

**What it is:** The last sentence of paragraph N must set up the first sentence of paragraph N+1. The pivot sentence at the end of paragraph N should carry a keyword, concept, or implication that the next paragraph picks up and develops.

**The test:**
1. Read the last sentence of paragraph N
2. Read the first sentence of paragraph N+1
3. Ask: does the second sentence follow from the first?

**Example (wrong):**
> "The non-compete protects a geographic territory that no longer exists in the knowledge economy." [closes with "territory"]
> "**Client data** is the real asset a departing contractor takes."

The second sentence doesn't follow from the first. "Territory" → "client data" is a conceptual leap with no bridge.

**Example (correct):**
> "The non-compete protects a geographic territory that no longer exists in the knowledge economy."
> "**The information inside that territory — client lists, pricing models, outreach sequences — is what a departing contractor actually carries out the door.**"

The second sentence takes "territory" and reveals what was inside it. The logical thread is intact.

---

### Level 3 — Argument Escalation

**What it is:** Each paragraph should end by raising a question, introducing a tension, or making a claim that the next paragraph answers, resolves, or escalates. This creates momentum — the reader feels pulled forward, not pushed along.

**The pattern:**
- Paragraph N ends with: a tension, a question, or a claim that demands follow-through
- Paragraph N+1 opens by: picking up that tension and resolving or escalating it

**Example (escalation):**
> P1: "Courts look at whether a worker is economically dependent on the hiring business or whether they operate as an independent business entity."
> P2: "**This creates a structural bind.** The business that most needs protection is the one whose protective actions most clearly signal the employment relationship that voids their protection."

P1 establishes the test. P2 opens with the implication of that test. The escalation is earned, not cosmetic.

---

## The Transition Audit Method

**Step 1:** Read each paragraph pair in order. For each pair:
- Does the last sentence of paragraph 1 connect to the first sentence of paragraph 2?
- What is the keyword bridge between them?
- Is the connection logical, or is it just cosmetic (same transition word glued on)?

**Step 2:** Mark every paragraph boundary where:
- The same word family appears at the end of paragraph N and the start of paragraph N+1 → fix the Level 1 vocabulary
- The logical thread is missing → fix by adding a bridging sentence or revising the pivot
- The escalation is missing → add tension or a question at paragraph N's close

**Step 3:** Fix by revision, not by insertion. It is almost always better to rewrite the pivot sentence at the end of paragraph N to carry the thread forward than to add a bridging sentence between paragraphs. Additional sentences between paragraphs create filler.

---

## Transition Words Are Signals, Not Mechanisms

**The mistake:** Adding "Furthermore" at the start of a paragraph without ensuring the paragraph actually continues the previous argument.

**The fix:** The transition word should describe the actual logical relationship:
- "Furthermore" = adding more of the same type of evidence
- "Yet" = introducing a contrast that complicates what came before
- "Consequently" = showing that what came before produces a result
- "Worse" = escalating the stakes of what came before
- "For instance" = illustrating what came before with a specific case

If the word doesn't match the actual relationship, don't use it. Find the right word, or restructure the sentence so the logical relationship is clear without a transition word.

---

## Paragraph Closing: The Pivot Sentence

Every paragraph (not just the last in a section) should end with a sentence that implicates the reader's agency — what the reader should now think, do, or consider based on what the paragraph just proved.

**Wrong close:**
> "This is why many contractor agreements fail to protect the assets they were meant to protect."

**Correct close:**
> "If your contractor agreement has a non-compete but no explicit, defined confidentiality obligation, you have the wrong protection for the actual threat."

The correct close puts the reader inside the implication. The wrong close states a general observation from outside the reader's position.

---

## Reference

See `references/transition-examples.md` for annotated examples of good and bad transitions.
