# Transition Examples — Good and Bad

## Vocabulary Bridge — Examples

### Wrong (same word family at boundary)

> **P1:** "The non-compete is a geographic restriction on where a contractor can work."
> **P2:** "**Geographic** restrictions are meaningless when contractors operate online."

Problem: "geographic" appears in both. The reader feels the jump.

### Correct (vocabulary bridge)

> **P1:** "The non-compete is a geographic restriction on where a contractor can work."
> **P2:** "**Location-based** controls cannot prevent a contractor from serving clients remotely from anywhere."

"Geographic" → "Location-based" — same concept, different word family. Smooth bridge.

---

## Logical Thread — Examples

### Wrong (no thread)

> **P1:** "The non-compete protects a geographic territory that no longer exists in the knowledge economy."
> **P2:** "**Client data** is the real asset a departing contractor takes."

Problem: "territory" jumps to "client data" with no logical connection. The reader can't follow how we got there.

### Correct (logical thread)

> **P1:** "The non-compete protects a geographic territory that no longer exists in the knowledge economy."
> **P2:** "**The information inside that territory — client lists, pricing models, outreach sequences — is what a departing contractor actually carries out the door.**"

P2 takes "territory" and reveals what was inside it. The thread is explicit.

---

## Argument Escalation — Examples

### Wrong (no escalation)

> **P1:** "Courts look at whether a worker is economically dependent on the hiring business."
> **P2:** "**Economic dependence is the state in which a contractor's income flows from a single client.**"

P2 restates P1 instead of escalating. No new ground is broken. No tension is created.

### Correct (escalation)

> **P1:** "Courts look at whether a worker is economically dependent on the hiring business."
> **P2:** "**This creates a structural bind.** The business that most needs protection is the one whose protective actions most clearly signal the employment relationship that voids their protection."

P1 establishes the test. P2 opens with "This creates a structural bind" — the implication. Now the argument is moving somewhere.

---

## Transition Words — Right and Wrong Use

### Wrong (word doesn't match relationship)

> "Furthermore, trade secret law applies in every state."

This is used as a connector but doesn't add more of the same type of evidence — it's changing the subject. "Furthermore" is wrong here.

### Correct (word matches relationship)

> "Furthermore, a contractor who handles your primary lead generation cannot be restricted from the entire marketing industry for two years."

This actually adds more of the same type of evidence — a second illustration of the same point. "Furthermore" fits.

---

## Paragraph Closing — Pivot Sentences

### Wrong (no reader implicitness)

> "This is why many contractor agreements fail to protect the assets they were meant to protect."

Reader is outside the statement. It's an observation about the world, not a implicating the reader.

### Correct (reader implicitness)

> "If your contractor agreement has a non-compete but no explicit, defined confidentiality obligation, you have the wrong protection for the actual threat."

Reader is inside the statement — "you have" puts them directly in the implication. The close implicates reader agency.

---

## Full Paragraph Pair — Complete Example

From the NC article, H3.1.1, two paragraphs working as a complete argument:

> **P1:** The non-compete does not restrict what the contractor knows or what they do with that knowledge. It restricts where they can physically work — which is meaningless if they operate online or across state lines. Location-based restrictions cannot stop someone from serving clients remotely from anywhere. A founder who thinks their non-compete prevents a contractor from taking email sequences or client data is using the wrong tool for the actual threat.

> **P2:** Beyond location, the real value is informational. A contractor who leaves can take your pricing model, your outreach scripts, and your conversion data on a laptop. The email sequences, the ad copy, the strategic frameworks — these are the assets, not the physical territory. A location restriction stops none of it. If geographic restriction is the tool and the threat is informational, you are using the wrong tool entirely.

**Level 1 (vocabulary):** "location-based" in P1 → no repetition in P2 opening. Clean.
**Level 2 (logical thread):** P1 ends with "wrong tool for the actual threat." P2 opens with "Beyond location, the real value is informational" — this picks up the "threat" implication and reframes what the threat actually is.
**Level 3 (escalation):** P1 establishes that location restriction is useless. P2 escalates: the real threat is informational AND the tool doesn't address it. The argument has moved from "this is broken" to "here's what is actually at stake."

---

## Transition Audit Checklist

For each paragraph boundary:
1. Do the last word of paragraph N and the first word of paragraph N+1 share a word family? → fix with vocabulary bridge
2. Does the last sentence of paragraph N set up the first sentence of paragraph N+1? → fix the logical thread
3. Does paragraph N end by raising stakes, asking a question, or creating tension that paragraph N+1 resolves? → fix the escalation
4. Does the closing pivot sentence implicate reader agency, not just state a general observation?
